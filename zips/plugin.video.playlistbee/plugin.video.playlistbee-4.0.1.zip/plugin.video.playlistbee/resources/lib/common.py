# -*- coding: utf-8 -*-

import base64
import gzip
import hashlib
import json
import os
import pickle
import re
import shutil
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime as dt, timedelta, timezone
from io import BytesIO
import chardet
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


AddonID = "plugin.video.playlistbee"

Addon = xbmcaddon.Addon(AddonID)

AddonName = Addon.getAddonInfo("name")

icon = Addon.getAddonInfo("icon")

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))

cacheDir = os.path.join(addon_data_dir, "cache")

for _d in (addon_data_dir, cacheDir):
    if not os.path.exists(_d):
        os.makedirs(_d, exist_ok=True)

_DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.3"

_custom_ua = ""

if Addon.getSetting("useCustomUA") == "true":
    _custom_ua = (Addon.getSetting("customUA") or "").strip()

UA = _custom_ua or _DEFAULT_UA


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[Bee] {0}".format(msg), level)


class SmartRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        return urllib.request.HTTPRedirectHandler.http_error_301(
            self, req, fp, code, msg, headers
        )

    def http_error_302(self, req, fp, code, msg, headers):
        return urllib.request.HTTPRedirectHandler.http_error_302(
            self, req, fp, code, msg, headers
        )

def getFinalUrl(url, headers=None, timeout=10):
    if not url or not url.startswith("http"):
        return url, "", "unknown"

    req_headers = {"User-Agent": UA}
    if headers:
        req_headers.update(headers)

    req_url = url
    parsed = urllib.parse.urlsplit(url)
    if parsed.username:
        cred = "{0}:{1}".format(parsed.username, parsed.password or "")
        req_headers["Authorization"] = (
            "Basic " + base64.b64encode(cred.encode("utf-8")).decode("ascii")
        )
        netloc = parsed.hostname + (
            ":{0}".format(parsed.port) if parsed.port else ""
        )
        req_url = urllib.parse.urlunsplit(
            (parsed.scheme, netloc, parsed.path, parsed.query,
             parsed.fragment)
        )

    try:
        req = urllib.request.Request(req_url)
        for k, v in req_headers.items():
            req.add_header(k, v)
        opener = urllib.request.build_opener(SmartRedirectHandler())
        f = opener.open(req, timeout=timeout)
        final = f.url or req_url
        ctype = (f.headers.get("Content-Type") or "")
        ctype = ctype.split(";", 1)[0].strip().lower()
        if final != req_url:
            log(
                "getFinalUrl: {0} -> {1} [{2}]".format(url, final, ctype),
                xbmc.LOGDEBUG,
            )
        return final, ctype, "ok"
    except urllib.error.HTTPError as ex:
        log("getFinalUrl: HTTP {0} {1}".format(ex.code, url), 3)
        if ex.code in (400, 401, 402, 403, 404, 410, 451):
            return url, "", "dead"
        return url, "", "unknown"
    except urllib.error.URLError as ex:
        reason = getattr(ex, "reason", None)
        rname = reason.__class__.__name__ if reason is not None else ""
        log("getFinalUrl: {0} {1}".format(rname or ex, url), 3)
        if rname in ("ConnectionRefusedError", "gaierror"):
            return url, "", "dead"
        return url, "", "unknown"
    except Exception as ex:
        log("getFinalUrl: {0}".format(ex), 3)
        return url, "", "unknown"

def OpenURL(url, headers=None, user_data=None, cookieJar=None, justCookie=False, timeout=20):
    parsed = urllib.parse.urlsplit(url)
    auth_header = None
    if parsed.username:
        cred = "{0}:{1}".format(parsed.username, parsed.password or "")
        auth_header = "Basic " + base64.b64encode(cred.encode("utf-8")).decode("ascii")
        netloc = parsed.hostname + (":{0}".format(parsed.port) if parsed.port else "")
        url = urllib.parse.urlunsplit(
            (parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment)
        )

    url = urllib.parse.quote(url, safe=":/?&=%~#+!$,;'@()*[]")

    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(cookieJar)
    )

    post_data = None
    if user_data:
        post_data = urllib.parse.urlencode(user_data).encode("utf-8")

    req_headers = {"User-Agent": UA, "Accept-Encoding": "gzip, deflate"}
    if auth_header:
        req_headers["Authorization"] = auth_header
    if headers:
        req_headers.update(headers)

    req = urllib.request.Request(url, data=post_data, headers=req_headers)

    response = opener.open(req, timeout=timeout)
    try:
        if justCookie:
            return response.info().get("Set-Cookie")

        raw = response.read()

        encoding = (response.info().get("Content-Encoding") or "").lower()
        if encoding == "gzip" or raw[:2] == b"\x1f\x8b":
            try:
                raw = gzip.GzipFile(fileobj=BytesIO(raw)).read()
            except OSError:
                pass
        elif encoding == "deflate":
            try:
                raw = zlib.decompress(raw, -zlib.MAX_WBITS)
            except zlib.error:
                try:
                    raw = zlib.decompress(raw)
                except zlib.error:
                    pass

        try:
            data = raw.decode("utf-8")
        except UnicodeDecodeError:
            detected = chardet.detect(raw).get("encoding") or "utf-8"
            data = raw.decode(detected, errors="replace")
        return data.replace("\r", "")
    finally:
        response.close()

def _downloadToFile(url, dest, timeout=30):
    tmp = dest + ".tmp"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            with open(tmp, "wb") as out:
                while True:
                    chunk = resp.read(262144)
                    if not chunk:
                        break
                    out.write(chunk)
        os.replace(tmp, dest)
        return True
    except Exception as ex:
        log("_downloadToFile failed for {0}: {1}".format(url, ex), 3)
        DelFile(tmp)
        return False


def ReadFile(fileName):
    try:
        f = xbmcvfs.File(fileName)
        content = f.read()
        f.close()
        return content
    except Exception as ex:
        log("ReadFile failed for {0}: {1}".format(fileName, ex), 3)
        return ""

def SaveFile(fileName, text):
    try:
        f = xbmcvfs.File(fileName, "w")
        f.write(text)
        f.close()
        return True
    except Exception as ex:
        log("SaveFile failed for {0}: {1}".format(fileName, ex), 3)
        return False

def ReadList(fileName):
    if not os.path.isfile(fileName):
        return []
    try:
        with open(fileName, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception as ex:
        log("ReadList failed for {0}: {1}".format(fileName, ex), 5)
        try:
            shutil.copyfile(
                fileName, "{0}_bak.txt".format(os.path.splitext(fileName)[0])
            )
            xbmcgui.Dialog().notification(
                AddonName,
                Addon.getLocalizedString(30007).format(
                    os.path.basename(fileName)
                ),
                icon,
                5000,
            )
        except Exception:
            pass
        return []

def SaveList(fileName, chList, indent=4):
    try:
        with open(fileName, "w", encoding="utf-8") as handle:
            json.dump(chList, handle, indent=indent, ensure_ascii=False)
        return True
    except Exception as ex:
        log("SaveList failed for {0}: {1}".format(fileName, ex), 3)
        return False

def DelFile(filname):
    try:
        if os.path.isfile(filname):
            os.unlink(filname)
    except Exception as ex:
        log("DelFile failed for {0}: {1}".format(filname, ex), 3)

def GetEncodeString(s):
    if isinstance(s, bytes):
        try:
            s = s.decode("utf-8")
        except UnicodeDecodeError:
            detected = chardet.detect(s).get("encoding") or "utf-8"
            s = s.decode(detected, errors="replace")
    return s.replace("\r", "") if isinstance(s, str) else s

def OKmsg(title, line1):
    xbmcgui.Dialog().ok(title, line1)


class _KeyBox:
    __slots__ = ("_k",)

    def __init__(self, key):
        self._k = bytes(key)

    def get(self):
        return self._k

    def __repr__(self):
        return "<key hidden>"

    __str__ = __repr__

_CACHE_KEY = None

def set_key(key):
    global _CACHE_KEY
    _CACHE_KEY = _KeyBox(key)

def _xor(data: bytes, key: bytes) -> bytes:
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def encrypt_data(data, key: bytes) -> bytes:
    return _xor(zlib.compress(pickle.dumps(data)), key)

def decrypt_data(blob: bytes, key: bytes):
    if not blob:
        return None
    unxored = _xor(blob, key)
    try:
        raw = zlib.decompress(unxored)
    except zlib.error:
        raw = unxored
    return pickle.loads(raw)

def save_encrypted(filname, data, key: bytes):
    try:
        with open(filname, "wb") as handle:
            handle.write(encrypt_data(data, key))
        return True
    except Exception as ex:
        log("save_encrypted failed for {0}: {1}".format(filname, ex), 3)
        return False

def load_encrypted(filname, key: bytes, default=None):
    fallback = default if default is not None else []
    if not os.path.isfile(filname):
        return fallback
    try:
        with open(filname, "rb") as handle:
            blob = handle.read()
        if not blob:
            return fallback
        result = decrypt_data(blob, key)
        return fallback if result is None else result
    except Exception as ex:
        log("load_encrypted failed for {0}: {1}".format(filname, ex), 5)
        try:
            base, ext = os.path.splitext(filname)
            bak = "{0}_bak_{1}{2}".format(base, int(time.time()), ext or ".dat")
            shutil.copyfile(filname, bak)
            xbmcgui.Dialog().notification(
                AddonName,
                Addon.getLocalizedString(30007).format(
                    os.path.basename(filname)
                ),
                icon,
                5000,
            )
        except Exception:
            pass
        return fallback


_EPG_PARSED_SUFFIX = "#epg-parsed"

_EPG_RAW_SUFFIX = "#epg-raw"

def cachePath(address):
    return os.path.join(cacheDir, hashlib.md5(address.encode("utf-8")).hexdigest())

def cacheNames(address, epg=""):
    names = [os.path.basename(cachePath(address))] if address else []
    if epg:
        names.append(os.path.basename(cachePath(epg)))
        names.append(os.path.basename(cachePath(epg + _EPG_PARSED_SUFFIX)))
        names.append(os.path.basename(cachePath(epg + _EPG_RAW_SUFFIX)))
    return names

def isFileNew(filePath, deltaInSec):
    if not os.path.isfile(filePath):
        return False
    return (time.time() - os.path.getmtime(filePath)) <= deltaInSec

def isFromCache(address, cache=0):
    if cache <= 0:
        return False
    target = cachePath(address) if address.startswith("http") else address
    return isFileNew(target, cache * 60)


def GetList(address, cache=0):
    if not address.startswith("http"):
        return ReadFile(address)

    key = _CACHE_KEY.get() if _CACHE_KEY else None
    fileLocation = cachePath(address)

    if key and cache > 0 and isFileNew(fileLocation, cache * 60):
        cached = load_encrypted(fileLocation, key, default="")
        if cached:
            return cached

    try:
        response = OpenURL(address)
    except Exception as ex:
        log("GetList: download failed for {0}: {1}".format(address, ex), 3)
        stale = load_encrypted(fileLocation, key, default="") if key else ""
        return stale or ""

    if key and cache > 0 and response:
        save_encrypted(fileLocation, response, key)
    return response

def plx2list(url, cache):
    response = GetList(url, cache)

    background = None
    chList = []
    item_data = None

    for line in response.splitlines():
        line = line.strip()
        if not line:
            continue

        if line == "#":
            if item_data:
                item_data.setdefault("group", "Main")
                chList.append(item_data)
                item_data = None
            continue

        if "=" not in line:
            continue

        field, value = line.split("=", 1)
        field = field.strip().lower()
        value = value.strip()

        if item_data is None:
            if field == "type":
                item_data = {"type": value}
            elif field == "background":
                background = value
        else:
            item_data[field] = value

    if item_data:
        item_data.setdefault("group", "Main")
        chList.append(item_data)

    return [{"background": background}] + chList

_M3U_ATTR = re.compile(
    r'([\w-]+)=(?:"([^"]*)"|\'([^\']*)\'|([^\s,]+))'
)

_ATTR_NUM_PREFIX_RE = re.compile(r"^[-+\d.]+")

def _splitExtinf(body):
    last_end = 0
    for m in _M3U_ATTR.finditer(body):
        last_end = m.end()
    comma = body.find(",", last_end)
    if comma == -1:
        return body, ""
    return body[:comma], body[comma + 1:]

_ZWSP_CHARS = "\u200b\u200c\u200d\ufeff"

_OBF_PROBE = 4096
_OBF_MAX_B64 = 32 * 1024 * 1024


def _m3uScore(text):
    lines = [ln.strip() for ln in text.split("\n")]
    lines = [ln for ln in lines if ln]
    score = 0
    for i, ln in enumerate(lines):
        if "#EXTINF" not in ln:
            continue
        for nxt in lines[i + 1:i + 5]:
            if not nxt.startswith("#"):
                score += 1
                break
            if "#EXTINF" in nxt:
                break
    return score


def _looksLikeM3u(text):
    return _m3uScore(text) > 0


def _deobfuscate(text):
    if not text or _looksLikeM3u(text):
        return text

    probe = text[:_OBF_PROBE]

    if any(ch in probe for ch in _ZWSP_CHARS):
        stripped = text
        for ch in _ZWSP_CHARS:
            stripped = stripped.replace(ch, "")
        if _looksLikeM3u(stripped[:_OBF_PROBE]):
            log("deobfuscate: zero-width join")
            return stripped

    norm = text.replace("\r\n", "\n")
    for off in (0, 1):
        if _looksLikeM3u(norm[:_OBF_PROBE][off::2]):
            log("deobfuscate: separator join (offset {0})".format(off))
            return norm[off::2]

    perline = "\n".join(
        ln[::-1] for ln in text.replace("\r\n", "\n").split("\n")
    )
    whole = text[::-1]
    s_perline = _m3uScore(perline[:_OBF_PROBE])
    s_whole = _m3uScore(whole[:_OBF_PROBE])
    if s_perline or s_whole:
        if s_perline >= s_whole:
            log("deobfuscate: per-line reversed")
            return perline
        log("deobfuscate: whole text reversed")
        return whole

    half = (len(text) + 1) // 2
    rail = "".join(
        a + b for a, b in zip(text[:half], text[half:] + " ")
    ).rstrip(" ")
    if _looksLikeM3u(rail[:_OBF_PROBE]):
        log("deobfuscate: rail-fence")
        return rail

    blob = "".join(text.split())
    if 8 < len(blob) <= _OBF_MAX_B64:
        try:
            raw = base64.b64decode(blob, validate=True)
        except Exception:
            raw = None
        if raw:
            try:
                unz = gzip.decompress(raw).decode("utf-8", "replace")
                if _looksLikeM3u(unz[:_OBF_PROBE]):
                    log("deobfuscate: gzip+base64")
                    return unz
            except Exception:
                pass
            try:
                plain = raw.decode("utf-8", "replace")
                if _looksLikeM3u(plain[:_OBF_PROBE]):
                    log("deobfuscate: base64")
                    return plain
            except Exception:
                pass

    return text


_M3U_DIRECTIVE_RE = re.compile(
    r"#(?:EXTINF|EXTM3U|EXTGRP|EXTVLCOPT|KODIPROP)\b", re.I
)

_URLISH_RE = re.compile(r"^(?:[a-z][a-z0-9+.\-]*://|/|\\\\)", re.I)


def _splitGluedLine(line):
    pos = [m.start() for m in _M3U_DIRECTIVE_RE.finditer(line)]
    if not pos or (len(pos) == 1 and pos[0] == 0):
        return [line]
    parts = []
    prev = 0
    for p in pos:
        if p > prev:
            seg = line[prev:p].strip()
            if seg:
                parts.append(seg)
        prev = p
    tail = line[prev:].strip()
    if tail:
        parts.append(tail)
    return parts


_BARE_DIRECTIVE_RE = re.compile(
    r"^(EXTINF|EXTM3U|EXTGRP|EXTVLCOPT|KODIPROP)\b", re.I
)

_HEADER_DECOR_RE = re.compile(
    r"^[\s=\-*_~#/.]{3,}|[\s=\-*_~#/.]{3,}$"
)

_NON_URL_PLACEHOLDERS = ("skip", "none", "null", "-", "#", "")


def _fixBareDirective(line):
    if line.startswith("#"):
        return line
    return "#" + line if _BARE_DIRECTIVE_RE.match(line) else line


def _isHeaderItem(name, url):
    if _isUrlish(url):
        return False
    if url.strip().lower() not in _NON_URL_PLACEHOLDERS:
        return False
    plain = re.sub(r"\[/?[^\]]{1,20}\]", "", name or "").strip()
    return bool(plain) and bool(_HEADER_DECOR_RE.search(plain))


def _isUrlish(line):
    if not _URLISH_RE.match(line):
        return False
    return any(ch.isalnum() for ch in line)


def m3u2list(url, cache):
    response = GetList(url, cache)
    if not response:
        return []

    response = response.lstrip("\ufeff")
    response = _deobfuscate(response)

    if response.lstrip()[:1] == "<":
        log(
            "m3u2list: response is not M3U ({0}...)".format(
                response.lstrip()[:80].replace("\n", " ")
            ),
            3,
        )
        return []

    chList = []
    pending = None
    pre = {}

    def _addProp(target, line):
        prop = line.split(":", 1)[1]
        if "=" in prop:
            k, _, v = prop.partition("=")
            target.setdefault("props", {})[k.strip()] = v.strip()

    def _addVlcopt(target, line):
        opt = line.split(":", 1)[1]
        if "=" in opt:
            k, _, v = opt.partition("=")
            k = k.strip().lower()
            if k.startswith("http-"):
                hname = k[5:].replace("referrer", "referer")
                hname = "-".join(
                    w.capitalize() for w in hname.split("-")
                )
                target.setdefault("vlcopt", {})[hname] = v.strip()

    skipped_junk = 0

    for raw_line in response.splitlines():
        stripped = raw_line.strip().lstrip("\ufeff")
        if not stripped:
            continue

        for line in _splitGluedLine(_fixBareDirective(stripped)):
            if not line:
                continue

            line = _fixBareDirective(line)
            upper = line.upper()

            if upper.startswith("#EXTINF"):
                body = line.split(":", 1)[1].strip() if ":" in line else ""
                attrs_part, title = _splitExtinf(body)

                pending = {"display_name": title.strip()}
                if pre.get("props"):
                    pending["props"] = pre["props"]
                if pre.get("vlcopt"):
                    pending["vlcopt"] = pre["vlcopt"]
                pre = {}
                for m in _M3U_ATTR.finditer(attrs_part):
                    field = m.group(1).strip().lower()
                    field = _ATTR_NUM_PREFIX_RE.sub("", field)
                    field = field.replace("-", "_")
                    value = (m.group(2) or m.group(3) or m.group(4) or "").strip()
                    if field and value:
                        pending[field] = value

            elif upper.startswith("#EXTGRP"):
                if pending is not None and ":" in line:
                    grp = line.split(":", 1)[1].strip().strip('"').strip("'")
                    if grp:
                        pending["group_title"] = grp

            elif upper.startswith("#KODIPROP:"):
                _addProp(pending if pending is not None else pre, line)

            elif upper.startswith("#EXTVLCOPT:"):
                _addVlcopt(pending if pending is not None else pre, line)

            elif line.startswith("#"):
                continue

            else:
                if pending is not None:
                    if _isHeaderItem(pending.get("display_name", ""), line):
                        pending = None
                        skipped_junk += 1
                        pre = {}
                        continue
                    pending["url"] = line
                    if not pending.get("display_name"):
                        pending["display_name"] = pending.get("tvg_name", line)
                    chList.append(pending)
                    pending = None
                elif _isUrlish(line):
                    chList.append({"display_name": line, "url": line})
                else:
                    skipped_junk += 1
                pre = {}

    if skipped_junk:
        log("m3u2list: preskoceno {0} neispravnih redova".format(
            skipped_junk))

    return chList


def xmltvTime(s):
    try:
        base = dt(
            int(s[0:4]), int(s[4:6]), int(s[6:8]),
            int(s[8:10]), int(s[10:12]), int(s[12:14]),
        )
    except (ValueError, IndexError, TypeError):
        return None
    tail = s[14:].strip()
    if (len(tail) >= 5 and tail[0] in "+-" and tail[1:5].isdigit()):
        off = int(tail[1:3]) * 60 + int(tail[3:5])
        if tail[0] == "-":
            off = -off
        base -= timedelta(minutes=off)
    return base

_EPG_QUALITY_RE = re.compile(
    r"\b(4K|8K|UHD|FHD|FULL\s*HD|HD|SD|H\s*\.?\s*265|H\s*\.?\s*264|"
    r"RAW|PLUS|BACKUP|REZERVA|ALT|ALTERNATIVE|ALTERNATIVA|TEST|"
    r"SPORE|SPOR|LIVE)\b", re.I
)

_EPG_COUNTRY_PREFIX_RE = re.compile(r"^[A-Za-z]{2,3}\s*[-–]\s*")

_EPG_EXYU_PREFIX_RE = re.compile(r"^\s*EXYU\b\s*[-–|:.]?\s*", re.I)

_EPG_NONALNUM_RE = re.compile(r"[^0-9A-Za-z]+")

_EPG_ID_COUNTRY_SUFFIX_RE = re.compile(r"\.(EXYU|[A-Za-z]{2})$", re.I)

_EPG_DIACRITIC_MAP = str.maketrans({
    "đ": "dj", "Đ": "DJ",
})

_EPG_NAME_COUNTRY_RE = re.compile(r"^\s*(EXYU|[A-Za-z]{2})\s*[-–|:.]", re.I)

_EPG_ONSCREEN_EP_RE = re.compile(
    r"[Ss]\s*(\d{1,2})(?:\s*[,.\-–:xX/ ]*\s*[Ee][Pp]?\s*\.?\s*(\d{1,4}))?"
)

def normEpgName(name):
    name = (name or "").strip()
    name = _EPG_COUNTRY_PREFIX_RE.sub("", name)
    name = _EPG_EXYU_PREFIX_RE.sub("", name)
    name = re.sub(r"[\(\[].*?[\)\]]", "", name)
    name = _EPG_QUALITY_RE.sub("", name)
    name = name.translate(_EPG_DIACRITIC_MAP)
    name = unicodedata.normalize("NFKD", name)
    name = "".join(c for c in name if not unicodedata.combining(c))
    name = _EPG_NONALNUM_RE.sub("", name).upper()
    return name

def normEpgId(chid):
    chid = (chid or "").strip()
    chid = _EPG_ID_COUNTRY_SUFFIX_RE.sub("", chid)
    return _EPG_NONALNUM_RE.sub("", chid).upper()

def epgCountryFromId(chid):
    m = _EPG_ID_COUNTRY_SUFFIX_RE.search(chid or "")
    return m.group(1).lower() if m else ""

def epgCountryFromName(name):
    m = _EPG_NAME_COUNTRY_RE.match(name or "")
    if not m:
        return ""
    return m.group(1).lower()

def _openXmlStream(path):
    with open(path, "rb") as probe:
        magic = probe.read(2)
    if magic == b"\x1f\x8b":
        return gzip.open(path, "rb")
    return open(path, "rb")

def prefetchEpg(url, cache=720):
    if not url or not url.startswith("http"):
        return

    rawFresh = isFromCache(url + _EPG_RAW_SUFFIX, cache)
    parsedFresh = isFromCache(url + _EPG_PARSED_SUFFIX, cache)
    if rawFresh and parsedFresh:
        return

    lock = cachePath(url + _EPG_RAW_SUFFIX) + ".lock"
    if isFileNew(lock, 600):
        return
    try:
        with open(lock, "w") as h:
            h.write(str(time.time()))
    except Exception:
        return

    def _job():
        try:
            log("prefetchEpg: start for {0}".format(url), 2)
            if not isFromCache(url + _EPG_RAW_SUFFIX, cache):
                if not _downloadToFile(
                    url, cachePath(url + _EPG_RAW_SUFFIX), timeout=120
                ):
                    log("prefetchEpg: download failed", 2)
                    return
            _parseAndCacheEpg(url, cachePath(url + _EPG_RAW_SUFFIX))
            log("prefetchEpg: done", 2)
        finally:
            DelFile(lock)

    threading.Thread(target=_job, daemon=False).start()

def _parseAndCacheEpg(url, rawFile):
    if not os.path.isfile(rawFile):
        log(
            "_parseAndCacheEpg: raw file missing {0}".format(rawFile), 2
        )
        return {}

    now = dt.now(timezone.utc).replace(tzinfo=None)
    wStart = now - timedelta(hours=2)
    wEnd = now + timedelta(hours=24)

    nList, dList, pDict = [], [], {}

    def _first_text(el, tag):
        for sub in el.iter(tag):
            t = (sub.text or "").strip()
            if t:
                return t
        return ""

    def _all_texts(el, tag):
        out = []
        for sub in el.iter(tag):
            t = (sub.text or "").strip()
            if t and t not in out:
                out.append(t)
        return out

    def _episodeNum(el):
        onscreen = ""
        ns = ""
        for sub in el.iter("episode-num"):
            t = (sub.text or "").strip()
            if not t:
                continue
            system = (sub.get("system") or "").lower()
            if system == "xmltv_ns" and not ns:
                ns = t
            elif not onscreen:
                onscreen = t
        if onscreen:
            m = _EPG_ONSCREEN_EP_RE.search(onscreen)
            if m:
                return int(m.group(1) or 0), int(m.group(2) or 0)
        if ns:
            parts = ns.split(".")
            try:
                season = int(parts[0].split("/")[0]) + 1 if parts[0].strip() else 0
            except (ValueError, IndexError):
                season = 0
            try:
                episode = (int(parts[1].split("/")[0]) + 1
                           if len(parts) > 1 and parts[1].strip() else 0)
            except (ValueError, IndexError):
                episode = 0
            return season, episode
        return 0, 0

    try:
        stream = _openXmlStream(rawFile)
    except Exception as ex:
        log(
            "_parseAndCacheEpg: cannot open {0}: {1}".format(rawFile, ex), 2
        )
        return {}

    try:
        context = ET.iterparse(stream, events=("start", "end"))
        _, root = next(context)

        for event, elem in context:
            if event != "end":
                continue

            if elem.tag == "channel":
                ch_id = elem.get("id", "")
                icon_el = elem.find("icon")
                icon = icon_el.get("src", "") if icon_el is not None else ""
                for dname in elem.iter("display-name"):
                    dn = (dname.text or "").strip()
                    if dn:
                        nList.append(dn)
                        dList.append((ch_id, icon))
                elem.clear()
                root.clear()

            elif elem.tag == "programme":
                start = elem.get("start", "")
                stop = elem.get("stop", "")
                sdt = xmltvTime(start)
                edt = xmltvTime(stop)
                if (sdt is None or edt is None
                        or edt < wStart or sdt > wEnd):
                    elem.clear()
                    root.clear()
                    continue

                ch_id = elem.get("channel", "")
                title = _first_text(elem, "title")
                if ch_id and title:
                    desc = _first_text(elem, "desc")
                    categories = _all_texts(elem, "category")
                    date = _first_text(elem, "date")
                    icon_el = elem.find("icon")
                    picon = (icon_el.get("src", "")
                             if icon_el is not None else "")
                    season, episode = _episodeNum(elem)
                    pDict.setdefault(ch_id, []).append(
                        (start, stop, title, desc, picon, categories,
                         date, season, episode)
                    )
                elem.clear()
                root.clear()
    except (ET.ParseError, Exception) as ex:
        log(
            "_parseAndCacheEpg: parse EXCEPTION for {0}: {1}".format(
                url, ex
            ), 2,
        )
    finally:
        try:
            stream.close()
        except Exception:
            pass

    if not nList:
        return {}

    idMap = {}
    normIdMap = {}
    normIdMulti = {}
    for i, (ch_id, icon) in enumerate(dList):
        idMap.setdefault(ch_id, (icon, i))
        nkey = normEpgId(ch_id)
        if nkey:
            normIdMap.setdefault(nkey, i)
            normIdMulti.setdefault(nkey, []).append(i)

    normMap = {}
    normMulti = {}
    for i, dn in enumerate(nList):
        key = normEpgName(dn)
        if key:
            normMap.setdefault(key, i)
            normMulti.setdefault(key, []).append(i)

    eDict = {"v": 5, "name": nList, "data": dList, "prg": pDict,
             "ids": idMap, "normids": normIdMap, "norm": normMap,
             "normidMulti": normIdMulti, "normMulti": normMulti}
    SaveList(cachePath(url + _EPG_PARSED_SUFFIX), eDict, indent=None)
    return eDict

def epg2dict(url, cache, noDownload=False):
    fn = cachePath(url + _EPG_PARSED_SUFFIX)

    fresh = cache > 0 and isFileNew(fn, cache * 60)
    if fresh and not url.startswith("http") and os.path.isfile(url):
        try:
            fresh = os.path.getmtime(fn) >= os.path.getmtime(url)
        except OSError:
            fresh = False

    if fresh:
        cached = ReadList(fn)
        if cached and "ids" in cached and cached.get("v") == 5:
            return cached

    if noDownload:
        stale = ReadList(fn)
        if stale and "ids" in stale and stale.get("v") == 5:
            return stale
        return {}

    if url.startswith("http"):
        rawFile = cachePath(url + _EPG_RAW_SUFFIX)
        if not isFromCache(url + _EPG_RAW_SUFFIX, cache):
            if not _downloadToFile(url, rawFile):
                stale = ReadList(fn)
                if stale and "ids" in stale and stale.get("v") == 5:
                    return stale
                return {}
    else:
        rawFile = url
        if not os.path.isfile(rawFile):
            return {}

    return _parseAndCacheEpg(url, rawFile)


_IPTVORG_KEY = "iptvorg://logos"

_IPTVORG_LOGOS_URL = "https://iptv-org.github.io/api/logos.json"

_IPTVORG_CHANNELS_URL = "https://iptv-org.github.io/api/channels.json"

def iptvLogosCacheNames():
    return [os.path.basename(cachePath(_IPTVORG_KEY + _EPG_PARSED_SUFFIX))]

def prefetchIptvLogos(cache=2880):
    if isFromCache(_IPTVORG_KEY + _EPG_PARSED_SUFFIX, cache):
        return

    lock = cachePath(_IPTVORG_KEY + _EPG_PARSED_SUFFIX) + ".lock"
    if isFileNew(lock, 600):
        return
    try:
        with open(lock, "w") as h:
            h.write(str(time.time()))
    except Exception:
        return

    def _job():
        try:
            log("prefetchIptvLogos: start", 2)
            _parseAndCacheIptvLogos()
            log("prefetchIptvLogos: done", 2)
        finally:
            DelFile(lock)

    threading.Thread(target=_job, daemon=False).start()

def _parseAndCacheIptvLogos():
    try:
        logos = json.loads(OpenURL(_IPTVORG_LOGOS_URL, timeout=60))
        channels = json.loads(OpenURL(_IPTVORG_CHANNELS_URL, timeout=60))
    except Exception as ex:
        log("_parseAndCacheIptvLogos: download failed: {0}".format(ex), 3)
        return {}
    if not isinstance(logos, list) or not isinstance(channels, list):
        log("_parseAndCacheIptvLogos: unexpected JSON shape", 3)
        return {}

    best = {}
    for entry in logos:
        if not isinstance(entry, dict):
            continue
        url = entry.get("url", "")
        fmt = (entry.get("format") or "").upper()
        if not url or fmt == "SVG" or url.lower().endswith(".svg"):
            continue
        cid = entry.get("channel", "")
        if not cid:
            continue
        in_use = bool(entry.get("in_use"))
        cur = best.get(cid)
        if cur is None or (in_use and not cur[0]):
            best[cid] = (in_use, url)

    ids = {cid: u for cid, (_, u) in best.items()}

    normIds = {}
    for cid, url in ids.items():
        nkey = normEpgId(cid)
        if nkey:
            normIds.setdefault(nkey, []).append(
                [epgCountryFromId(cid), url]
            )

    normNames = {}
    for ch in channels:
        if not isinstance(ch, dict):
            continue
        cid = ch.get("id", "")
        url = ids.get(cid)
        if not url:
            continue
        cc = epgCountryFromId(cid)
        for nm in [ch.get("name", "")] + list(ch.get("alt_names") or []):
            nkey = normEpgName(nm)
            if nkey:
                normNames.setdefault(nkey, []).append([cc, url])

    d = {"v": 1, "ids": ids, "normids": normIds, "normnames": normNames}
    SaveList(cachePath(_IPTVORG_KEY + _EPG_PARSED_SUFFIX), d, indent=None)
    log(
        "_parseAndCacheIptvLogos: ids={0} normids={1} normnames={2}".format(
            len(ids), len(normIds), len(normNames)
        ), 2,
    )
    return d

def iptvLogos(cache=2880):
    d = ReadList(cachePath(_IPTVORG_KEY + _EPG_PARSED_SUFFIX))
    if d and d.get("v") == 1 and "ids" in d:
        return d
    return {}

def iptvLogoLookup(d, name="", tvg_id=""):
    if not d:
        return ""
    ids = d.get("ids") or {}
    if tvg_id and tvg_id in ids:
        return ids[tvg_id]

    want = epgCountryFromId(tvg_id) or epgCountryFromName(name)

    def _pick(cands):
        if not cands:
            return ""
        if want:
            for cc, url in cands:
                if cc == want:
                    return url
        return cands[0][1]

    if tvg_id:
        url = _pick((d.get("normids") or {}).get(normEpgId(tvg_id)))
        if url:
            return url
    return _pick((d.get("normnames") or {}).get(normEpgName(name)))
