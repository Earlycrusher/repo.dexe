import xbmc, xbmcgui, xbmcvfs
import json
import os
import time
from threading import Thread
from modules.logger import logger
from modules.monitors.ratings import RatingsMonitor
from modules.monitors.image import ImageMonitor, ImageColorAnalyzer, ImageAnalysisConfig
from modules.monitors.live_search import LiveSearchMonitor
from modules.databases.ratings import RatingsDatabase
from modules.config import SETTINGS_PATH
from modules.select_view import VIEW_PREFERENCES_PATH

# Main loop cadence, in seconds. Every iteration reads several infolabels and
# conditions, each taking the graphics lock the render thread needs, so this is
# a direct tax on animation smoothness. Nothing here needs sub-300ms reaction:
# the fastest consumer is the altus.ctx.* publish that DialogContextMenu reads,
# and a context menu takes a long-press to open.
MAIN_LOOP_INTERVAL = 0.3
# Seconds between skin-version and Kodi-profile checks. The version only
# changes when the skin updates, and a profile switch restarts services — so
# this used to build an xbmcaddon.Addon every tick to watch for events that
# happen a handful of times a year. Ten seconds after an update is soon enough
# to regenerate the widget XML.
VERSION_CHECK_INTERVAL = 10


class Service(xbmc.Monitor):
    """Main service class that coordinates monitor and rating lookups."""

    def __init__(self):
        super().__init__()
        self._initialize()

    def _initialize(self):
        """Initialize service components."""
        if not xbmcvfs.exists(SETTINGS_PATH):
            xbmcvfs.mkdir(SETTINGS_PATH)
        self.home_window = xbmcgui.Window(10000)
        self.get_infolabel = xbmc.getInfoLabel
        self.get_visibility = xbmc.getCondVisibility
        current_config = ImageAnalysisConfig.from_skin_settings()
        self.image_monitor = ImageMonitor(ImageColorAnalyzer, current_config)
        self.ratings_monitor = RatingsMonitor(RatingsDatabase(), self.home_window)
        self.live_search_monitor = LiveSearchMonitor()
        self._last_addon_key = None
        self._last_content_type = None
        self._view_prefs_cache = {}
        self._view_prefs_mtime = 0
        self._last_history_refresh = 0.0
        self._history_was_sub_minute = False
        # 10s bucket the sub-minute labels were last rendered for.
        self._last_history_bucket = 0
        self._last_version_check = 0.0

    def run(self):
        """Start the service and monitor."""
        self.image_monitor.start()
        self.live_search_monitor.start()
        self._was_on_home = False
        while not self.abortRequested():
            on_home = (
                self.get_visibility("Window.IsVisible(home)")
                and xbmc.getSkinDir() == "skin.altus"
            )
            if on_home:
                now = time.monotonic()
                if now - self._last_version_check >= VERSION_CHECK_INTERVAL:
                    self._last_version_check = now
                    self._check_version_and_profile()
                self._check_stacked_widgets(on_home)
            else:
                self._was_on_home = False
            self._check_search_history_refresh()
            if self._should_pause():
                self.waitForAbort(2)
                continue
            # The MDbList key gates ratings and trailers only. It used to sit in
            # _should_pause, which also skipped per-addon views and the context
            # menu properties for anyone without a key.
            has_api_key = bool(self.get_infolabel("Skin.String(mdblist_api_key)"))
            self.ratings_monitor.process_current_item(fetch_ratings=has_api_key)
            self.monitor_addon_views()
            self.waitForAbort(MAIN_LOOP_INTERVAL)

    def _check_version_and_profile(self):
        """Check for skin updates and profile changes (runs in service loop)."""
        from modules.version_monitor import check_for_update, check_for_profile_change

        check_for_update("skin.altus")
        current_profile = self.get_infolabel("System.ProfileName")
        saved_profile = self.home_window.getProperty("skin.altus.current_profile")
        if current_profile != saved_profile:
            check_for_profile_change("skin.altus")

    def _check_stacked_widgets(self, on_home):
        """Init stacked widgets when home window loads (replaces onload RunScript)."""
        starting = self.home_window.getProperty("altus.starting_widgets")
        if self._was_on_home and starting:
            # Already initialised and still on home: needs_init below is False
            # whatever the setting says, so don't evaluate it every tick.
            return
        disable_reset = self.get_visibility("Skin.HasSetting(Disable.ResetStacked)")
        # Run when: property is empty (first load or after _reload_skin cleared it)
        # OR when returning to home and reset isn't disabled
        needs_init = not starting or (not self._was_on_home and not disable_reset)
        if needs_init:
            from modules.widget_manager.config_manager import ConfigManager
            from modules.widget_manager.xml_generator import _init_stacked_widgets

            cm = ConfigManager()
            config = cm.get_full_config()
            cm.close()
            _init_stacked_widgets(config)
        self._was_on_home = True

    def _load_view_preferences(self):
        """Load view preferences from JSON, using mtime-based cache."""
        try:
            mtime = os.path.getmtime(VIEW_PREFERENCES_PATH)
            if mtime != self._view_prefs_mtime:
                with open(VIEW_PREFERENCES_PATH, "r") as f:
                    self._view_prefs_cache = json.load(f)
                self._view_prefs_mtime = mtime
        except (FileNotFoundError, json.JSONDecodeError, IOError):
            self._view_prefs_cache = {}
        return self._view_prefs_cache

    def _apply_all_addon_views(self, addon_key, prefs):
        """Set all stored skin strings for an addon at once."""
        addon_prefs = prefs.get(addon_key, {})
        # Set skin strings for all saved content types
        for ct, saved_view in addon_prefs.items():
            if isinstance(saved_view, dict):
                xbmc.executebuiltin(
                    f'Skin.SetString(Skin.ForcedView.{ct},{saved_view["label"]})'
                )
        # Reset any content types this addon doesn't have saved
        all_content_types = set()
        for ap in prefs.values():
            if isinstance(ap, dict):
                all_content_types.update(ap.keys())
        for ct in all_content_types - set(addon_prefs.keys()):
            xbmc.executebuiltin(f"Skin.Reset(Skin.ForcedView.{ct})")

    def monitor_addon_views(self):
        """Apply saved per-addon view preferences when addon/content changes."""
        plugin_name = self.get_infolabel("Container.PluginName")
        content = self.get_infolabel("Container.Content")
        if content == "episodes":
            if self.get_visibility(
                "String.StartsWith(Container.PluginCategory,Season)"
            ):
                content_type = "episodes.inside"
            else:
                content_type = "episodes.outside"
        else:
            content_type = content

        addon_key = plugin_name if plugin_name else "__library__"
        addon_changed = addon_key != self._last_addon_key
        content_changed = content_type != self._last_content_type
        if not (addon_changed or content_changed):
            return
        # Only read once something changed — prefs are only used on a change,
        # and loading them costs a stat syscall even on a cache hit.
        prefs = self._load_view_preferences()

        if addon_changed:
            self._last_addon_key = addon_key
            self._apply_all_addon_views(addon_key, prefs)

        # Apply SetViewMode whenever addon or content changes — re-entering a
        # plugin from home keeps content_type="" on both sides, so we must also
        # react to addon changes or the view never gets switched back.
        if addon_changed or content_changed:
            self._last_content_type = content_type
            saved_view = prefs.get(addon_key, {}).get(content_type)
            if saved_view and isinstance(saved_view, dict):
                # Skin.SetString is async; wait for Skin.ForcedView.{ct} to
                # reflect the expected label before SetViewMode, or the view's
                # <visible> may still evaluate false and the switch gets dropped.
                expected = saved_view["label"]
                key = f"Skin.String(Skin.ForcedView.{content_type})"
                for _ in range(15):
                    if xbmc.getInfoLabel(key) == expected:
                        break
                    xbmc.sleep(20)
                xbmc.executebuiltin(f'Container.SetViewMode({saved_view["viewid"]})')

    def _check_search_history_refresh(self):
        """Re-humanize search-history .last labels.

        Default cadence is 60s. While the most recently committed entry is
        under a minute old, switches to 1s so the seconds counter advances
        live ("5 seconds ago" → "6 seconds ago"). Reverts to 60s once that
        entry crosses the minute mark.

        The humanized timestamp is computed once at write time and goes
        stale immediately. Refresh while a search-relevant window is
        visible so users see live values.
        """
        now = time.monotonic()
        most_recent_str = self.home_window.getProperty(
            "altus.search.history.most_recent_ts"
        )
        try:
            most_recent_ts = int(most_recent_str) if most_recent_str else 0
        except ValueError:
            most_recent_ts = 0
        sub_minute = bool(most_recent_ts and (int(time.time()) - most_recent_ts) < 60)
        # Transition from sub-minute → >=minute needs an immediate refresh so
        # "59 seconds ago" flips to "1 minute ago" without waiting a full 60s
        # for the slow-cadence timer to come around.
        just_crossed_minute = self._history_was_sub_minute and not sub_minute
        self._history_was_sub_minute = sub_minute
        if sub_minute:
            # Keyed to the 10s bucket _humanize_timestamp renders, not to
            # elapsed time. An elapsed-time interval drifts against the loop's
            # 0.2s tick, which is what made the old per-second counter skip.
            # Comparing the bucket itself means each one is rendered once, on
            # its boundary, however the ticks happen to land.
            current_bucket = int(time.time()) // 10
            if not just_crossed_minute and current_bucket == self._last_history_bucket:
                return
            self._last_history_bucket = current_bucket
        elif not just_crossed_minute and now - self._last_history_refresh < 60:
            # Drift is invisible at minute resolution, so the elapsed check is
            # fine here and avoids waking for a comparison every tick.
            return
        if xbmc.getSkinDir() != "skin.altus":
            return
        if not self.get_visibility("Window.IsVisible(1121)"):
            return
        count_str = self.home_window.getProperty("altus.search.history.count")
        try:
            count = int(count_str) if count_str else 0
        except ValueError:
            count = 0
        self._last_history_refresh = now
        if count == 0:
            return
        from modules.search_utils import SPaths

        SPaths().refresh_history_timestamps()

    def _should_pause(self):
        if self.home_window.getProperty("pause_services") == "true":
            return True
        if xbmc.getSkinDir() != "skin.altus":
            return True
        if not self.get_visibility(
            "Window.IsVisible(videos) | "
            "Window.IsVisible(home) | "
            "Window.IsVisible(1121) | "
            "Window.IsActive(movieinformation)"
        ):
            return True
        return False

    def onNotification(self, sender, method, data):
        """Handle Kodi notifications."""
        # logger(
        #     "Notification received - Sender: {}, Method: {}, Data: {}".format(
        #         sender, method, data
        #     ),
        #     1,
        # )
        if sender == "xbmc":
            if method in ("GUI.OnScreensaverActivated", "System.OnSleep"):
                self.home_window.setProperty("pause_services", "true")
            elif method in ("GUI.OnScreensaverDeactivated", "System.OnWake"):
                self.home_window.clearProperty("pause_services")


if __name__ == "__main__":
    service = Service()
    service.run()
