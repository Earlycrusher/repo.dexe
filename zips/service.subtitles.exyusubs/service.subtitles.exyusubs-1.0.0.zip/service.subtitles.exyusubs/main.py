# -*- coding: utf-8 -*-
import sys
import os
import re
import io
import time
import math
import codecs
import struct
import base64
import gzip
import zipfile
import requests
import urllib.parse
from urllib.parse import unquote
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon


# ============================================================
#  ADDON INFO
# ============================================================

ADDON        = xbmcaddon.Addon()
ADDON_ID     = ADDON.getAddonInfo('id')
ADDON_NAME   = ADDON.getAddonInfo('name')
ADDON_VER    = ADDON.getAddonInfo('version')
PROFILE      = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


# ============================================================
#  LANGUAGE CONFIGURATION
# ============================================================

# Kandidati za dekodiranje, poređani po verovatnoći za ex-yu titlove.
EXYU_ENCODINGS = [
    'cp1250',        # Windows centralna Evropa - najčešći za ex-yu latinicu
    'cp1251',        # Windows ćirilica - srpski/makedonski
    'iso-8859-2',    # Latin-2 - stariji ex-yu titlovi
    'cp1252',        # Windows zapadna Evropa - engleski
    'iso-8859-1',    # Latin-1 - engleski
    'iso-8859-5',    # ISO ćirilica
    'cp852',         # DOS centralna Evropa - vrlo stari titlovi
    'mac_latin2',    # Mac centralna Evropa
]

# Slova koja OČEKUJEMO u ex-yu latiničnom tekstu
EXYU_LATIN_CHARS = set('čćžšđČĆŽŠĐ')

# Ćirilica (srpska + makedonska) - legitimna ako je tekst pretežno ćiriličan
EXYU_CYRILLIC_CHARS = set(
    'абвгдђежзијклљмнњопрстћуфхцчџшАБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШ'
    'ѓѕќѐѝЃЅЌЀЍ'
)

# Znakovi koji su gotovo sigurno posledica pogrešnog dekodiranja
SUSPICIOUS_CHARS = set(
    'ÐðÞþÝýÿ¤¦©«¬®¯°±µ¶·¸¹º»¼½¾¿×÷'
    'àâãäåæçèêëìîïñòôõöøùûüÀÂÃÄÅÆÇÈÊËÌÎÏÑÒÔÕÖØÙÛÜ'
    'ЉЊЂЋЏљњ'
)

# Podržani formati titlova - koriste se pri raspakivanju arhiva
# i pri čišćenju temp foldera. Kodi bira parser po ekstenziji,
# pa je važno da sačuvamo pravi format.
SUB_EXTENSIONS = ('.srt', '.sub', '.ssa', '.ass', '.vtt', '.smi')

# Regex za detekciju hearing impaired (SDH/CC) titlova iz naziva fajla
# Koristi se kao fallback jer OS SubHearingImpaired flag često nije ispravno popunjen
SDH_PATTERN = re.compile(r'\b(sdh|cc|hearing.?impaired|closed.?caption)\b', re.IGNORECASE)

# lang_code služi i za Kodi oznaku jezika i za zastavicu
EXYU_LANGUAGES = [
    {'lang_code': 'sr', 'label': 'Serbian',     'stremio': ['srp', 'scc'], 'rest': ['scc']},
    {'lang_code': 'sr', 'label': 'Montenegrin', 'stremio': ['mne'],        'rest': ['mne']},
    {'lang_code': 'bs', 'label': 'Bosnian',     'stremio': ['bos'],        'rest': ['bos']},
    {'lang_code': 'hr', 'label': 'Croatian',    'stremio': ['hrv'],        'rest': ['hrv']},
    {'lang_code': 'sl', 'label': 'Slovenian',   'stremio': ['slv'],        'rest': ['slv']},
    {'lang_code': 'mk', 'label': 'Macedonian',  'stremio': ['mkd', 'mac'], 'rest': ['mac']},
]

# Engleski se drži van glavne liste - koristi se samo kao rezervna
# pretraga kada za izabrane jezike nema nijednog titla
ENGLISH_LANGUAGE = {
    'lang_code': 'en', 'label': 'English', 'stremio': ['eng'], 'rest': ['eng']
}


# ============================================================
#  API CONFIGURATION
# ============================================================

# TMDB - za fallback kada nema IMDB ID
TMDB_API_KEY  = base64.b64decode("OGFkM2MyMWE5MmE2NGRhODMyYzU1OWQ1OGNjNjNhYjQ=").decode()
TMDB_BASE_URL = "https://api.themoviedb.org/3"

# Stremio OpenSubtitles v3 wrapper - primarni izvor titlova
STREMIO_BASE_URL = "https://opensubtitles-v3.strem.io/subtitles"

# OpenSubtitles.org XML-RPC - fallback ako Stremio nije dostupan
OPENSUB_XMLRPC_URL = "https://api.opensubtitles.org/xml-rpc"
OPENSUB_USER_AGENT = f"{ADDON_NAME} v{ADDON_VER}"

# OpenSubtitles.org stari REST - za dohvatanje pravih imena fajlova
OPENSUB_REST_URL   = "https://rest.opensubtitles.org/search"


# ============================================================
#  HTTP HEADERS
# ============================================================
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.3'
}


# ============================================================
#  BEHAVIOR OPTIONS
# ============================================================

# True = titl se konvertuje u UTF-8 pre snimanja (preporučeno)
CONVERT_TO_UTF8 = True

# Maksimalan broj titlova prikazanih u listi po prolazu pretrage.
# 0 ili None = bez ograničenja
MAX_RESULTS = 100

# True  = koristi se interna lista jezika (EXYU_LANGUAGES)
# False = koriste se jezici izabrani u Kodi podešavanjima za titlove
USE_INTERNAL_LANGUAGES = True

# True  = ako nijedan titl nije nađen za izabrane jezike, pokušava se
#         još jedna pretraga na engleskom
# False = bez dodatne pretrage, lista ostaje prazna
FALLBACK_TO_ENGLISH = True

# True  = određuje se da li je titl sinhronizovan sa videom koji se pušta
#         i pali se 'sync' ikona u Kodi dijalogu
# False = sync ikona se nikad ne pali
DETECT_SYNC = True

# Sheme putanja za koje se NE računa OpenSubtitles hash.
# Računanje traži čitanje prvih i zadnjih 64 KB, što kod debrid linkova
# i drugih streamova znači dva spora mrežna zahteva i osetno kašnjenje
# liste titlova. Za takve izvore ostaje heuristika po nazivu izdanja.
NO_HASH_SCHEMES = (
    'plugin://', 'http://', 'https://', 'ftp://', 'ftps://',
    'rtmp://', 'rtmpe://', 'rtsp://', 'udp://', 'rtp://',
    'upnp://', 'pvr://', 'stack://', 'sftp://', 'dav://', 'davs://',
)

# Tagovi izvora ripa, grupisani u porodice.
SOURCE_FAMILIES = {
    'web':       ['web-dl', 'webdl', 'web.dl', 'webrip', 'web-rip', 'web.rip',
                  'amzn', 'nf', 'dsnp', 'hmax', 'atvp', 'itunes', 'it.web',
                  'ma.web', 'pcok', 'stan', 'crav', 'hulu', 'red', 'web'],
    'disc':      ['bluray', 'blu-ray', 'blu.ray', 'bdrip', 'brrip', 'bdmux',
                  'bdremux', 'uhdremux', 'uhd.bluray', 'remux', 'bdrip',
                  'hddvd', 'dvdrip', 'dvd5', 'dvd9', 'dvdr', 'dvd'],
    'tv':        ['hdtv', 'pdtv', 'sdtv', 'dsr', 'dvbrip', 'dvbc', 'dvbs',
                  'ahdtv', 'uhdtv'],
    'cam':       ['telesync', 'hdts', 'ts.', 'cam.', 'camrip', 'hdcam',
                  'telecine', 'tc.', 'screener', 'dvdscr', 'bdscr', 'scr.',
                  'workprint', 'r5', 'vhsrip'],
}

# Ostali tagovi - rezolucija, kodek, zvuk, varijante izdanja.
# Slabiji pojedinačni signal od izvora, pa se broje kumulativno.
RELEASE_TAGS = [
    # Rezolucija
    '2160p', '1080p', '1080i', '720p', '576p', '480p', '4k', 'uhd',
    # Video kodek
    'x264', 'x265', 'h264', 'h265', 'h.264', 'h.265', 'hevc', 'avc',
    'xvid', 'divx', 'av1', '10bit', '8bit',
    # Opseg boja
    'hdr10', 'hdr', 'dovi', 'dv', 'sdr', 'hlg',
    # Zvuk
    'atmos', 'truehd', 'ddp5', 'ddp', 'dd5', 'eac3', 'ac3', 'aac',
    'dts-hd', 'dtshd', 'dts', 'flac', 'opus', '7.1', '5.1', '2.0',
    # Varijante izdanja
    'proper', 'repack', 'rerip', 'internal', 'limited',
    'extended', 'unrated', 'uncut', 'directors', 'theatrical',
    'remastered', 'imax', 'open.matte', 'hybrid',
    # Jezičke varijante
    'dual', 'multi', 'dubbed', 'subbed',
]

# Prag poklapanja kada izvor NIJE prepoznat ni u jednom nazivu
SYNC_TAG_THRESHOLD = 3

# Blazi prag kada se porodica izvora poklopi - tada je dovoljan
# još jedan pokazatelj (rezolucija, kodek ili zvuk)
SYNC_TAG_THRESHOLD_SAME_SOURCE = 1


# ============================================================
#  TIMEOUTS  (seconds)
# ============================================================

TIMEOUT_STREMIO  = 7
TIMEOUT_TMDB     = 5
TIMEOUT_REST     = 5
TIMEOUT_XMLRPC   = 10
TIMEOUT_DOWNLOAD = 15


# ============================================================
#  RETRY CONFIGURATION
# ============================================================

RETRY_COUNT = 2      # broj ponovnih pokušaja za Stremio
RETRY_DELAY = 1.5    # sekundi između pokušaja

REST_RETRY_COUNT = 1     # jedan ponovni pokušaj
REST_RETRY_DELAY = 2.0   # sekundi pre ponovnog pokušaja


# ============================================================
#  LOGGING
# ============================================================

DEBUG = False

def log(msg, level=xbmc.LOGINFO):
    if DEBUG:
        xbmc.log(f"### [{ADDON_ID}] {msg}", level)

def log_error(msg):
    xbmc.log(f"### [{ADDON_ID}] ERROR: {msg}", xbmc.LOGERROR)


# ============================================================
#  TITLE CLEANUP
# ============================================================

def clean_title_for_search(title):
    if not title or not isinstance(title, str):
        return "", None

    title = re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\[/?(B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE)\]', '', title, flags=re.IGNORECASE)
    title = re.sub(r'<[^>]+>', '', title)

    year = None

    try:
        clean, year_str = xbmc.getCleanMovieTitle(title)
        if clean and clean.strip():
            title = clean.strip()
        if year_str and year_str.isdigit() and 1900 <= int(year_str) <= 2100:
            year = int(year_str)
    except Exception:
        title = title.strip()

    title = re.sub(r'\s*S\d{1,2}E\d{1,2}.*', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\s*Season\s*\d+.*', '', title, flags=re.IGNORECASE)

    if not year:
        m = re.search(r'[\(\[]((?:19|20)\d{2})[\)\]]', title)
        if m:
            year = int(m.group(1))

    title = re.sub(r'\s*[\(\[](?:19|20)\d{2}[\)\]]', '', title)
    title = re.sub(r'[\._]', ' ', title)
    title = re.sub(r'\s+', ' ', title).strip()

    log(f"clean_title_for_search: '{title}' year={year}")
    return title, year


# ============================================================
#  TMDB - TV SHOW
# ============================================================

def get_series_imdb_id(query, year=None):
    try:
        clean_name, extracted_year = clean_title_for_search(query)

        if not clean_name:
            log_error("get_series_imdb_id: empty title after cleanup")
            return None

        search_year = year or extracted_year

        log(f"TMDB TV search: '{clean_name}'" + (f" year={search_year}" if search_year else ""))

        r = requests.get(
            f"{TMDB_BASE_URL}/search/tv",
            params={"api_key": TMDB_API_KEY, "query": clean_name},
            timeout=TIMEOUT_TMDB
        ).json()

        results = r.get('results', [])
        if not results:
            log(f"TMDB TV: no results for '{clean_name}'")
            return None

        best = results[0]
        if search_year and len(results) > 1:
            for result in results:
                air_date = result.get('first_air_date', '')
                if air_date and str(search_year) in air_date:
                    best = result
                    log(f"TMDB TV: year match on '{result.get('name', '')}' ({air_date})")
                    break

        tmdb_id = best['id']
        log(f"TMDB TV: selected tmdb_id={tmdb_id} '{best.get('name', '')}'")

        ext_r = requests.get(
            f"{TMDB_BASE_URL}/tv/{tmdb_id}/external_ids",
            params={"api_key": TMDB_API_KEY},
            timeout=TIMEOUT_TMDB
        ).json()

        imdb = ext_r.get('imdb_id', '')
        if not imdb or not imdb.startswith('tt'):
            log(f"TMDB TV: no valid IMDB ID for tmdb_id={tmdb_id}")
            return None

        log(f"TMDB TV: resolved IMDB ID={imdb}")
        return imdb

    except Exception as e:
        log_error(f"get_series_imdb_id: {str(e)}")
        return None


# ============================================================
#  TMDB - MOVIE
# ============================================================

def get_movie_imdb_id(query, year=None):
    try:
        clean_name, extracted_year = clean_title_for_search(query)

        if not clean_name:
            log_error("get_movie_imdb_id: empty title after cleanup")
            return None

        search_year = year or extracted_year

        log(f"TMDB Movie search: '{clean_name}'" + (f" year={search_year}" if search_year else ""))

        r = requests.get(
            f"{TMDB_BASE_URL}/search/movie",
            params={"api_key": TMDB_API_KEY, "query": clean_name},
            timeout=TIMEOUT_TMDB
        ).json()

        results = r.get('results', [])
        if not results:
            log(f"TMDB Movie: no results for '{clean_name}'")
            return None

        best = results[0]
        if search_year and len(results) > 1:
            for result in results:
                release_date = result.get('release_date', '')
                if release_date and str(search_year) in release_date:
                    best = result
                    log(f"TMDB Movie: year match on '{result.get('title', '')}' ({release_date})")
                    break

        tmdb_id = best['id']
        log(f"TMDB Movie: selected tmdb_id={tmdb_id} '{best.get('title', '')}'")

        ext_r = requests.get(
            f"{TMDB_BASE_URL}/movie/{tmdb_id}/external_ids",
            params={"api_key": TMDB_API_KEY},
            timeout=TIMEOUT_TMDB
        ).json()

        imdb = ext_r.get('imdb_id', '')
        if not imdb or not imdb.startswith('tt'):
            log(f"TMDB Movie: no valid IMDB ID for tmdb_id={tmdb_id}")
            return None

        log(f"TMDB Movie: resolved IMDB ID={imdb}")
        return imdb

    except Exception as e:
        log_error(f"get_movie_imdb_id: {str(e)}")
        return None


# ============================================================
#  OS REST API - FILENAMES AND RATING
# ============================================================

def get_detailed_subtitle_names(imdb_id, season=None, episode=None, rest_codes=None):
    # Vraća dict {IDSubtitle: {'filename': ..., 'rating': ..., 'ai': ..., 'forced': ..., 'featured': ..., 'trusted': ...}}
    mapping = {}
    if not imdb_id:
        return mapping

    try:
        numeric_id = imdb_id.replace('tt', '')

        if season and episode:
            rest_url = f"{OPENSUB_REST_URL}/episode-{episode}/imdbid-{numeric_id}/season-{season}"
        else:
            rest_url = f"{OPENSUB_REST_URL}/imdbid-{numeric_id}"

        log(f"REST API request: {rest_url}")

        # Jedan ponovni pokušaj na 5xx greške i timeout. Klijentske greške (4xx) se ne ponavljaju jer se neće popraviti.
        response = None
        for attempt in range(1, REST_RETRY_COUNT + 2):
            try:
                response = requests.get(rest_url, headers=HEADERS,
                                        timeout=TIMEOUT_REST)
                if response.status_code < 500:
                    break
                log(f"REST API: HTTP {response.status_code}, retrying...")
            except requests.exceptions.Timeout:
                log(f"REST API: timeout on attempt {attempt}")
                response = None
            except Exception as e:
                log(f"REST API: error on attempt {attempt}: {e}")
                response = None
                break   # neočekivana greška - nema smisla ponavljati

            if attempt <= REST_RETRY_COUNT:
                time.sleep(REST_RETRY_DELAY)

        if response is None:
            log(f"REST API: no response for imdbid={numeric_id}")
            return mapping

        if not response.ok:
            log(f"REST API: HTTP {response.status_code} for imdbid={numeric_id}")
            return mapping

        data = response.json()
        if not isinstance(data, list):
            log(f"REST API: unexpected response format")
            return mapping

        # rest_codes=None znači BEZ filtera - koristi se kad rezultat keširamo za više jezičkih prolaza, pa se filtrira pri prikazu
        valid_langs = set(rest_codes) if rest_codes else None
        for item in data:
            if valid_langs is not None and item.get('SubLanguageID') not in valid_langs:
                continue
            sub_id    = str(item.get('IDSubtitle', ''))
            file_name = item.get('SubFileName', '')
            if sub_id and file_name:
                try:
                    rating = str(int(math.floor(float(item.get('SubRating', '0') or '0') / 2 + 0.5)))
                except Exception:
                    rating = '0'
                # Uklanjamo ekstenziju iz naziva
                base_name, _ = os.path.splitext(file_name)
                # SubHearingImpaired flag je često netačno popunjen - dodatno proveravamo i naziv fajla regexom (SDH, CC, hearing impaired)
                hi_flag = str(item.get('SubHearingImpaired', '0')) == '1'
                is_sdh  = hi_flag or bool(SDH_PATTERN.search(file_name.lower()))
                # Trusted flag se čuva posebno od ranga - ako flag postoji prikazujemo [Trusted], ako ne ali ima rang prikazujemo rang
                from_trusted = str(item.get('SubFromTrusted', '0')) == '1'
                user_rank    = str(item.get('UserRank', '') or '').strip()
                mapping[sub_id] = {
                    'filename':    base_name,
                    'rating':      rating,
                    'ai':          str(item.get('SubAutoTranslation', '0')) == '1',
                    'forced':      str(item.get('SubForeignPartsOnly', '0')) == '1',
                    'featured':    str(item.get('SubFeatured', '0')) == '1',
                    'trusted':     from_trusted,
                    'user_rank':   user_rank,
                    'hearing_imp': is_sdh,
                    'downloads':   item.get('SubDownloadsCnt', '0'),
                    # Za sync detekciju u Stremio toku
                    'release':     item.get('MovieReleaseName', '') or '',
                    'fps':         item.get('MovieFPS', '') or '',
                    # Komentar uploadera često sadrži spisak svih izdanja za koja titl odgovara - najbogatiji izvor za sync
                    'comment':     item.get('SubAuthorComment', '') or '',
                }

        log(f"REST API: mapped {len(mapping)} filenames for imdbid={numeric_id}")

    except Exception as e:
        log_error(f"get_detailed_subtitle_names: {str(e)}")

    return mapping


# ============================================================
#  IMDB ID + METADATA DETECTION
#  Grana se na dva toka:
#    - Player aktivan   -> VideoPlayer.* InfoLabels (najpouzdanije)
#    - Player neaktivan -> ListItem.* InfoLabels
#  Ovo izbegava greške kada se pretraga titlova pokrene iz
#  konteksta liste (npr. provera dostupnosti titla) pre puštanja
# ============================================================

def get_media_info():
    info = {
        'imdb_id': None,
        'title':   None,
        'season':  None,
        'episode': None,
        'year':    None,
    }

    junk_ids = {'', 'None', '0', 'VideoPlayer.IMDBNumber', 'VideoPlayer.TMDbId', 'VideoPlayer.TVShow.TMDbId', 'ListItem.IMDBNumber'}

    def is_valid_imdb(val):
        return val and str(val) not in junk_ids and str(val).startswith('tt')

    def clean_imdb(val):
        val = str(val).strip()
        if val in junk_ids:
            return None
        if val.isdigit():
            return f"tt{val}"
        if val.startswith('tt'):
            return val
        return None

    try:
        is_playing = xbmc.Player().isPlaying()
    except Exception:
        is_playing = False

    log(f"get_media_info: player active={is_playing}")

    if is_playing:
        # ----------------------------------------------------------
        # 1. VideoInfoTag - najpouzdaniji izvor u Kodi 19+ dok je
        #    video aktivan. getUniqueID('imdb') ne može da vrati
        #    TMDB ID greškom
        # ----------------------------------------------------------
        try:
            tag = xbmc.Player().getVideoInfoTag()
            imdb = tag.getUniqueID('imdb')
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from VideoInfoTag: {imdb}")

            info['title'] = tag.getTVShowTitle() or tag.getTitle()
            # getSeason()/getEpisode() vraćaju -1 ako nema vrednosti, ne None
            # -1 je truthy pa bi 'or None' propustio -1 i film tretirao kao seriju
            s = tag.getSeason()
            info['season']  = s if isinstance(s, int) and s > 0 else None
            e = tag.getEpisode()
            info['episode'] = e if isinstance(e, int) and e > 0 else None
            y = tag.getYear()
            info['year']    = y if isinstance(y, int) and y > 0 else None
        except Exception as e:
            log_error(f"get_media_info VideoInfoTag: {str(e)}")

        # ----------------------------------------------------------
        # 2. VideoPlayer.* InfoLabels - fallback za IMDB ID i title
        #    VideoPlayer.IMDBNumber može vratiti TMDB ID - proveravamo tt prefix
        # ----------------------------------------------------------
        if not info['imdb_id']:
            imdb = clean_imdb(xbmc.getInfoLabel('VideoPlayer.IMDBNumber'))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from InfoLabel VideoPlayer.IMDBNumber: {imdb}")

        if not info['title']:
            info['title'] = (xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or
                             xbmc.getInfoLabel('VideoPlayer.OriginalTitle') or
                             xbmc.getInfoLabel('VideoPlayer.Title'))

        if not info['season']:
            s = xbmc.getInfoLabel('VideoPlayer.Season')
            info['season'] = int(s) if s and s.isdigit() and s != '0' else None

        if not info['episode']:
            e = xbmc.getInfoLabel('VideoPlayer.Episode')
            info['episode'] = int(e) if e and e.isdigit() else None

        if not info['year']:
            y = xbmc.getInfoLabel('VideoPlayer.Year')
            info['year'] = int(y) if y and y.isdigit() else None

        # ----------------------------------------------------------
        # 3. Ekstrakcija iz URL-a - regex po tt pattern-u
        #    Neki streaming addoni stavljaju IMDB ID u URL
        # ----------------------------------------------------------
        if not info['imdb_id']:
            try:
                file_path = unquote(xbmc.Player().getPlayingFile())
                m = re.search(r'(?:media_id|imdb|imdb_id)=(tt\d+)', file_path, re.IGNORECASE)
                if not m:
                    m = re.search(r'/(tt\d+)(?:/|$|\?)', file_path)
                if m:
                    info['imdb_id'] = m.group(1)
                    log(f"IMDB ID from URL: {info['imdb_id']}")
            except Exception as e:
                log_error(f"get_media_info URL parse: {str(e)}")

    else:
        # ----------------------------------------------------------
        # 1. ListItem.* InfoLabels - koriste se kad player NIJE aktivan
        #    npr. provera dostupnosti titla iz liste, pre puštanja.
        #    Redosled: zvanični Kodi standardi prvo, pa najčešći
        #    custom property nazivi koje video addoni koriste
        # ----------------------------------------------------------
        imdb = clean_imdb(xbmc.getInfoLabel('ListItem.IMDBNumber'))
        if is_valid_imdb(imdb):
            info['imdb_id'] = imdb
            log(f"IMDB ID from ListItem.IMDBNumber: {imdb}")

        if not info['imdb_id']:
            imdb = clean_imdb(xbmc.getInfoLabel('ListItem.UniqueID(imdb)'))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from ListItem.UniqueID(imdb): {imdb}")

        if not info['imdb_id']:
            imdb = clean_imdb(xbmc.getInfoLabel('ListItem.Property(imdb_id)'))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from ListItem.Property(imdb_id): {imdb}")

        if not info['imdb_id']:
            imdb = clean_imdb(xbmc.getInfoLabel('ListItem.Property(imdbnumber)'))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from ListItem.Property(imdbnumber): {imdb}")

        info['title'] = (xbmc.getInfoLabel('ListItem.TVShowTitle') or
                         xbmc.getInfoLabel('ListItem.OriginalTitle') or
                         xbmc.getInfoLabel('ListItem.Title'))

        s = xbmc.getInfoLabel('ListItem.Season')
        info['season'] = int(s) if s and s.isdigit() and s != '0' else None

        e = xbmc.getInfoLabel('ListItem.Episode')
        info['episode'] = int(e) if e and e.isdigit() else None

        y = xbmc.getInfoLabel('ListItem.Year')
        info['year'] = int(y) if y and y.isdigit() else None

    # ----------------------------------------------------------
    # Window Properties - radi u oba slučaja, neki addoni
    # pišu IMDB ID ovde bez obzira na stanje playera
    # ----------------------------------------------------------
    if not info['imdb_id']:
        home = xbmcgui.Window(10000)
        for prop in ('IMDb', 'imdb_id', 'imdbid'):
            imdb = clean_imdb(home.getProperty(prop))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from Window Property '{prop}': {imdb}")
                break

    # ----------------------------------------------------------
    # TMDB Fallback - ako ništa nije dalo IMDB ID
    # Koristimo naslov za pretragu na TMDB koji vraća IMDB ID
    # Radi identično bez obzira na stanje playera
    # ----------------------------------------------------------
    if not info['imdb_id'] and info['title']:
        log("No IMDB ID found, initiating TMDB fallback...")
        is_series = bool(info['season'] and info['episode'])
        if is_series:
            info['imdb_id'] = get_series_imdb_id(info['title'], info['year'])
        else:
            info['imdb_id'] = get_movie_imdb_id(info['title'], info['year'])

        if info['imdb_id']:
            log(f"IMDB ID from TMDB fallback: {info['imdb_id']}")
        else:
            log_error("get_media_info: could not find IMDB ID by any means")

    log(f"get_media_info result: {info}")
    return info


# ============================================================
#  HELPER - OPENSUBTITLES VIDEO HASH
#  Kanonski način utvrđivanja sinhronizacije: OS vraća
#  MatchedBy='moviehash' samo za titlove uploadovane baš za
#  taj video fajl. Algoritam (zvanična OS specifikacija):
#    hash = veličina + zbir prvih 64KB + zbir zadnjih 64KB,
#    svaki 8-bajtni blok kao little-endian uint64, po modulu 2^64
#  Vraća (hash_hex, veličina) ili (None, None) ako nije moguće.
# ============================================================

OS_HASH_CHUNK = 65536          # 64 KB
OS_HASH_MIN_SIZE = 131072      # OS zahteva fajl veći od 128 KB

def compute_os_hash(file_path):
    if not file_path or not isinstance(file_path, str):
        return None, None

    low = file_path.lower()
    if low.startswith(NO_HASH_SCHEMES):
        scheme = low.split('://', 1)[0] + '://'
        log(f"compute_os_hash: skipping hash for stream source ({scheme})")
        return None, None

    f = None
    try:
        f = xbmcvfs.File(file_path)
        size = f.size()

        if not size or size < OS_HASH_MIN_SIZE:
            log(f"compute_os_hash: file too small or size unknown ({size})")
            return None, None

        hash_val = size & 0xFFFFFFFFFFFFFFFF

        def add_chunk(buf):
            nonlocal hash_val
            # Obrađujemo samo cele 8-bajtne blokove
            usable = len(buf) - (len(buf) % 8)
            for i in range(0, usable, 8):
                (val,) = struct.unpack('<Q', buf[i:i + 8])
                hash_val = (hash_val + val) & 0xFFFFFFFFFFFFFFFF

        # Prvih 64 KB
        f.seek(0, 0)
        add_chunk(f.readBytes(OS_HASH_CHUNK))

        # Zadnjih 64 KB
        f.seek(size - OS_HASH_CHUNK, 0)
        add_chunk(f.readBytes(OS_HASH_CHUNK))

        # OS traži tačno 16 znakova sa vodećim nulama
        hash_hex = f"{hash_val:016x}"
        log(f"compute_os_hash: hash={hash_hex} size={size}")
        return hash_hex, size

    except Exception as e:
        log(f"compute_os_hash: failed ({e})")
        return None, None
    finally:
        if f is not None:
            try:
                f.close()
            except Exception:
                pass


# ============================================================
#  HELPER - SYNC HEURISTIC BY RELEASE NAME
#  Koristi se kada nemamo potvrdu preko moviehash-a
#  (Stremio izvor ili titl matchovan samo po imdbid).
#  Poredi tagove izdanja i naziv release grupe.
# ============================================================

def extract_release_groups(text):
    """
    Vraca SKUP svih release grupa pronadjenih u tekstu.

    Jedan titl cesto odgovara vecem broju izdanja, a OS to zapisuje
    na tri nacina: u MovieReleaseName (ponekad vise njih), u nazivu
    fajla, i vrlo cesto u komentaru uploadera gdje bude izlistano
    i po desetak kompatibilnih izdanja. Zato ne trazimo jednu grupu
    nego sve, pa poredimo da li se ijedna poklapa sa videom.
    """
    if not text:
        return set()

    groups = set()

    # Tekst može biti višelinijski spisak izdanja - obrađujemo red po red
    for line in re.split(r'[\r\n,;]+', str(text)):
        line = line.strip()
        if len(line) < 6:
            continue

        # Uklanjamo poznate ekstenzije
        base = re.sub(r'\.(srt|sub|ssa|ass|txt|mkv|mp4|avi|mov|m2ts)$', '',
                      line, flags=re.IGNORECASE)

        # Skidamo jezičke i SDH markere sa kraja
        marker = r'(sdh|cc|hi|forced|eng|en|ser|srp|scc|hrv|hr|bos|slv|mac)'
        for _ in range(3):
            new = re.sub(r'[\.\-_\s]*\[' + marker + r'\]\s*$', '', base, flags=re.IGNORECASE)
            new = re.sub(r'[\.\-_]' + marker + r'\s*$', '', new, flags=re.IGNORECASE)
            if new == base:
                break
            base = new

        # Grupa u uglastim zagradama, bilo gde u redu
        for m in re.finditer(r'\[([A-Za-z0-9.]{3,})\]', base):
            groups.add(m.group(1).lower())

        # Grupa iza crtice na kraju reda
        m = re.search(r'-([A-Za-z0-9]{3,})\s*$', base)
        if m:
            groups.add(m.group(1).lower())

    # Uklanjamo vrednosti koje su zapravo tagovi, ne nazivi grupa. Proveravamo obe liste - i opšte tagove i oznake izvora.
    source_tags = {t.strip('.') for tags in SOURCE_FAMILIES.values() for t in tags}
    bogus = set(RELEASE_TAGS) | source_tags
    return {g for g in groups if g not in bogus}


def detect_source_family(text):
    """
    Vraca naziv porodice izvora ('web', 'disc', 'tv', 'cam') ili ''.
    Ako se u tekstu pojavi vise porodica, bira onu cija se oznaka
    javlja ranije - obicno je to stvarni izvor, a kasnije oznake
    su ostaci iz naziva prethodnog izdanja.
    """
    if not text:
        return ''
    low = str(text).lower().replace('_', '.').replace(' ', '.')

    best_family, best_pos = '', len(low) + 1
    for family, tags in SOURCE_FAMILIES.items():
        for tag in tags:
            pos = low.find(tag)
            if pos != -1 and pos < best_pos:
                best_family, best_pos = family, pos
    return best_family


def get_video_name_for_match():
    """
    Vraca naziv videa upotrebljiv za poredjenje sa nazivom izdanja.
    Kod debrid izvora putanja zna biti samo hash ili UUID bez ikakvog
    naziva (npr. TorBox), pa probavamo vise izvora redom i biramo prvi
    koji stvarno lici na naziv izdanja.
    """
    def usable(name):
        if not name:
            return ''
        base = os.path.basename(str(name).split('?')[0]).strip()
        # Naziv izdanja ima razdvajače i razumnu dužinu
        if len(base) < 10 or not re.search(r'[._\- ]', base):
            return ''
        # Odbacujemo čiste hash/UUID nizove - nemaju ništa za poređenje
        stripped = re.sub(r'[^A-Za-z0-9]', '', base)
        if len(stripped) >= 16 and not re.search(r'(19|20)\d{2}', base):
            # dug niz bez godine i bez poznatog taga je verovatno hash
            low = base.lower()
            has_tag = any(t in low for t in ('1080', '2160', '720', 'web', 'blu', 'hdtv', 'x264', 'x265'))
            if not has_tag:
                return ''
        return base

    candidates = []

    # 1. Stvarna putanja fajla
    try:
        candidates.append(unquote(xbmc.Player().getPlayingFile()))
    except Exception:
        pass

    # 2. Oznaka stavke koja se pušta - video addoni tu često stave puni naziv izdanja koji su prikazali u izboru izvora
    try:
        item = xbmc.Player().getPlayingItem()
        candidates.append(item.getLabel())
        candidates.append(item.getLabel2())
        for prop in ('release_title', 'releaseTitle', 'release', 'source_name', 'filename', 'name'):
            try:
                candidates.append(item.getProperty(prop))
            except Exception:
                pass
    except Exception:
        pass

    # 3. InfoLabels koje zadržavaju originalni naziv i kad je izvor stream
    for lbl in ('Player.Filename',
                'ListItem.FilenameAndPath',
                'ListItem.Filename',
                'ListItem.Label',
                'Player.Title',
                'VideoPlayer.Title'):
        try:
            candidates.append(xbmc.getInfoLabel(lbl))
        except Exception:
            pass

    for c in candidates:
        got = usable(c)
        if got:
            log(f"sync: video name for matching -> {got}")
            return got

    log("sync: no usable video name found, release matching disabled")
    return ''


def is_release_match(candidates, video_name, sub_fps=None, video_fps=None):
    """
    candidates - lista tekstova koji mogu sadrzati nazive izdanja:
    MovieReleaseName, naziv fajla titla, komentar uploadera.
    Jedan titl cesto odgovara vecem broju izdanja, pa sakupljamo
    grupe iz svih izvora i trazimo bilo koje poklapanje sa videom.
    """
    if isinstance(candidates, str):
        candidates = [candidates]
    elif not isinstance(candidates, (list, tuple, set)):
        return False
    candidates = [str(c) for c in candidates if c and str(c).strip()]

    if not candidates or not video_name:
        return False

    vid = os.path.basename(str(video_name)).lower()
    vid = vid.replace('_', '.').replace(' ', '.')

    # Video naziv mora imati bar nešto upotrebljivo
    if len(vid) < 8:
        return False

    # 1. Sve grupe iz svih izvora - jedno poklapanje je dovoljno.
    #    Ista grupa obično znači isti izvor i isti tajming, pa vredi
    #    i kad se rezolucija razlikuje (1080p titl za 2160p video).
    #    Grupa je POUZDANIJA od MovieFPS polja, koje uploaderi često
    #    ostave prazno ili pogrešno, pa poklapanje grupe ide pre
    #    FPS provere i ne može biti poništeno njome.
    vid_groups = extract_release_groups(vid)
    sub_groups = set()
    for cand in candidates:
        sub_groups |= extract_release_groups(cand)

    for g in sub_groups:
        # Grupa se može naći i kao deo naziva videa i kao izvučena grupa
        if len(g) >= 3 and (g in vid_groups or g in vid):
            return True

    # FPS neslaganje presuđuje protiv kada nemamo poklapanje grupe - titl rađen za drugi FPS ce odlutati kroz film
    try:
        if sub_fps and video_fps:
            sf, vf = float(sub_fps), float(video_fps)
            if sf > 0 and vf > 0 and abs(sf - vf) > 0.1:
                return False
    except (TypeError, ValueError):
        pass

    # 2. Izvor ripa je najvažniji pojedinačni pokazatelj tajminga.
    #    Različite porodice (npr. DVDRip prema WEB-DL) gotovo nikad
    #    nemaju isti tajming, pa takav par odbijamo odmah.
    #    Ista porodica jako podiže verovatnoću, pa spuštamo prag.
    vid_src = detect_source_family(vid)
    sub_src = ''
    for cand in candidates:
        sub_src = detect_source_family(cand)
        if sub_src:
            break

    if vid_src and sub_src and vid_src != sub_src:
        return False

    same_source = bool(vid_src and sub_src and vid_src == sub_src)
    threshold = SYNC_TAG_THRESHOLD_SAME_SOURCE if same_source else SYNC_TAG_THRESHOLD

    # 3. Ostali tagovi - rezolucija, kodek, zvuk
    best_tags = 0
    for cand in candidates:
        rel = cand.lower().replace('_', '.').replace(' ', '.')
        n = sum(1 for tag in RELEASE_TAGS if tag in rel and tag in vid)
        best_tags = max(best_tags, n)

    return best_tags >= threshold


# ============================================================
#  HELPER - ACTIVE LANGUAGE LIST
#  Vraća listu jezičkih unosa koji se koriste u ovoj pretrazi.
#  USE_INTERNAL_LANGUAGES = True  -> cela EXYU_LANGUAGES lista
#  USE_INTERNAL_LANGUAGES = False -> samo jezici izabrani u Kodi
#    podešavanjima; Kodi ih šalje kao 'languages' parametar u
#    obliku engleskih naziva, npr. "Bosnian,Croatian,Serbian"
#  Ako presek ispadne prazan, vraćamo internu listu da pretraga
#  ne bi ostala bez ijednog jezika.
# ============================================================

def get_active_languages(kodi_languages='', preferred=''):
    if USE_INTERNAL_LANGUAGES or not kodi_languages:
        active = list(EXYU_LANGUAGES)
    else:
        wanted = {n.strip().lower() for n in kodi_languages.split(',') if n.strip()}

        # Kodi nudi i zbirni naziv "Serbo-Croatian" koji pokriva
        # srpski, hrvatski, bosanski i crnogorski
        serbo_croatian = {'serbian', 'croatian', 'bosnian', 'montenegrin'}
        has_sh = 'serbo-croatian' in wanted or 'serbocroatian' in wanted

        active = []
        for entry in EXYU_LANGUAGES:
            label = entry['label'].lower()
            if label in wanted or (has_sh and label in serbo_croatian):
                active.append(entry)

        if not active:
            log("get_active_languages: no match with Kodi languages, using internal list")
            active = list(EXYU_LANGUAGES)
        else:
            log(f"get_active_languages: using Kodi selection -> "
                f"{', '.join(e['label'] for e in active)}")

    # ----------------------------------------------------------
    # Preferirani jezik iz Kodi podešavanja ide na vrh liste.
    # Redosled liste određuje prioritet sortiranja rezultata,
    # pa se time preferirani jezik prikazuje prvi.
    # Radi i za internu listu i za Kodi izbor.
    # ----------------------------------------------------------
    pref = (preferred or '').strip().lower()
    if pref and pref not in ('none', 'original'):
        # Zbirni naziv podiže sve ex-yu varijante, ali srpski prvi
        if pref in ('serbo-croatian', 'serbocroatian'):
            order = ['serbian', 'montenegrin', 'bosnian', 'croatian']
            matched = [e for lbl in order for e in active
                       if e['label'].lower() == lbl]
        else:
            matched = [e for e in active if e['label'].lower() == pref]

        if matched:
            rest   = [e for e in active if e not in matched]
            active = matched + rest
            log(f"get_active_languages: preferred '{preferred}' moved to top")
        else:
            log(f"get_active_languages: preferred '{preferred}' not in active list")

    return active


# ============================================================
#  HELPER - DECODED TEXT SCORING
#  Jednobajtne kodne strane nikad ne bacaju grešku pri dekodiranju,
#  pa se ispravnost mora proceniti po Sadržaju rezultata.
#  Veći rezultat = verovatnije ispravan enkoding.
# ============================================================

def score_decoded_text(text):
    if not text or not isinstance(text, str):
        return -9999

    score    = 0
    cyr_cnt  = 0
    lat_cnt  = 0
    ascii_cnt = 0

    for ch in text:
        if ch in EXYU_LATIN_CHARS:
            score += 10                 # čćžšđ - jak pozitivan signal
            lat_cnt += 1
        elif ch in SUSPICIOUS_CHARS:
            score -= 8                  # tipična posledica pogrešnog dekodiranja
        elif ch in EXYU_CYRILLIC_CHARS:
            cyr_cnt += 1                # ocenjuje se kasnije, po koherentnosti
        elif ch.isascii():
            if ch.isalnum() or ch.isspace() or ch in '.,!?:;-\'"()[]<>/':
                score += 1              # normalan tekst titla
                if ch.isalpha():
                    ascii_cnt += 1
            elif ord(ch) < 32 and ch not in '\r\n\t':
                score -= 20             # kontrolni znak - skoro sigurno greška
        elif ord(ch) > 0x2000 and ch not in '…—–‘’“”':
            score -= 5                  # egzotični unicode van očekivanog opsega

    # Ćirilica je ispravna samo ako je tekst Pretežno ćiriličan.
    # Mešanje pisama unutar istog titla znači pogrešan enkoding.
    total_letters = cyr_cnt + lat_cnt + ascii_cnt
    if total_letters > 0:
        if cyr_cnt / total_letters > 0.5:
            score += cyr_cnt * 8        # koherentan ćirilični titl
        elif cyr_cnt > 0:
            score -= cyr_cnt * 6        # latinica pogrešno pročitana kao ćirilica

    return score


# ============================================================
#  HELPER - DISPLAY TAGS
#  Gradi obojeni string tagova [AI] [Forced] [Trusted/Rank]
#  + broj preuzimanja, na osnovu flagova iz REST/XML-RPC odgovora
#  AI/Forced = plavo, Featured/Trusted/Rank = zeleno, broj preuzimanja = žuto
#  Trusted ima prioritet nad rangom - ako oba postoje, prikazuje
#  se samo [Trusted]; ako nema flaga ali ima rang, prikazuje se rang
# ============================================================

def build_tags(ai=False, forced=False, featured=False, trusted=False,
                user_rank='', downloads=None):
    tags = []
    if ai:       tags.append('[COLOR dodgerblue][AI][/COLOR]')
    if forced:   tags.append('[COLOR dodgerblue][Forced][/COLOR]')
    if featured: tags.append('[COLOR limegreen][Featured][/COLOR]')

    if trusted:
        tags.append('[COLOR limegreen][Trusted][/COLOR]')
    elif user_rank:
        rank_label = str(user_rank).strip().title()
        tags.append(f'[COLOR limegreen][{rank_label}][/COLOR]')

    result = ' '.join(tags)

    try:
        dl = int(downloads or 0)
    except (TypeError, ValueError):
        dl = 0
    if dl > 0:
        dl_str = f'[COLOR gold]{dl}x[/COLOR]'
        result = f'{result} {dl_str}' if result else dl_str

    return result


# ============================================================
#  SUBTITLE SEARCH - STREMIO (primary) + XML-RPC (fallback)
# ============================================================

# ============================================================
#  SINGLE SEARCH PASS FOR A GIVEN LANGUAGE LIST
#  Stremio (primarni) + XML-RPC (fallback).
#  Vraća broj titlova dodatih u listu - 0 znači da ništa nije
#  nađeno, što poziva engleski fallback u search().
# ============================================================

def _run_search(handle, imdb_id, season, episode, is_series, active_langs,
                video_path='', video_hash=None, video_size=None, video_fps=None,
                cache=None):
    displayed = 0
    # Keš deljen između prolaza (exyu i engleski fallback).
    # Stremio i REST URL zavise samo od imdb_id/season/episode, pa je
    # odgovor u drugom prolazu identičan - menja se samo lokalni
    # filter po jeziku. Bez keša bismo dvaput tražili isto.
    if cache is None:
        cache = {}

    # Filtere i mape gradimo iz prosleđene liste jezika
    stremio_codes = [c for l in active_langs for c in l['stremio']]
    stremio_map   = {c: l for l in active_langs for c in l['stremio']}
    rest_codes    = [c for l in active_langs for c in l['rest']]

    # ----------------------------------------------------------
    # Gradimo Stremio URL
    # ----------------------------------------------------------
    if is_series:
        query_id = f"{imdb_id}:{season}:{episode}"
    else:
        query_id = imdb_id

    stremio_url = f"{STREMIO_BASE_URL}/{'series' if is_series else 'movie'}/{query_id}.json"
    log(f"search: Stremio URL: {stremio_url}")

    # ----------------------------------------------------------
    # Pokušavamo Stremio kao primarni izvor
    # Retry logika: RETRY_COUNT pokušaja sa RETRY_DELAY pauzom
    # između - pokriva prolazne greške (503, timeout, reset)
    # ----------------------------------------------------------
    stremio_ok = False
    subtitles  = None

    if stremio_url in cache:
        subtitles = cache[stremio_url]
        log(f"search: Stremio response served from cache ({len(subtitles)} items)")
    else:
        response = None
        for attempt in range(1, RETRY_COUNT + 2):  # +2 jer je range ekskluzivan i 1-indexed
            try:
                log(f"search: Stremio attempt {attempt}/{RETRY_COUNT + 1}")
                response = requests.get(stremio_url, headers=HEADERS, timeout=TIMEOUT_STREMIO)
                log(f"search: Stremio HTTP {response.status_code}")

                # Ako je server error (5xx), retry ima smisla
                # Ako je client error (4xx), nema smisla ponavljati
                if response.status_code < 500:
                    break

                # 5xx greška - logujemo i ako ima još pokušaja, čekamo
                log(f"search: Stremio server error {response.status_code}, retrying...")
                if attempt <= RETRY_COUNT:
                    time.sleep(RETRY_DELAY)

            except requests.exceptions.Timeout:
                log(f"search: Stremio timeout on attempt {attempt}")
                if attempt <= RETRY_COUNT:
                    time.sleep(RETRY_DELAY)
                else:
                    log("search: Stremio all attempts timed out, switching to fallback")

            except Exception as e:
                log_error(f"search: Stremio error on attempt {attempt}: {e}")
                break  # Neočekivana greška - nema smisla ponavljati

        if response is not None and response.ok:
            try:
                subtitles = response.json().get('subtitles', [])
                cache[stremio_url] = subtitles
            except Exception as e:
                log_error(f"search: Stremio JSON parse error: {e}")

    if subtitles is not None:
        try:
            filtered = [s for s in subtitles if s.get('lang') in stremio_codes]
            log(f"search: Stremio total={len(subtitles)} exyu={len(filtered)}")

            if not filtered:
                log("search: Stremio returned no exyu subtitles, switching to XML-RPC fallback")

            if filtered:
                stremio_ok = True

                # Dohvatamo imena fajlova iz REST API-ja samo ako je Stremio
                # vratio rezultate - za XML-RPC tok ova funkcija nije potrebna.
                # Rezultat keširamo jer REST URL ne zavisi od jezika.
                rest_key = f"rest:{imdb_id}:{season}:{episode}"
                if rest_key in cache:
                    detailed_names = cache[rest_key]
                    log(f"search: REST response served from cache ({len(detailed_names)} items)")
                else:
                    # Bez jezičkog filtera - keširani rezultat koristi i
                    # engleski prolaz, pa filtriramo lokalno pri prikazu
                    detailed_names = get_detailed_subtitle_names(
                        imdb_id,
                        season=season,
                        episode=episode,
                        rest_codes=None
                    )
                    cache[rest_key] = detailed_names

                # Sortiramo po prioritetu jezika iz aktivne liste
                def lang_priority(sub):
                    lang  = sub.get('lang', '')
                    entry = stremio_map.get(lang)
                    if not entry:
                        return 99
                    return next((i for i, l in enumerate(active_langs)
                                 if l['lang_code'] == entry['lang_code']
                                 and l['label'] == entry['label']), 99)

                filtered.sort(key=lang_priority)

                # Ograničenje broja prikazanih rezultata
                if MAX_RESULTS and len(filtered) > MAX_RESULTS:
                    log(f"search: limiting Stremio results {len(filtered)} -> {MAX_RESULTS}")
                    filtered = filtered[:MAX_RESULTS]

                for sub in filtered:
                    lang        = sub.get('lang', '')
                    sub_id      = str(sub.get('id', ''))
                    sub_url     = sub.get('url', '')
                    entry       = stremio_map.get(lang, active_langs[0])
                    sub_info    = detailed_names.get(sub_id, {})
                    filename    = sub_info.get('filename', f"OpenSubtitles_{sub_id}")
                    rating      = sub_info.get('rating', '0')
                    hearing_imp = 'true' if sub_info.get('hearing_imp', False) else 'false'
                    tags        = build_tags(
                        ai        = sub_info.get('ai',        False),
                        forced    = sub_info.get('forced',    False),
                        featured  = sub_info.get('featured',  False),
                        trusted   = sub_info.get('trusted',   False),
                        user_rank = sub_info.get('user_rank', ''),
                        downloads = sub_info.get('downloads', '0'),
                    )
                    label2 = f"{filename}  {tags}" if tags else filename

                    # Stremio ne vraća MatchedBy - sinhronizaciju procenjujemo
                    # poređenjem naziva izdanja sa nazivom video fajla.
                    # Šaljemo SVE kandidate jer je OS release polje nepouzdano:
                    # zna biti skraćeno, prazno ili sa drugom grupom nego naziv titla.
                    sync_flag = 'false'
                    if DETECT_SYNC and video_path:
                        if is_release_match(
                                [sub_info.get('release', ''),
                                 filename,
                                 sub_info.get('comment', '')],
                                video_path,
                                sub_info.get('fps'), video_fps):
                            sync_flag = 'true'

                    list_item = xbmcgui.ListItem(
                        label=entry['label'],
                        label2=label2
                    )
                    list_item.setArt({'icon': rating, 'thumb': entry['lang_code']})
                    list_item.setProperty('sync',          sync_flag)
                    list_item.setProperty('hearing_imp',   hearing_imp)
                    list_item.setProperty('LanguageName',  entry['label'])

                    params_dl = {
                        'action':    'download',
                        'url':       sub_url,
                        'filename':  filename,
                        'encoding':  sub.get('SubEncoding', ''),
                        'lang_code': entry['lang_code'],
                        'source':    'stremio'
                    }
                    path = f"{sys.argv[0]}?{urllib.parse.urlencode(params_dl)}"
                    xbmcplugin.addDirectoryItem(
                        handle=handle, url=path,
                        listitem=list_item, isFolder=False
                    )
                log(f"search: displayed {len(filtered)} subtitles to user")
                displayed += len(filtered)
        except Exception as e:
            log_error(f"search: Stremio processing error: {e}")

    # ----------------------------------------------------------
    # XML-RPC Fallback - ako Stremio nije vratio exyu rezultate
    # ----------------------------------------------------------
    if not stremio_ok:
        log("search: initiating XML-RPC fallback")
        prev_timeout    = None
        timeout_changed = False
        try:
            import xmlrpc.client as xmlrpc
            import ssl
            import socket

            # ServerProxy ne prima timeout parametar, a podrazumevani
            # socket timeout je beskonačan - ako server zablokira, addon
            # čeka zauvek. Zato ga postavljamo globalno i vraćamo
            # staru vrednost u finally bloku.
            prev_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(TIMEOUT_XMLRPC)
            timeout_changed = True

            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE

            server = xmlrpc.ServerProxy(OPENSUB_XMLRPC_URL, context=ctx)
            login  = server.LogIn('', '', 'en', OPENSUB_USER_AGENT)
            token  = login.get('token')

            if not token:
                log_error("search: XML-RPC login failed, no token")
            else:
                # Pravimo jedan search po svim jezicima odjednom
                lang_str = ','.join(rest_codes)
                xmlrpc_params = {
                    'sublanguageid': lang_str,
                    'imdbid':        imdb_id.replace('tt', '')
                }
                if is_series:
                    xmlrpc_params['season']  = str(season)
                    xmlrpc_params['episode'] = str(episode)

                # Kanonski način utvrđivanja sinhronizacije: ako pošaljemo
                # hash i veličinu fajla, OS vraća MatchedBy='moviehash' za
                # titlove uploadovane baš za taj video
                if DETECT_SYNC and video_hash and video_size:
                    xmlrpc_params['moviehash']     = video_hash
                    xmlrpc_params['moviebytesize'] = str(video_size)
                    log(f"search: XML-RPC including moviehash={video_hash}")

                log(f"search: XML-RPC params: {xmlrpc_params}")
                result = server.SearchSubtitles(token, [xmlrpc_params])
                # data može biti False kad nema rezultata, ne samo prazna lista
                data   = result.get('data', []) if result else []
                subs   = data if isinstance(data, list) else []
                log(f"search: XML-RPC found {len(subs)} subtitles")

                def xmlrpc_priority(sub):
                    lang = sub.get('SubLanguageID', '')
                    return rest_codes.index(lang) if lang in rest_codes else 99

                subs_filtered = [s for s in subs
                                 if s.get('SubLanguageID') in rest_codes
                                 and str(s.get('SubBad', '0')) == '0']  # filtriramo loše titlove
                subs_filtered.sort(key=xmlrpc_priority)
                log(f"search: XML-RPC exyu={len(subs_filtered)} (filtered from {len(subs)})")

                # Ograničenje broja prikazanih rezultata
                if MAX_RESULTS and len(subs_filtered) > MAX_RESULTS:
                    log(f"search: limiting XML-RPC results {len(subs_filtered)} -> {MAX_RESULTS}")
                    subs_filtered = subs_filtered[:MAX_RESULTS]

                for sub in subs_filtered:
                    lang        = sub.get('SubLanguageID', '')
                    sub_url     = sub.get('SubDownloadLink', '')
                    raw_name    = sub.get('SubFileName', f"subtitle_{lang}.srt")
                    # XML-RPC može vratiti flagove kao string '1'/'0', int 1/0 ili bool
                    # Zato upoređujemo kroz str() da budemo tip-agnosticki
                    # Dodatno proveravamo i naziv fajla regexom - SubHearingImpaired
                    # flag je često netačno popunjen od strane uploadera
                    hi_flag     = str(sub.get('SubHearingImpaired', '0')) == '1'
                    is_sdh      = hi_flag or bool(SDH_PATTERN.search(raw_name.lower()))
                    hearing_imp = 'true' if is_sdh else 'false'
                    try:
                        rating = str(int(math.floor(float(sub.get('SubRating', '0') or '0') / 2 + 0.5)))
                    except Exception:
                        rating = '0'
                    if not sub_url:
                        sub_url = sub.get('ZipDownloadLink', '')

                    # Naziv bez ekstenzije
                    filename, _ = os.path.splitext(raw_name)

                    # Trusted flag se prikazuje ako postoji, inače prikazujemo rang uploadera (administrator, vip member, gold member, ...)
                    from_trusted = str(sub.get('SubFromTrusted', '0')) == '1'
                    user_rank    = str(sub.get('UserRank', '') or '').strip()
                    tags = build_tags(
                        ai        = str(sub.get('SubAutoTranslation', '0')) == '1',
                        forced    = str(sub.get('SubForeignPartsOnly', '0')) == '1',
                        featured  = str(sub.get('SubFeatured', '0')) == '1',
                        trusted   = from_trusted,
                        user_rank = user_rank,
                        downloads = sub.get('SubDownloadsCnt', '0'),
                    )
                    label2 = f"{filename}  {tags}" if tags else filename

                    # Pronalazimo odgovarajući entry iz aktivne liste jezika
                    entry = next(
                        (l for l in active_langs if lang in l['rest']),
                        active_langs[0]
                    )

                    # Sync: moviehash pogodak je definitivan dokaz - OS vraća
                    # MatchedBy='moviehash' samo za titlove uploadovane baš
                    # za ovaj video fajl. Inače pokušavamo heuristiku po
                    # nazivu izdanja.
                    sync_flag = 'false'
                    if DETECT_SYNC:
                        if sub.get('MatchedBy') == 'moviehash':
                            sync_flag = 'true'
                        elif video_path and is_release_match(
                                [sub.get('MovieReleaseName', ''),
                                 raw_name,
                                 sub.get('SubAuthorComment', '')],
                                video_path,
                                sub.get('MovieFPS'), video_fps):
                            sync_flag = 'true'

                    list_item = xbmcgui.ListItem(
                        label=entry['label'],
                        label2=label2
                    )
                    list_item.setArt({'icon': rating, 'thumb': entry['lang_code']})
                    list_item.setProperty('sync',         sync_flag)
                    list_item.setProperty('hearing_imp',  hearing_imp)
                    list_item.setProperty('LanguageName', entry['label'])

                    params_dl = {
                        'action':   'download',
                        'url':      sub_url,
                        'filename': filename,
                        'encoding': sub.get('SubEncoding', ''),
                        'lang_code': entry['lang_code'],
                        'source':   'xmlrpc'
                    }
                    path = f"{sys.argv[0]}?{urllib.parse.urlencode(params_dl)}"
                    xbmcplugin.addDirectoryItem(
                        handle=handle, url=path,
                        listitem=list_item, isFolder=False
                    )
                log(f"search: displayed {len(subs_filtered)} subtitles to user")
                displayed += len(subs_filtered)

        except Exception as e:
            log_error(f"search: XML-RPC fallback error: {e}")
        finally:
            # Obavezno vraćamo stari socket timeout - postavljen je
            # globalno, pa bi inače ostao aktivan za celi Kodi proces.
            # Napomena: prev_timeout je legitimno None (podrazumevano),
            # zato koristimo zasebnu zastavicu umesto provere na None.
            if timeout_changed:
                try:
                    import socket
                    socket.setdefaulttimeout(prev_timeout)
                except Exception:
                    pass

    return displayed


# ============================================================
#  HELPER - METADATA FROM MANUAL QUERY
#  Kodi šalje action=manualsearch&searchstring=<tekst> kada
#  korisnik ukuca naslov u dijalogu. Iz tog teksta vadimo
#  sezonu/epizodu ako postoje, pa naslov razrešavamo preko TMDB.
#  Vraća isti oblik dicta kao get_media_info().
# ============================================================

def get_media_info_manual(search_string):
    info = {'imdb_id': None, 'title': None,
            'season': None, 'episode': None, 'year': None}

    query = str(search_string).strip() if search_string else ''
    if not query:
        log_error("get_media_info_manual: empty search string")
        return info

    log(f"get_media_info_manual: query='{query}'")

    # Sezona/epizoda u oblicima: S01E02, 1x02, "Season 1 Episode 2"
    m = re.search(r'[Ss](\d{1,2})[\s._-]*[Ee](\d{1,3})', query)
    if not m:
        m = re.search(r'(?<!\d)(\d{1,2})[xX](\d{1,3})(?!\d)', query)
    if not m:
        m = re.search(r'season\s*(\d{1,2}).*?episode\s*(\d{1,3})',
                      query, flags=re.IGNORECASE)
    if m:
        info['season']  = int(m.group(1))
        info['episode'] = int(m.group(2))
        # Sklanjamo prepoznati obrazac i sve iza njega - TMDB traži samo naziv serije, ne i oznaku epizode
        query = query[:m.start()].strip(' .-_')
        log(f"get_media_info_manual: parsed S{info['season']}E{info['episode']}, "
            f"title query='{query}'")

    # Ako je korisnik ukucao direktno IMDB ID, nema potrebe za TMDB
    m_imdb = re.search(r'(tt\d{6,})', query, flags=re.IGNORECASE)
    if m_imdb:
        info['imdb_id'] = m_imdb.group(1).lower()
        info['title']   = query
        log(f"get_media_info_manual: IMDB ID typed directly: {info['imdb_id']}")
        return info

    clean_name, year = clean_title_for_search(query)
    info['title'] = clean_name or query
    info['year']  = year

    is_series = bool(info['season'] and info['episode'])
    if is_series:
        info['imdb_id'] = get_series_imdb_id(info['title'], info['year'])
    else:
        info['imdb_id'] = get_movie_imdb_id(info['title'], info['year'])

    if not info['imdb_id']:
        log_error(f"get_media_info_manual: could not resolve '{info['title']}'")

    log(f"get_media_info_manual result: {info}")
    return info


# ============================================================
#  SUBTITLE SEARCH - ENTRY POINT
#  Dohvata metapodatke, pokreće pretragu za izabrane jezike,
#  a ako nema nijednog rezultata i FALLBACK_TO_ENGLISH je uključen,
#  pokušava još jednom na engleskom.
# ============================================================

def search(params=None):
    try:
        handle = int(sys.argv[1])
    except Exception as e:
        log_error(f"search: invalid handle: {e}")
        return

    params = params or {}

    # ----------------------------------------------------------
    # Aktivna lista jezika - interna ili iz Kodi podešavanja
    # ----------------------------------------------------------
    active_langs = get_active_languages(params.get('languages', ''),
                                        params.get('preferredlanguage', ''))

    # ----------------------------------------------------------
    # Metapodaci: iz ručnog upita ako ga ima, inače iz Kodija
    # ----------------------------------------------------------
    manual_query = params.get('searchstring', '').strip()
    if params.get('action') == 'manualsearch' and manual_query:
        info = get_media_info_manual(manual_query)
    else:
        info = get_media_info()

    if not info['imdb_id']:
        log_error("search: no IMDB ID found, aborting")
        xbmcplugin.endOfDirectory(handle)
        return

    imdb_id   = info['imdb_id']
    season    = info['season']
    episode   = info['episode']
    title     = info['title']
    is_series = bool(season and episode)

    log(f"search: imdb={imdb_id} | title={title} | S={season} | E={episode}")

    # ----------------------------------------------------------
    # Kontekst za detekciju sinhronizacije - traži aktivan player.
    # Hash je kanonski dokaz (OS vraća MatchedBy='moviehash'),
    # putanja i FPS služe heuristici po nazivu izdanja.
    # ----------------------------------------------------------
    video_path = ''
    video_hash = None
    video_size = None
    video_fps  = None

    if DETECT_SYNC:
        try:
            if xbmc.Player().isPlaying():
                raw_path   = xbmc.Player().getPlayingFile()
                fps_label  = xbmc.getInfoLabel('Player.Process(videofps)')
                video_fps  = fps_label if fps_label else None
                # Hash se računa nad stvarnom putanjom (preskače se za streamove)
                video_hash, video_size = compute_os_hash(raw_path)
                # Za poređenje naziva tražimo najbolji dostupan izvor - debrid URL često nema naziv izdanja u putanji
                video_path = get_video_name_for_match()
        except Exception as e:
            log(f"search: sync context unavailable ({e})")

    # Keš deljen između exyu i engleskog prolaza - Stremio i REST
    # odgovori ne zavise od jezika, pa se drugi prolaz poslužuje iz njega
    net_cache = {}

    found = _run_search(handle, imdb_id, season, episode, is_series, active_langs,
                        video_path, video_hash, video_size, video_fps, net_cache)

    # ----------------------------------------------------------
    # Engleski fallback - samo ako ništa nije nađeno i engleski
    # već nije bio među izabranim jezicima
    # ----------------------------------------------------------
    if found == 0 and FALLBACK_TO_ENGLISH:
        has_english = any(l['lang_code'] == 'en' for l in active_langs)
        if has_english:
            log("search: no results, English was already searched - skipping fallback")
        else:
            log("search: no results for selected languages, retrying in English")
            found = _run_search(handle, imdb_id, season, episode, is_series,
                                [ENGLISH_LANGUAGE],
                                video_path, video_hash, video_size, video_fps,
                                net_cache)
            log(f"search: English fallback returned {found} subtitles")

    log("=== SEARCH DONE ===")
    xbmcplugin.endOfDirectory(handle)


# ============================================================
#  SUBTITLE DOWNLOAD + UTF-8 CONVERSION
# ============================================================

def download(params):
    try:
        handle    = int(sys.argv[1])
        url       = params.get('url')
        filename  = params.get('filename', 'subtitle.srt')
        encoding  = params.get('encoding', '')
        lang_code = params.get('lang_code', '')

        if not url:
            log_error("download: no URL provided")
            xbmcplugin.endOfDirectory(handle)
            return

        temp_dir  = xbmcvfs.translatePath('special://temp/')

        # Brišemo sve prethodne subtitle.* fajlove iz temp foldera
        # da nam se ne gomilaju između sesija (bilo kog formata).
        # Celi blok je pomoćna radnja - ako padne, download se nastavlja.
        try:
            for f in os.listdir(temp_dir):
                if f.startswith('subtitle.') and f.lower().endswith(SUB_EXTENSIONS):
                    try:
                        os.remove(os.path.join(temp_dir, f))
                    except Exception:
                        pass
        except Exception as e:
            log(f"download: temp cleanup skipped ({e})")

        log(f"download: url={url} encoding={encoding or 'unknown'} lang={lang_code}")

        res = requests.get(url, headers=HEADERS, timeout=TIMEOUT_DOWNLOAD)
        res.raise_for_status()
        raw = res.content
        log(f"download: received {len(raw)} bytes")

        # Format titla - utvrđuje se iz arhive ili iz sadržaja nakon
        # raspakivanja, jer Kodi bira parser po ekstenziji fajla
        sub_ext = '.srt'

        # ----------------------------------------------------------
        # ZIP / GZIP detekcija i raspakivanje
        # XML-RPC može vratiti .gz ili .zip arhivu umesto čistog .srt
        # Proveravamo magic bytes: PK = ZIP, \x1f\x8b = GZIP
        # ----------------------------------------------------------
        if raw[:2] == b'PK':
            log("download: detected ZIP archive, extracting subtitle")
            try:
                with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                    # Tražimo prvi .srt ili .sub fajl u arhivi
                    sub_names = [n for n in zf.namelist()
                                 if n.lower().endswith(SUB_EXTENSIONS)]
                    if sub_names:
                        chosen = sub_names[0]
                        raw = zf.read(chosen)
                        # Zadržavamo format iz arhive
                        _, zip_ext = os.path.splitext(chosen)
                        if zip_ext:
                            sub_ext = zip_ext.lower()
                        log(f"download: extracted '{chosen}' from ZIP")
                    else:
                        log_error("download: ZIP contains no subtitle files")
                        xbmcplugin.endOfDirectory(handle)
                        return
            except zipfile.BadZipFile as e:
                log_error(f"download: invalid ZIP archive: {e}")
                xbmcplugin.endOfDirectory(handle)
                return

        elif raw[:2] == b'\x1f\x8b':
            log("download: detected GZIP archive, extracting subtitle")
            try:
                raw = gzip.decompress(raw)
                log(f"download: GZIP decompressed ({len(raw)} bytes)")
            except Exception as e:
                log_error(f"download: GZIP decompression failed: {e}")
                xbmcplugin.endOfDirectory(handle)
                return

        # ----------------------------------------------------------
        # Provera formata po sadržaju - pouzdanije od ekstenzije,
        # jer je uploaderi često pogreše. Gledamo samo početak fajla.
        # ----------------------------------------------------------
        head = raw[:512].lstrip(codecs.BOM_UTF8).lstrip()
        if head[:12].lower() == b'[script info':
            if sub_ext not in ('.ass', '.ssa'):
                log(f"download: content is ASS/SSA, overriding '{sub_ext}'")
            sub_ext = '.ass'
        elif head[:6].lower() == b'webvtt':
            log("download: content is WebVTT")
            sub_ext = '.vtt'

        # ----------------------------------------------------------
        # Generički naziv koji se prepisuje pri svakom preuzimanju.
        # Jezički sufiks ostaje da Kodi prepozna jezik, a ekstenzija
        # odgovara stvarnom formatu da Kodi izabere pravi parser.
        # ----------------------------------------------------------
        filename_with_lang = (f"subtitle.{lang_code}{sub_ext}"
                              if lang_code else f"subtitle{sub_ext}")
        temp_path = os.path.join(temp_dir, filename_with_lang)

        # ----------------------------------------------------------
        # Konverzija u UTF-8
        # Redosled: BOM -> strogi UTF-8 -> bodovanje jednobajtnih
        # Deklarisani enkoding iz API-ja se NE uzima zdravo za gotovo
        # (često je netačan), ali dobija bonus pri izjednačenom rezultatu
        # ----------------------------------------------------------
        def decode_content(raw, encoding):
            declared = encoding.strip().lower().replace('_', '-') if encoding else ''
            # Normalizujemo nazive: "UTF8" -> "utf-8", "CP1250" -> "cp1250"
            if declared in ('utf8', 'utf-8-bom', 'utf8bom'):
                declared = 'utf-8'

            # 1. BOM je definitivan dokaz - nema potrebe za pogađanjem
            if raw.startswith(codecs.BOM_UTF8):
                log("download: UTF-8 BOM detected")
                return raw.decode('utf-8-sig')

            # 2. Strogi UTF-8 - samovalidirajući, slučajni 8-bitni sadržaj gotovo uvek pukne, pa je uspeh jak dokaz
            try:
                text_utf8 = raw.decode('utf-8')
                # Ako ima višebajtnih sekvenci, sigurno je UTF-8
                if any(ord(c) > 127 for c in text_utf8):
                    log("download: detected UTF-8 (multi-byte sequences)")
                    return text_utf8
                # Čist ASCII - svaka kodna strana daje isto, vraćamo odmah
                log("download: detected plain ASCII")
                return text_utf8
            except UnicodeDecodeError:
                pass

            # 3. Bodovanje jednobajtnih kodnih strana po sadržaju rezultata
            candidates = list(EXYU_ENCODINGS)
            if declared and declared not in candidates:
                candidates.insert(0, declared)

            best_enc, best_text, best_score = None, None, None
            for enc in candidates:
                try:
                    decoded = raw.decode(enc)
                except (UnicodeDecodeError, LookupError):
                    continue
                sc = score_decoded_text(decoded)
                # Mali bonus deklarisanom enkodingu za slučaj izjednačenja
                if enc == declared:
                    sc += 5
                log(f"download: encoding candidate '{enc}' score={sc}")
                if best_score is None or sc > best_score:
                    best_enc, best_text, best_score = enc, decoded, sc

            if best_text is not None:
                if declared and best_enc != declared:
                    log(f"download: declared '{declared}' overridden by '{best_enc}' (score={best_score})")
                else:
                    log(f"download: using encoding '{best_enc}' (score={best_score})")
                return best_text

            log_error("download: all encodings failed, using utf-8 with replace")
            return raw.decode('utf-8', errors='replace')

        # CONVERT_TO_UTF8 = False -> snimamo fajl tačno onakav kakav je preuzet
        if CONVERT_TO_UTF8:
            text      = decode_content(raw, encoding)
            out_bytes = text.encode('utf-8')
        else:
            log("download: UTF-8 conversion disabled, saving raw content")
            out_bytes = raw

        f = None
        try:
            f = xbmcvfs.File(temp_path, 'wb')
            f.write(bytearray(out_bytes))
        except Exception as e:
            log_error(f"download: failed to write temp file: {e}")
            xbmcplugin.endOfDirectory(handle)
            return
        finally:
            # Zatvaramo i kad write pukne - inače handle ostaje otvoren
            if f is not None:
                try:
                    f.close()
                except Exception:
                    pass

        log(f"download: saved to {temp_path} ({len(out_bytes)} bytes)")

        # Kodi preuzima titl kroz addDirectoryItem i sam ga primenjuje.
        list_item = xbmcgui.ListItem(label=filename_with_lang)
        xbmcplugin.addDirectoryItem(
            handle=handle, url=temp_path,
            listitem=list_item, isFolder=False
        )
        log(f"=== DOWNLOAD DONE | {filename_with_lang} ===")

    except requests.exceptions.Timeout:
        log_error("download: request timed out")
    except requests.exceptions.HTTPError as e:
        log_error(f"download: HTTP error: {e}")
    except Exception as e:
        log_error(f"download: {str(e)}")

    xbmcplugin.endOfDirectory(handle)


# ============================================================
#  ENTRY POINT
# ============================================================

if __name__ == '__main__':
    try:
        param_string = sys.argv[2][1:] if len(sys.argv) > 2 else ""
        params = dict(urllib.parse.parse_qsl(param_string))
        action = params.get('action')

        if action == 'download':
            log(f"=== DOWNLOAD START | lang={params.get('lang_code','?')} source={params.get('source','?')} ===")
            download(params)
        elif action == 'manualsearch':
            log(f"=== MANUAL SEARCH START | query='{params.get('searchstring','')}' ===")
            search(params)
        else:
            log(f"=== SEARCH START ===")
            search(params)

    except Exception as e:
        log_error(f"FATAL: {str(e)}")
        try:
            handle = int(sys.argv[1])
            xbmcplugin.endOfDirectory(handle)
        except Exception:
            pass
