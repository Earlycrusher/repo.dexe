# -*- coding: utf-8 -*-

import hashlib
import json
import os
import random
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid as uuidlib
import zlib
from datetime import datetime

from dateutil import tz

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import common


Addon = common.Addon

AddonName = common.AddonName

icon = common.icon

addon_data_dir = common.addon_data_dir

cacheDir = common.cacheDir

addonDir = Addon.getAddonInfo("path")

iconsDir = os.path.join(addonDir, "resources", "images")

playlistsFile = os.path.join(addon_data_dir, "playLists.dat")

vDirectoriesFile = os.path.join(addon_data_dir, "virtual_directoriesLists.dat")

tmpListFile = os.path.join(addon_data_dir, "tempList.dat")

favoritesFile = os.path.join(addon_data_dir, "favorites.dat")

searchResultsFile = os.path.join(addon_data_dir, "searchResults.dat")

recentFile = os.path.join(addon_data_dir, "recent.dat")

sortPrefsFile = os.path.join(addon_data_dir, "sortPrefs.dat")

_RECENT_MAX = 20

_RECENT_CONFIRM_SEC = 10

_RECENT_START_WAIT = 15

makeGroups = Addon.getSetting("makeGroups") == "true"

groupSeries = Addon.getSetting("groupSeries") == "true"

ENC_KEY = None

EXTERNAL_LISTS_URLS = None

MENU = {}

_EXT_CACHE_MIN = 360

_EXT_LIST_CACHE_MIN = 0

def getLocaleString(id, *args):
    s = Addon.getLocalizedString(id)
    if not args:
        return s
    try:
        return s.format(*args)
    except (IndexError, KeyError, ValueError):
        return s


def GetKeyboardText(title="", defaultText=""):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ""

def GetSourceLocation(title, chList):
    return xbmcgui.Dialog().select(title, chList)

def GetNumFromUser(title, defaultt=""):
    choice = xbmcgui.Dialog().input(
        title, defaultt=defaultt, type=xbmcgui.INPUT_NUMERIC
    )
    return None if choice == "" else int(choice)

def GetIndexFromUser(listLen, index):
    location = GetNumFromUser("{0} (1-{1})".format(getLocaleString(30000), listLen))
    if location is None or not (0 < location <= listLen):
        return 0
    return location - 1 - index

def GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, defaultText=""):
    choiceList = [getLocaleString(choiceFile), getLocaleString(choiceUrl)]
    offset = 0
    if choiceNone is not None:
        choiceList.insert(0, getLocaleString(choiceNone))
        offset = 1

    method = GetSourceLocation(getLocaleString(choiceTitle), choiceList)
    if method < 0:
        return None
    if choiceNone is not None and method == 0:
        return ""

    if method == offset:
        default = defaultText if defaultText.startswith("http") else ""
        text = GetKeyboardText(getLocaleString(fileTitle), default).strip()
        return text if text else None
    else:
        default = "" if defaultText.startswith("http") else defaultText
        choice = xbmcgui.Dialog().browse(
            fileType, getLocaleString(urlTitle), "files",
            fileMask, False, False, default,
        )
        return choice if choice and choice != default or default else None


_TAG_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)[^\]]*\]", re.I)

_BROKEN_TAG_RE = re.compile(r"\[/?[A-Z]+[^\]]*$|^[^\[]*?\]", re.I)

_FIX_OPEN_RE = re.compile(r"(?<!\[)(?<!\[/)\b(COLOR ?[a-zA-Z0-9]+)\]", re.I)

_FIX_CLOSE_RE = re.compile(r"\[(/COLOR|/B|/I)$", re.I)

def clean_tags(text):
    if not text:
        return ""
    text = _TAG_RE.sub("", text)
    text = _BROKEN_TAG_RE.sub("", text)
    return text.strip()

def fix_tags(text):
    if not text:
        return ""
    text = _FIX_OPEN_RE.sub(r"[\1]", text)
    text = _FIX_CLOSE_RE.sub(r"[\1]", text)
    opens = len(re.findall(r"\[COLOR[^\]]*\]", text, re.I))
    closes = len(re.findall(r"\[/COLOR\]", text, re.I))
    text += "[/COLOR]" * max(opens - closes, 0)
    opens_b = len(re.findall(r"\[B\]", text, re.I))
    closes_b = len(re.findall(r"\[/B\]", text, re.I))
    text += "[/B]" * max(opens_b - closes_b, 0)
    return text

def _display_name(name, wrap=True, local=False):
    fixed = fix_tags(name or "?")
    if local:
        return "[B][[/B]{0}[B]][/B]".format(fixed)
    if not wrap:
        return fixed
    if fixed.startswith(("[COLOR", "[B]", "[I]")):
        return fixed
    return "[B][[/B]{0}[B]][/B]".format(fixed)

_NON_COLOR_TAG_RE = re.compile(
    r"\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)\]", re.I
)

def _sanitizeDirName(name):
    name = _NON_COLOR_TAG_RE.sub("", name or "")
    return fix_tags(name.strip())

def _plainName(text):
    text = clean_tags(text or "")
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1].strip()
    return text.strip()


def _extListCache(entry):
    src_cache = entry.get("_src_cache", "")
    try:
        if src_cache != "" and src_cache is not None:
            return str(int(src_cache))
    except (ValueError, TypeError):
        pass
    try:
        val = entry.get("cache", "")
        if val != "" and val is not None:
            return str(int(val))
    except (ValueError, TypeError):
        pass
    return str(_EXT_LIST_CACHE_MIN)

def _folderParts(path):
    return [p for p in (path or "").split("/") if p.strip()]


def _joinFolder(*parts):
    out = []
    for p in parts:
        out.extend(_folderParts(p))
    return "/".join(out)


def _extFolderChildren(entries, base):
    baseParts = _folderParts(base)
    subs = []
    here = []
    for entry in entries:
        parts = _folderParts(entry.get("_folder", ""))
        if parts[:len(baseParts)] != baseParts:
            continue
        rest = parts[len(baseParts):]
        if not rest:
            here.append(entry)
        elif rest[0] not in subs:
            subs.append(rest[0])
    return subs, here


def GetExternalEntries():
    entries = []

    sources = []
    if Addon.getSetting("useCustomSource") == "true":
        customSrc = (Addon.getSetting("customSourceUrl") or "").strip()
        if customSrc.startswith("http"):
            sources.append({"url": customSrc, "folder": "", "cache": ""})
    sources.extend(EXTERNAL_LISTS_URLS or [])

    if not sources:
        return entries

    for src in sources:
        if isinstance(src, dict):
            url = src.get("url", "")
            folder = (src.get("folder") or "").strip()
            src_cache = src.get("cache", "")
        else:
            url = src
            folder = ""
            src_cache = ""
        if not url:
            continue

        cacheFile = common.cachePath(url + "#external")
        data = None

        if common.isFileNew(cacheFile, _EXT_CACHE_MIN * 60):
            data = common.load_encrypted(cacheFile, ENC_KEY, default=None)

        if data is None:
            try:
                data = json.loads(common.OpenURL(url, timeout=15))
                if isinstance(data, list):
                    common.save_encrypted(cacheFile, data, ENC_KEY)
            except Exception as ex:
                common.log(
                    "Failed to fetch external entries ({0}): {1}".format(url, ex), 3
                )
                data = common.load_encrypted(cacheFile, ENC_KEY, default=None)

        if isinstance(data, list):
            for entry in data:
                if isinstance(entry, dict):
                    if entry.get("enabled") is False:
                        continue
                    eurl = (entry.get("url") or "").strip()
                    if not eurl:
                        continue
                    entry["url"] = eurl
                    if eurl.startswith("http"):
                        eurl, xtream_epg = _xtreamInfo(eurl)
                        entry["url"] = eurl
                        if xtream_epg and not entry.get("epg"):
                            entry["epg"] = xtream_epg
                    if not entry.get("uuid"):
                        entry["uuid"] = "ext" + hashlib.md5(
                            eurl.encode("utf-8")
                        ).hexdigest()[:8]
                    if not entry.get("name"):
                        entry["name"] = getLocaleString(
                            30006, entry["uuid"][-4:]
                        )
                    entry["_folder"] = _joinFolder(
                        folder, entry.get("folder")
                    )
                    entry["_src_cache"] = src_cache
                    entries.append(entry)
        elif data is not None:
            common.log("External list is not a JSON array: {0}".format(url), 3)

    return entries


def _globalEpg():
    if Addon.getSetting("useGlobalEpg") != "true":
        return ""
    if Addon.getSetting("globalEpgSource") == "1":
        return Addon.getSetting("globalEpgFile") or ""
    return (Addon.getSetting("globalEpgUrl") or "").strip()

def _globalLogos():
    if Addon.getSetting("useGlobalLogos") != "true":
        return ""
    if Addon.getSetting("globalLogosSource") == "1":
        base = (Addon.getSetting("globalLogosFolder") or "").strip()
        if base and not base.endswith(("/", "\\")):
            base += "/"
        return base
    base = (Addon.getSetting("globalLogosUrl") or "").strip()
    if base and not base.endswith("/"):
        base += "/"
    return base

def _useIptvLogos():
    return Addon.getSetting("useIptvOrgLogos") == "true"

def _resolveImage(image, logos):
    if not image:
        return ""
    if image.startswith("http"):
        return image
    prefix = logos or _globalLogos()
    return prefix + image if prefix else ""

def _imageWithUA(image):
    if not image or not image.startswith("http") or "|" in image:
        return image
    return "{0}|{1}".format(
        image, urllib.parse.urlencode({"User-Agent": common.UA})
    )


def _channelPlot(listName="", groupName="", epgPlot="", isFav=False,
                 seriesName="", sortedByName=False):
    parts = []
    if listName:
        parts.append("[B]{0}[/B]".format(
            getLocaleString(30060, _plainName(listName))
        ))
    if groupName:
        parts.append(getLocaleString(30061, _plainName(groupName)))
    if seriesName:
        parts.append(getLocaleString(30062, _plainName(seriesName)))
    if sortedByName:
        parts.append(
            "[COLOR FF808080]{0}[/COLOR]".format(getLocaleString(30064))
        )

    origin = "\n".join(parts)

    if isFav:
        fav = "[COLOR FFDAA520][B]{0}[/B][/COLOR]".format(
            getLocaleString(30063)
        )
        origin = origin + "\n\n" + fav if origin else fav

    if origin and epgPlot:
        return origin + "\n\n" + epgPlot
    return origin or epgPlot

def AddDir(
    name, url, mode, iconimage="", logos="", epg="", index=-1, move=0,
    uuid="0", isFolder=True, IsPlayable=False, background=None,
    cacheMin="0", plot="", fanart="", addToVdir=True, streamProps=None,
    isExternal=False, listName="", favUrls=None, epgMeta=None,
    extraParams=None, fromSearch=False, originParams=None, isAudio=False,
    groupName="", listUrl="", fromRecent=False, infoTitle="",
):
    urlParams = {
        "name": name,
        "url": url,
        "mode": mode,
        "iconimage": iconimage,
        "logos": logos,
        "epg": epg,
        "cache": cacheMin,
        "uuid": uuid,
    }
    if isAudio:
        urlParams["audio"] = 1
    if streamProps:
        urlParams["sprops"] = json.dumps(streamProps)
    if mode == 12:
        urlParams["index"] = index
        if listName:
            urlParams["listname"] = listName
    if extraParams:
        urlParams.update(extraParams)

    liz = xbmcgui.ListItem(name)

    epgMeta = epgMeta or {}
    disp_icon = _imageWithUA(iconimage)
    poster = _imageWithUA(epgMeta.get("poster", "")) or (
        disp_icon if IsPlayable else ""
    )
    art = {"icon": disp_icon or "DefaultVideo.png"}
    if disp_icon:
        art["thumb"] = disp_icon
    if poster:
        art["poster"] = poster
    if background:
        art["fanart"] = _imageWithUA(background)
    elif fanart:
        art["fanart"] = _imageWithUA(fanart)
    liz.setArt(art)

    if isAudio:
        try:
            liz.getMusicInfoTag().setTitle(infoTitle or name)
        except AttributeError:
            liz.setInfo(
                type="Music", infoLabels={"Title": infoTitle or name}
            )
    elif isFolder or IsPlayable:
        genres = epgMeta.get("genres") or (
            [epgMeta["genre"]] if epgMeta.get("genre") else []
        )
        year = epgMeta.get("year", "")
        try:
            vtag = liz.getVideoInfoTag()
            vtag.setTitle(infoTitle or name)
            vtag.setPlot(plot)
            vtag.setPlaycount(0)
            if genres:
                vtag.setGenres(genres)
            if year:
                vtag.setYear(int(year))
        except AttributeError:
            infoLabels = {"Title": infoTitle or name, "plot": plot,
                          "playcount": 0}
            if genres:
                infoLabels["genre"] = " / ".join(genres)
            if year:
                infoLabels["year"] = int(year)
            liz.setInfo(type="Video", infoLabels=infoLabels)

    if IsPlayable:
        liz.setProperty("IsPlayable", "true")

    def _ctx(label_id, ctx_mode, label_args=(), **extra):
        params = {"mode": ctx_mode, "index": index, "uuid": uuid}
        params.update(extra)
        return (
            "[B]{0}[/B]".format(getLocaleString(label_id, *label_args)),
            "RunPlugin({0}?{1})".format(
                sys.argv[0], urllib.parse.urlencode(params)
            ),
        )

    items = []
    listMode = 31

    if mode in (10, 11) and not isExternal:
        items = [
            _ctx(30010, 32, label_args=(AddonName,)),
        ]
        if mode == 11 and not url.lower().endswith(".plx"):
            _slabel = 30031 if _getSort(url) == "name" else 30030
            items.append(_ctx(_slabel, 82, url=url))
            items.append(_ctx(30029, 83, url=url, index=-1, cache=cacheMin))
        items += [
            _ctx(30011, 33),
            _ctx(30012, 34),
            _ctx(30013, 35),
        ]
        if mode == 11 and not url.lower().endswith(".plx"):
            items.append(_ctx(30014, 36))
            items.append(_ctx(30015, 37))
        if url.startswith("http"):
            items.append(_ctx(30016, 38))

    if mode == 20:
        inFav = favUrls is not None and url.lower() in favUrls
        if inFav:
            items = [(
                "[B]{0}[/B]".format(getLocaleString(30022, AddonName)),
                "RunPlugin({0}?{1})".format(
                    sys.argv[0],
                    urllib.parse.urlencode({"mode": 44, "url": url}),
                ),
            )]
        else:
            _favp = {
                "mode": 41, "url": url,
                "iconimage": iconimage, "name": name, "uuid": uuid,
            }
            if fromRecent and originParams:
                if originParams.get("listname"):
                    _favp["favlist"] = originParams["listname"]
                if originParams.get("group"):
                    _favp["favgroup"] = originParams["group"]
                if originParams.get("series"):
                    _favp["favseries"] = originParams["series"]
                if originParams.get("epg"):
                    _favp["favepg"] = originParams["epg"]
                if originParams.get("tvg_id"):
                    _favp["favtvg"] = originParams["tvg_id"]
                if originParams.get("kind"):
                    _favp["favkind"] = originParams["kind"]
            items = [(
                "[B]{0}[/B]".format(getLocaleString(30021, AddonName)),
                "RunPlugin({0}?{1})".format(
                    sys.argv[0], urllib.parse.urlencode(_favp)
                ),
            )]

        if originParams and originParams.get("listname"):
            op = {"mode": 80}
            op.update(originParams)
            items.append((
                "[B]{0}[/B]".format(getLocaleString(30023)),
                "RunPlugin({0}?{1})".format(
                    sys.argv[0], urllib.parse.urlencode(op)
                ),
            ))

        if fromRecent:
            items.append(_ctx(30033, 52, url=url))

        _ff_path = urllib.parse.urlsplit(
            url.split("|", 1)[0]
        ).path.lower()
        if (_ff_path.endswith((".m3u8", ".mpd"))
                or not _ff_path.endswith(_KNOWN_STREAM_EXT)):
            ffParams = dict(urlParams)
            ffParams["ff"] = 1
            items.append((
                "[B]{0}[/B]".format(getLocaleString(30024)),
                "PlayMedia({0}?{1})".format(
                    sys.argv[0], urllib.parse.urlencode(ffParams)
                ),
            ))

    elif mode == 21:
        items = [
            _ctx(30022, 43, label_args=(AddonName,)),
        ]
        if listName:
            items.append(_ctx(30023, 81))

        _ff_path = urllib.parse.urlsplit(
            url.split("|", 1)[0]
        ).path.lower()
        if (_ff_path.endswith((".m3u8", ".mpd"))
                or not _ff_path.endswith(_KNOWN_STREAM_EXT)):
            ffParams = dict(urlParams)
            ffParams["ff"] = 1
            items.append((
                "[B]{0}[/B]".format(getLocaleString(30024)),
                "PlayMedia({0}?{1})".format(
                    sys.argv[0], urllib.parse.urlencode(ffParams)
                ),
            ))

        items += [
            _ctx(30011, 46),
            _ctx(30012, 47),
            _ctx(30013, 48),
        ]
        listMode = 45

    elif mode == 71:
        if not str(uuid).startswith("ext:"):
            items = [
                _ctx(30025, 74),
                _ctx(30026, 75),
                _ctx(30028, 77),
                _ctx(30027, 76),
            ]

    elif mode == 50:
        items = [_ctx(30032, 51)]

    elif mode == 40:
        items = [
            _ctx(30140, 42),
            _ctx(30029, 85),
        ]

    elif mode == 12:
        _gname = groupName or re.sub(r"\s*\(\d+\)\s*$", "", name).strip()
        _slabel = 30031 if _getSort(listUrl or url, _gname or None) == "name" \
            else 30030
        items = [
            _ctx(_slabel, 82, url=listUrl or url, group=_gname,
                 scope="group"),
            _ctx(30029, 83, url=listUrl or url, cache=cacheMin),
        ]

    elif mode == 13:
        _xp = extraParams or {}
        items = []
        if _xp.get("series", "") == _UNGROUPED:
            _pg = _xp.get("group", "")
            _slabel = 30031 if _getSort(url, _pg or None) == "name" \
                else 30030
            if _pg:
                items.append(_ctx(_slabel, 82, url=url, group=_pg,
                                  scope="group"))
            else:
                items.append(_ctx(_slabel, 82, url=url))
        items.append(_ctx(
            30029, 84, url=url, cache=cacheMin,
            index=_xp.get("index", -1), series=_xp.get("series", ""),
        ))

    if mode in (10, 11, 21) and not isExternal:
        items += [
            _ctx(30017, listMode, move=-1),
            _ctx(30018, listMode, move=1),
        ]
        if mode in (10, 11):
            if addToVdir:
                items.append(_ctx(30019, 72))
            else:
                items.append(_ctx(30020, 73))

    liz.addContextMenuItems(items)

    u = "{0}?{1}".format(sys.argv[0], urllib.parse.urlencode(urlParams))
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder
    )

def AddListItems(chList, addToVdir=True):
    for i, item in enumerate(chList):
        mode = 10 if ".plx" in item["url"] else 11
        name = common.GetEncodeString(item["name"])
        uuid4 = item["uuid"]

        image = item.get("image", "") or os.path.join(
            iconsDir, "defaultlist.png"
        )
        logos = item.get("logos", "")
        epg = item.get("epg", "")
        cacheMin = item.get("cache", "0")

        AddDir(
            _display_name(name, local=True),
            item["url"],
            mode,
            image,
            logos,
            epg,
            index=i,
            uuid=uuid4,
            cacheMin=cacheMin,
            addToVdir=addToVdir,
        )


def Categories():
    gEpg = _globalEpg()
    if gEpg.startswith("http"):
        common.prefetchEpg(gEpg, cache=720)
    if _useIptvLogos():
        common.prefetchIptvLogos(cache=2880)

    if MENU.get("toggle_groups"):
        AddDir(
            "[B]{0}: {1}[/B] - {2} ".format(
                getLocaleString(30302),
                getLocaleString(30004) if makeGroups else getLocaleString(30005),
                getLocaleString(30046),
            ),
            "setting", 86, os.path.join(iconsDir, "setting.png"), isFolder=False,
        )

    if MENU.get("favorites"):
        AddDir(
            "[COLOR FFDAA520][B]{0}[/B][/COLOR]".format(getLocaleString(30040)),
            "favorites", 40, os.path.join(iconsDir, "favorites.png"),
        )

    if MENU.get("recent"):
        AddDir(
            "[COLOR FF9B7EDE][B]{0}[/B][/COLOR]".format(getLocaleString(30041)),
            "recent", 50, os.path.join(iconsDir, "recent.png"),
        )

    if MENU.get("search"):
        AddDir(
            "[COLOR FFFF6600][B]{0}[/B][/COLOR]".format(getLocaleString(30042)),
            "search", 60, os.path.join(iconsDir, "search.png"),
            isFolder=False,
        )

    if MENU.get("new_list"):
        AddDir(
            "[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30043)),
            "newList", 30, os.path.join(iconsDir, "newlist.png"), isFolder=False,
        )

    if MENU.get("new_directory"):
        AddDir(
            "[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30044)),
            "newDirectory", 70, os.path.join(iconsDir, "newfolder.png"),
            isFolder=False,
        )

    external = GetExternalEntries() if MENU.get("external") else []

    vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    userDirNames = {v.get("name", "") for v in vDirs}
    extSubs, extHere = _extFolderChildren(external, "")
    extFolders = [f for f in extSubs if f not in userDirNames]

    for y, vDir in enumerate(vDirs):
        dir_icon = vDir.get("icon") or os.path.join(
            iconsDir, "defaultfolder.png"
        )
        AddDir(
            "[COLOR FF00BFFF][B]{0}[/B][/COLOR]".format(vDir["name"]),
            str(y), 71, dir_icon, uuid=vDir["uuid"], isFolder=True,
        )

    for f in extFolders:
        AddDir(
            "[COLOR FF00FF66][B]{0}[/B][/COLOR]".format(f),
            f, 71, os.path.join(iconsDir, "defaultfolder.png"),
            uuid="ext:{0}".format(f), isFolder=True,
        )

    ignored = set()
    for vDir in vDirs:
        ignored.update(vDir.get("data", []))

    chList = common.load_encrypted(playlistsFile, ENC_KEY)
    addList = [
        item for item in chList
        if "uuid" in item and item["uuid"] not in ignored
    ]
    AddListItems(addList)

    for entry in extHere:
        AddDir(
            _display_name(entry.get("name", "?")),
            entry.get("url", ""),
            11,
            entry.get("image") or "DefaultPlaylist.png",
            entry.get("logos", ""),
            entry.get("epg", ""),
            index=1,
            uuid=entry.get("uuid", "0"),
            cacheMin=_extListCache(entry),
            addToVdir=False,
            isExternal=True,
        )

    if MENU.get("settings"):
        AddDir(
            "[B]{0}[/B]".format(getLocaleString(30045)),
            "settings", 90, os.path.join(iconsDir, "setting.png"),
            isFolder=False,
        )

    CleanCache(chList + external)


_UNGROUPED = "Uncategorised"

def _groupM3uChannels(chList):
    groups = {}
    order = []
    ungrouped = []
    for channel in chList:
        gkey = channel.get("group_title")
        if not gkey:
            ungrouped.append(channel)
            continue
        if gkey not in groups:
            groups[gkey] = []
            order.append(gkey)
        groups[gkey].append(channel)

    result = [groups[g] for g in order]

    if ungrouped:
        if result:
            for c in ungrouped:
                c["group_title"] = _UNGROUPED
            result.append(ungrouped)
        else:
            result = [[c] for c in ungrouped]
    return result

_EPISODE_RE = re.compile(
    r"""^(?P<series>.*?)
        [\s._\-\[\(]*                      # razdvajac pre oznake
        (?:
            [Ss](?P<s>\d{1,2})[\s._\-]?[Ee](?P<e>\d{1,3})   # S01E02 varijante
            (?:[\-\s]?[Ee]\d{1,3})*                          # dupla epizoda
          | (?P<s2>\d{1,2})[xX](?P<e2>\d{1,3})               # 1x02
          | [Ss][Ee][Aa][Ss][Oo][Nn]                         # Season 2 Episode 3
            [\s#:.\-_|\(\)\[\]]{0,4}(?P<s5>\d{1,2})
            [\s#:.\-_|\(\)\[\]]{0,6}
            [Ee][Pp][Ii][Ss][Oo][Dd][Ee]
            [\s#:.\-_|\(\)\[\]]{0,4}(?P<e5>\d{1,3})
          | [Ee][Pp][Ii][Ss][Oo][Dd][Ee]                     # Episode 3 (bez sezone)
            [\s#:.\-_|\(\)\[\]]{0,4}(?P<e6>\d{1,3})
          | [Ee][Pp][\s.\-]?(?P<e3>\d{1,3})                  # EP02
          | [Ee](?P<e4>\d{2,3})                              # E02 (min 2 cifre)
        )
        (?![a-zA-Z0-9])                    # tvrda granica posle oznake
    """,
    re.X,
)

def _parseEpisode(name):
    if not name:
        return None
    m = _EPISODE_RE.match(clean_tags(name))
    if not m:
        return None
    series = m.group("series").strip(" .-_([:|").strip()
    if not series:
        return None
    season = int(m.group("s") or m.group("s2") or m.group("s5") or 0)
    episode = int(
        m.group("e") or m.group("e2") or m.group("e3")
        or m.group("e4") or m.group("e5") or m.group("e6") or 0
    )
    return series, season, episode

_VOD_PATH_RE = re.compile(r"/(?:series|movies?)/", re.I)

_RADIO_PATH_RE = re.compile(r"/radio/", re.I)

_VOD_EXT = (".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".webm")

_AUDIO_EXT = (".mp3", ".aac", ".flac", ".ogg", ".wav", ".m4a", ".opus")

_RADIO_WORD_RE = re.compile(r"(?<![a-z])radio(?![a-z])", re.I)

_TV_WORD_RE = re.compile(r"(?<![a-z])tv(?![a-z])", re.I)

def _streamKind(url, name="", group="", tvg_id=""):
    try:
        path = urllib.parse.urlsplit(url).path.lower()
    except (ValueError, TypeError):
        return "live"
    if _RADIO_PATH_RE.search(path) or path.endswith(_AUDIO_EXT):
        return "radio"
    if _VOD_PATH_RE.search(path) or path.endswith(_VOD_EXT):
        return "vod"
    if tvg_id and _RADIO_WORD_RE.search(tvg_id):
        return "radio"
    if group and _RADIO_WORD_RE.search(group):
        return "radio"
    if name and _RADIO_WORD_RE.search(name) \
            and not _TV_WORD_RE.search(name):
        return "radio"
    return "live"


def _epgForChannel(epgSources, name, image, dnow, to_zone, tvg_id=""):
    base_name = name
    want_cc = (common.epgCountryFromId(tvg_id)
               or common.epgCountryFromName(base_name))

    def _pickByCountry(src, multi, default_idx):
        if not multi or len(multi) < 2 or not want_cc:
            return default_idx
        for ci in multi:
            if common.epgCountryFromId(src["data"][ci][0]) == want_cc:
                return ci
        return default_idx

    def _matchInSource(src):
        ids = src.get("ids") or {}
        if tvg_id and tvg_id in ids:
            idx = ids[tvg_id][1]
            return src["data"][idx][0], ids[tvg_id][0]
        normids = src.get("normids") or {}
        if tvg_id and normids:
            nkey = common.normEpgId(tvg_id)
            idx = normids.get(nkey)
            if idx is not None:
                idx = _pickByCountry(
                    src, (src.get("normidMulti") or {}).get(nkey), idx
                )
                return src["data"][idx][0], src["data"][idx][1]
        names = src.get("name") or []
        if base_name in names:
            idx = names.index(base_name)
            return src["data"][idx][0], src["data"][idx][1]
        normMap = src.get("norm") or {}
        if normMap:
            nkey = common.normEpgName(base_name)
            idx = normMap.get(nkey)
            if idx is not None:
                idx = _pickByCountry(
                    src, (src.get("normMulti") or {}).get(nkey), idx
                )
                return src["data"][idx][0], src["data"][idx][1]
        return None, ""

    def _clean(text):
        return text.replace("&quot;", '"').replace("&amp;", "&")

    def _duration(stime, etime):
        mins = int((etime - stime).total_seconds() // 60)
        if mins <= 0:
            return ""
        h, m = divmod(mins, 60)
        if h and m:
            return "({0}h {1}m)".format(h, m)
        if h:
            return "({0}h)".format(h)
        return "({0}m)".format(m)

    def _render(src, ch_id):
        programmes = (src.get("prg") or {}).get(ch_id) or []
        shown = 0
        in_current = False
        plot_parts = []
        disp_name = base_name
        rmeta = {}

        for entry in programmes:
            start, stop, title = entry[0], entry[1], entry[2]
            desc = entry[3] if len(entry) > 3 else ""
            picon = entry[4] if len(entry) > 4 else ""
            categories = entry[5] if len(entry) > 5 else []
            if isinstance(categories, str):
                categories = [categories] if categories else []
            date = entry[6] if len(entry) > 6 else ""

            stime = common.xmltvTime(start)
            etime = common.xmltvTime(stop)
            if stime is None or etime is None:
                continue
            stime = stime.replace(tzinfo=tz.UTC)
            etime = etime.replace(tzinfo=tz.UTC)

            if not in_current and not (stime <= dnow <= etime):
                if dnow < stime:
                    break
                continue

            ebgn = stime.astimezone(to_zone).strftime("%H:%M")
            eend = etime.astimezone(to_zone).strftime("%H:%M")
            stmp = "{0}-{1}".format(ebgn, eend)
            dur = _duration(stime, etime)
            plot_stmp = "{0} {1}".format(stmp, dur) if dur else stmp
            title = _clean(title)
            desc = _clean(desc)

            year = date[:4] if date[:4].isdigit() else ""
            title_plot = "{0} ({1})".format(title, year) if year else title

            if not in_current:
                disp_name = (
                    "[B]{0}[/B] • [COLOR FF00BB66]{1}[/COLOR] {2}".format(
                        base_name, stmp, title
                    )
                )
                part = (
                    "[B][COLOR FF4DA6FF]{0}[/COLOR]\n"
                    "[COLOR FFFFFFFF]{1}[/COLOR][/B]".format(
                        plot_stmp, title_plot
                    )
                )
                if desc:
                    part += "\n{0}".format(desc)
                plot_parts.append(part)
                rmeta = {
                    "poster": picon,
                    "genres": categories,
                    "year": year,
                }
                in_current = True
            else:
                part = "[B][COLOR FF0084FF]{0}[/COLOR]\n{1}[/B]".format(
                    plot_stmp, title_plot
                )
                if desc:
                    part += "\n{0}".format(desc)
                plot_parts.append(part)

            shown += 1
            if shown >= 5:
                break

        if not plot_parts:
            return None, "", {}
        return disp_name, "\n\n".join(plot_parts), rmeta

    fallback_img = ""

    for src in epgSources:
        if not src:
            continue
        mid, mimg = _matchInSource(src)
        if mid is None:
            continue
        if not fallback_img:
            fallback_img = mimg
        rname, rplot, rmeta = _render(src, mid)
        if rplot:
            if not image:
                image = mimg
            return rname, rplot, image, rmeta

    if not image:
        image = fallback_img
    return base_name, "", image, {}


_SORT_CACHE = {"data": None}

def _grpKey(group):
    return fix_tags(common.GetEncodeString(group or "")).strip().lower()

def _sortPrefs():
    if _SORT_CACHE["data"] is None:
        _SORT_CACHE["data"] = (
            common.load_encrypted(sortPrefsFile, ENC_KEY) or {}
        )
        if not isinstance(_SORT_CACHE["data"], dict):
            _SORT_CACHE["data"] = {}
    return _SORT_CACHE["data"]

def _getSort(listUrl, group=None):
    d = _sortPrefs().get(listUrl, {})
    if group:
        gk = _grpKey(group)
        if gk and gk in d.get("groups", {}):
            return d["groups"][gk]
    return d.get("list", "default")

def _chSortKey(channel):
    return common.GetEncodeString(channel.get("display_name", "")).lower()

def ToggleSort(listUrl, group=None):
    prefs = _sortPrefs()
    entry = prefs.setdefault(listUrl, {})
    current = _getSort(listUrl, group)
    newval = "name" if current != "name" else "default"
    if group:
        entry.setdefault("groups", {})[_grpKey(group)] = newval
    else:
        entry["list"] = newval
    common.save_encrypted(sortPrefsFile, prefs, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")


def PlxCategory(url, cache, listName=""):
    chList = common.plx2list(url, cache)
    background = chList[0].get("background")
    tmpList = []

    favUrls = {f.get("url", "").lower()
               for f in common.load_encrypted(favoritesFile, ENC_KEY)}

    for channel in chList[1:]:
        ch_url = channel.get("url", "")
        if not ch_url:
            continue
        name = common.GetEncodeString(channel.get("name", ch_url))
        iconimage = common.GetEncodeString(channel.get("thumb", ""))

        if channel.get("type") == "playlist":
            AddDir(
                _display_name(name),
                ch_url, 10, iconimage,
                background=background,
            )
        else:
            display = fix_tags(name)
            AddDir(
                display, ch_url, 20, iconimage or "DefaultTVShows.png",
                isFolder=False, IsPlayable=True,
                background=background,
                plot=_channelPlot(listName, isFav=ch_url.lower() in favUrls),
                favUrls=favUrls,
            )
            tmpList.append({"url": ch_url, "image": iconimage,
                            "name": display, "list": listName,
                            "group": "", "epg": "",
                            "kind": "live"})

    common.save_encrypted(tmpListFile, tmpList, ENC_KEY)

def m3uCategory(url, logos, epg, cache, mode, gListIndex=-1, listName=""):
    chList = common.m3u2list(url, cache)
    tmpList = []

    favUrls = {f.get("url", "").lower()
               for f in common.load_encrypted(favoritesFile, ENC_KEY)}

    epgState = {"loaded": False, "sources": [], "dnow": None, "to_zone": None}
    listEpg = epg
    globalEpgUrl = _globalEpg() if mode in (11, 12) else ""

    def _ensureEpg():
        if epgState["loaded"]:
            return
        epgState["loaded"] = True
        if mode not in (11, 12):
            return

        sources = []
        if listEpg:
            d1 = common.epg2dict(
                listEpg, cache=720, noDownload=(listEpg == globalEpgUrl)
            )
            if d1:
                sources.append(d1)
        if globalEpgUrl and globalEpgUrl != listEpg:
            d2 = common.epg2dict(globalEpgUrl, cache=720, noDownload=True)
            if d2:
                sources.append(d2)
        if sources:
            epgState["sources"] = sources
            epgState["dnow"] = datetime.now(tz.UTC)
            epgState["to_zone"] = tz.tzlocal()

    def _drawChannel(channel):
        name = common.GetEncodeString(channel.get("display_name", ""))
        chUrl = common.GetEncodeString(channel.get("url", ""))
        if not chUrl:
            return
        image = channel.get("tvg_logo", channel.get("logo", ""))

        base_display = fix_tags(name)
        kind = _streamKind(
            chUrl, name=name, group=channel.get("group_title", ""),
            tvg_id=channel.get("tvg_id", ""),
        )

        plot = ""
        meta = {}
        name2 = name
        if kind == "live":
            _ensureEpg()
            if epgState["sources"]:
                name2, plot, image, meta = _epgForChannel(
                    epgState["sources"], name, image,
                    epgState["dnow"], epgState["to_zone"],
                    tvg_id=channel.get("tvg_id", ""),
                )

        image = _resolveImage(image, logos)

        if not image and kind != "vod" and _useIptvLogos():
            if "iptvLogos" not in epgState:
                epgState["iptvLogos"] = common.iptvLogos()
            image = common.iptvLogoLookup(
                epgState["iptvLogos"], name,
                channel.get("tvg_id", ""),
            )

        if image:
            disp_image = image
        elif kind == "radio":
            disp_image = "DefaultMusicSongs.png"
        else:
            disp_image = "DefaultAddonPVRClient.png"

        _grp = common.GetEncodeString(channel.get("group_title", ""))
        plot = _channelPlot(
            listName, _grp, plot,
            isFav=chUrl.lower() in favUrls,
            sortedByName=(_getSort(url, _grp or None) == "name"),
        )

        _sp = {}
        if channel.get("props"):
            _sp["props"] = channel["props"]
        if channel.get("vlcopt"):
            _sp["vlcopt"] = channel["vlcopt"]
        AddDir(
            fix_tags(name2), chUrl, 20, disp_image,
            epg=(listEpg or globalEpgUrl), index=-1,
            isFolder=False, IsPlayable=True, plot=plot,
            favUrls=favUrls, epgMeta=meta,
            isAudio=(kind == "radio"),
            streamProps=_sp or None,
        )
        tmpList.append({"url": chUrl, "image": image,
                        "name": base_display,
                        "tvg_id": channel.get("tvg_id", ""),
                        "list": listName,
                        "group": channel.get("group_title", ""),
                        "epg": (listEpg or globalEpgUrl),
                        "kind": kind})

    groupChannels = (
        _groupM3uChannels(chList) if makeGroups else [[c] for c in chList]
    )

    if _getSort(url) == "name":
        if makeGroups:
            groupChannels = sorted(
                groupChannels,
                key=lambda g: common.GetEncodeString(
                    g[0].get("group_title", "")
                ).lower(),
            )
        else:
            groupChannels = sorted(groupChannels, key=lambda g: _chSortKey(g[0]))

    seriesView = groupSeries and (gListIndex > -1 or not makeGroups)
    if seriesView:
        if 0 <= gListIndex < len(groupChannels):
            flat = groupChannels[gListIndex]
        elif not makeGroups:
            flat = chList
        else:
            flat = []

        groupName = ""
        if flat:
            groupName = common.GetEncodeString(
                flat[0].get("group_title", "")
            )

        buckets = {}
        order = []
        rest = []
        for c in flat:
            parsed = _parseEpisode(
                common.GetEncodeString(c.get("display_name", ""))
            )
            if parsed:
                series = parsed[0]
                if series not in buckets:
                    buckets[series] = []
                    order.append(series)
                buckets[series].append(c)
            else:
                rest.append(c)

        if _getSort(url, groupName or None) == "name":
            order.sort(key=lambda s: s.lower())

        if order:
            for series in order:
                eps = buckets[series]
                gimage = ""
                for c in eps:
                    cand = _resolveImage(
                        c.get("tvg_logo", c.get("logo", "")), logos
                    )
                    if cand:
                        gimage = cand
                        break
                AddDir(
                    "{0}  ({1})".format(fix_tags(series), len(eps)),
                    url, 13,
                    iconimage=gimage or "DefaultTVShows.png",
                    epg=epg, cacheMin=cache,
                    plot=_channelPlot(listName, groupName, ""),
                    listName=listName,
                    extraParams={"series": series, "index": gListIndex,
                                 "listname": listName},
                )
            if len(rest) > 1:
                AddDir(
                    "{0}  ({1})".format(getLocaleString(30065), len(rest)),
                    url, 13,
                    iconimage="DefaultTVShows.png",
                    epg=epg, cacheMin=cache,
                    plot=_channelPlot(listName, groupName, ""),
                    listName=listName,
                    extraParams={"series": _UNGROUPED, "index": gListIndex,
                                 "listname": listName,
                                 "group": groupName},
                )
            elif rest:
                _drawChannel(rest[0])

            common.save_encrypted(tmpListFile, tmpList, ENC_KEY)
            return

    for idx, channels in enumerate(groupChannels):
        if gListIndex > -1 and gListIndex != idx:
            continue
        isGroupFolder = gListIndex < 0 and len(channels) > 1
        chs = [channels[0]] if isGroupFolder else channels

        if not isGroupFolder:
            _grp = common.GetEncodeString(
                channels[0].get(
                    "group_title", channels[0].get("display_name", "")
                )
            ) if channels else ""
            if _getSort(url, _grp or None) == "name":
                chs = sorted(chs, key=_chSortKey)

        for channel in chs:
            if isGroupFolder:
                gname = common.GetEncodeString(
                    channel.get("group_title", channel.get("display_name", ""))
                )
                gplot = ""
                gfanart = ""
                gimage = ""
                for c in channels:
                    gplot = gplot or c.get("group_plot", "")
                    gfanart = gfanart or c.get("group_fanart", "")
                    gimage = gimage or c.get("group_logo", "")
                gimage = _resolveImage(gimage, logos)
                if not gimage:
                    for c in channels:
                        cand = _resolveImage(
                            c.get("tvg_logo", c.get("logo", "")), logos
                        )
                        if cand:
                            gimage = cand
                            break
                image = gimage or "DefaultTVShows.png"
                AddDir(
                    "{0}  ({1})".format(fix_tags(gname), len(channels)),
                    url, 12, epg=epg, index=idx,
                    iconimage=image, cacheMin=cache,
                    plot=_channelPlot(listName, "", gplot),
                    fanart=gfanart,
                    listName=listName,
                    groupName=gname, listUrl=url,
                )
                continue

            _drawChannel(channel)

    common.save_encrypted(tmpListFile, tmpList, ENC_KEY)

def SeriesCategory(url, logos, epg, cache, gListIndex, series, listName=""):
    if not series:
        return

    chList = common.m3u2list(url, cache)
    if makeGroups and gListIndex > -1:
        groupChannels = _groupM3uChannels(chList)
        if _getSort(url) == "name":
            groupChannels = sorted(
                groupChannels,
                key=lambda g: common.GetEncodeString(
                    g[0].get("group_title", "")
                ).lower(),
            )
        if 0 <= gListIndex < len(groupChannels):
            flat = groupChannels[gListIndex]
        else:
            flat = []
    else:
        flat = chList

    parentGroup = ""
    if flat:
        parentGroup = common.GetEncodeString(
            flat[0].get("group_title", "")
        )

    favUrls = {f.get("url", "").lower()
               for f in common.load_encrypted(favoritesFile, ENC_KEY)}
    tmpList = []

    matched = []
    for c in flat:
        name = common.GetEncodeString(c.get("display_name", ""))
        parsed = _parseEpisode(name)
        if series == _UNGROUPED:
            if parsed is None:
                matched.append((0, 0, c))
        elif parsed and parsed[0] == series:
            matched.append((parsed[1], parsed[2], c))

    ungroupedSorted = False
    if series == _UNGROUPED:
        ungroupedSorted = _getSort(url, parentGroup or None) == "name"
        if ungroupedSorted:
            matched.sort(key=lambda t: _chSortKey(t[2]))
    else:
        matched.sort(key=lambda t: (t[0], t[1]))

    seriesLabel = "" if series == _UNGROUPED else series

    for _s, _e, channel in matched:
        name = common.GetEncodeString(channel.get("display_name", ""))
        chUrl = common.GetEncodeString(channel.get("url", ""))
        if not chUrl:
            continue
        kind = _streamKind(
            chUrl, name=name, group=channel.get("group_title", ""),
            tvg_id=channel.get("tvg_id", ""),
        )
        image = _resolveImage(
            channel.get("tvg_logo", channel.get("logo", "")), logos
        )
        disp_image = image or "DefaultAddonPVRClient.png"
        display = fix_tags(name)

        AddDir(
            display, chUrl, 20, disp_image, epg=epg, index=-1,
            isFolder=False, IsPlayable=True,
            plot=_channelPlot(
                listName, channel.get("group_title", ""),
                isFav=chUrl.lower() in favUrls,
                seriesName=seriesLabel,
                sortedByName=ungroupedSorted,
            ),
            favUrls=favUrls,
            isAudio=(kind == "radio"),
        )
        tmpList.append({"url": chUrl, "image": image, "name": display,
                        "list": listName,
                        "group": channel.get("group_title", ""),
                        "series": series,
                        "epg": epg,
                        "kind": kind})

    common.save_encrypted(tmpListFile, tmpList, ENC_KEY)


def RandomFromGroup(listUrl, cache, gListIndex):
    chList = common.m3u2list(listUrl, cache)

    if gListIndex < 0:
        pool = [c for c in chList if c.get("url")]
    else:
        groups = (
            _groupM3uChannels(chList) if makeGroups
            else [[c] for c in chList]
        )
        if _getSort(listUrl) == "name" and makeGroups:
            groups = sorted(
                groups,
                key=lambda g: common.GetEncodeString(
                    g[0].get("group_title", "")
                ).lower(),
            )
        if not (0 <= gListIndex < len(groups)):
            return
        pool = [c for c in groups[gListIndex] if c.get("url")]

    if not pool:
        return
    channel = random.choice(pool)
    chUrl = common.GetEncodeString(channel.get("url", ""))
    p = {
        "mode": 20,
        "name": common.GetEncodeString(channel.get("display_name", "")),
        "url": chUrl,
        "iconimage": channel.get("tvg_logo", channel.get("logo", "")),
    }
    if _streamKind(
            chUrl, name=channel.get("display_name", ""),
            group=channel.get("group_title", ""),
            tvg_id=channel.get("tvg_id", "")) == "radio":
        p["audio"] = 1
    xbmc.executebuiltin(
        "PlayMedia({0}?{1})".format(
            sys.argv[0], urllib.parse.urlencode(p)
        )
    )

def RandomFromSeries(listUrl, cache, gListIndex, series):
    if not series:
        return
    chList = common.m3u2list(listUrl, cache)
    if makeGroups and gListIndex > -1:
        groupChannels = _groupM3uChannels(chList)
        if _getSort(listUrl) == "name":
            groupChannels = sorted(
                groupChannels,
                key=lambda g: common.GetEncodeString(
                    g[0].get("group_title", "")
                ).lower(),
            )
        if 0 <= gListIndex < len(groupChannels):
            flat = groupChannels[gListIndex]
        else:
            flat = []
    else:
        flat = chList

    pool = []
    for c in flat:
        cname = common.GetEncodeString(c.get("display_name", ""))
        parsed = _parseEpisode(cname)
        if series == _UNGROUPED:
            if parsed is None and c.get("url"):
                pool.append(c)
        elif parsed and parsed[0] == series and c.get("url"):
            pool.append(c)

    if not pool:
        return
    channel = random.choice(pool)
    chUrl = common.GetEncodeString(channel.get("url", ""))
    p = {
        "mode": 20,
        "name": common.GetEncodeString(channel.get("display_name", "")),
        "url": chUrl,
        "iconimage": channel.get("tvg_logo", channel.get("logo", "")),
    }
    if _streamKind(
            chUrl, name=channel.get("display_name", ""),
            group=channel.get("group_title", ""),
            tvg_id=channel.get("tvg_id", "")) == "radio":
        p["audio"] = 1
    xbmc.executebuiltin(
        "PlayMedia({0}?{1})".format(
            sys.argv[0], urllib.parse.urlencode(p)
        )
    )

def RandomFromFavorites():
    favList = common.load_encrypted(favoritesFile, ENC_KEY) or []
    pool = [f for f in favList if f.get("url")]
    if not pool:
        return
    channel = random.choice(pool)
    chUrl = channel.get("url", "")
    p = {
        "mode": 20,
        "name": channel.get("name", ""),
        "url": chUrl,
        "iconimage": channel.get("image", ""),
    }
    if (channel.get("kind") or _streamKind(
            chUrl, name=channel.get("name", ""),
            group=channel.get("group", ""),
            tvg_id=channel.get("tvg_id", ""))) == "radio":
        p["audio"] = 1
    xbmc.executebuiltin(
        "PlayMedia({0}?{1})".format(
            sys.argv[0], urllib.parse.urlencode(p)
        )
    )


def _splitStreamUrl(url):
    if "|" not in url:
        return url, {}
    base, _, tail = url.partition("|")
    headers = {}
    for pair in tail.split("&"):
        if "=" in pair:
            k, _, v = pair.partition("=")
            headers[k.strip()] = urllib.parse.unquote(v.strip())
    return base, headers

_HLS_CTYPES = ("application/vnd.apple.mpegurl", "application/x-mpegurl",
               "audio/mpegurl", "audio/x-mpegurl")

_DASH_CTYPES = ("application/dash+xml",)

_KNOWN_STREAM_EXT = (".m3u", ".m3u8", ".mpd", ".ts", ".mp4", ".mkv", ".avi",
                     ".mov", ".flv", ".wmv", ".webm",
                     ".mp3", ".aac", ".flac", ".ogg", ".wav", ".m4a",
                     ".opus")

_NO_FASTSTART_RE = re.compile(
    r"(?:[?&]mac=|/(?:play/)?live\.php)", re.I
)

_EXT_MIME = {
    ".ts": "video/mp2t", ".mp4": "video/mp4", ".mkv": "video/x-matroska",
    ".avi": "video/x-msvideo", ".mov": "video/quicktime",
    ".flv": "video/x-flv", ".wmv": "video/x-ms-wmv", ".webm": "video/webm",
    ".mp3": "audio/mpeg", ".aac": "audio/aac", ".flac": "audio/flac",
    ".ogg": "application/ogg", ".wav": "audio/wav", ".m4a": "audio/mp4",
    ".opus": "audio/ogg",
}

_KODI_MAJOR = None


def _kodiMajor():
    global _KODI_MAJOR
    if _KODI_MAJOR is None:
        try:
            _KODI_MAJOR = int(
                xbmc.getInfoLabel("System.BuildVersion").split(".")[0]
            )
        except Exception:
            _KODI_MAJOR = 21
    return _KODI_MAJOR


def _buildPlayItem(name, stream_url, headers, manifest, isAudio, props,
                    iconimage, fastStart=False):
    src_hdr = urllib.parse.urlencode(headers)

    if manifest:
        play_url = stream_url
    else:
        play_url = stream_url + "|" + src_hdr if src_hdr else stream_url

    listitem = xbmcgui.ListItem(path=play_url)

    if manifest or fastStart:
        listitem.setContentLookup(False)
    if not manifest and fastStart:
        _mt = _EXT_MIME.get(
            os.path.splitext(urllib.parse.urlsplit(stream_url).path.lower())[1]
        )
        if _mt:
            listitem.setMimeType(_mt)

    if isAudio:
        try:
            listitem.getMusicInfoTag().setTitle(name)
        except AttributeError:
            listitem.setInfo(type="Music", infoLabels={"Title": name})
    else:
        if manifest:
            listitem.setProperty("inputstream", "inputstream.adaptive")
            if _kodiMajor() < 21:
                listitem.setProperty(
                    "inputstream.adaptive.manifest_type", manifest
                )
            if src_hdr:
                listitem.setProperty(
                    "inputstream.adaptive.manifest_headers", src_hdr
                )
                listitem.setProperty(
                    "inputstream.adaptive.stream_headers", src_hdr
                )
                listitem.setProperty(
                    "inputstream.adaptive.common_headers", src_hdr
                )
        try:
            listitem.getVideoInfoTag().setTitle(name)
        except AttributeError:
            listitem.setInfo(type="Video", infoLabels={"Title": name})

    if props:
        for k, v in props.items():
            listitem.setProperty(k, v)
        sh = props.get("inputstream.adaptive.stream_headers")
        if sh and "inputstream.adaptive.manifest_headers" not in props \
                and props.get("inputstream") == "inputstream.adaptive":
            listitem.setProperty(
                "inputstream.adaptive.manifest_headers", sh
            )

    if iconimage:
        listitem.setArt({"thumb": iconimage, "icon": iconimage})

    return listitem, play_url


def PlayUrl(name, url, iconimage=None, props=None, vlcopt=None,
            isAudio=False, forceFFmpeg=False):
    stream_url, headers = _splitStreamUrl(url)
    if vlcopt:
        headers = dict(vlcopt, **headers)

    if props:
        _psh = props.get("inputstream.adaptive.stream_headers", "")
        if _psh:
            for k, v in urllib.parse.parse_qsl(
                    _psh, keep_blank_values=True):
                headers.setdefault(k, v)

    path = urllib.parse.urlsplit(stream_url).path.lower()

    manifest = None
    if not isAudio and not forceFFmpeg:
        if path.endswith(".mpd"):
            manifest = "mpd"
        elif path.endswith((".m3u8", ".m3u")):
            manifest = "hls"

    if manifest is None and not path.endswith(_KNOWN_STREAM_EXT):
        _pre = stream_url
        stream_url, ctype, status = common.getFinalUrl(
            stream_url, headers=headers or None
        )
        common.log(
            "PlayUrl: getFinalUrl status={0} ctype='{1}' {2}".format(
                status, ctype,
                "redirect -> " + stream_url if stream_url != _pre
                else "no redirect",
            )
        )
        if status == "dead":
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30080), icon, 4000, sound=False
            )
            xbmcplugin.setResolvedUrl(
                int(sys.argv[1]), False, xbmcgui.ListItem()
            )
            return
        path = urllib.parse.urlsplit(stream_url).path.lower()
        if not isAudio and not forceFFmpeg:
            if path.endswith(".mpd") or ctype in _DASH_CTYPES:
                manifest = "mpd"
            elif path.endswith((".m3u8", ".m3u")) or ctype in _HLS_CTYPES:
                manifest = "hls"

    if "User-Agent" not in headers and not isAudio:
        headers["User-Agent"] = common.UA

    fastStart = (
        not _NO_FASTSTART_RE.search(url or "")
        and _streamKind(stream_url, name=name) != "vod"
    )

    listitem, play_url = _buildPlayItem(
        name, stream_url, headers, manifest, isAudio, props, iconimage,
        fastStart=fastStart,
    )

    _via = ("ISA/" + manifest) if manifest else (
        "ffmpeg-forced" if forceFFmpeg else
        ("audio/direct" if isAudio else "direct")
    )
    common.log('PlayUrl: "{0}" via={1}. {2}'.format(name, _via, play_url))

    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

    _playbackMonitor(
        name, stream_url, headers, manifest, isAudio, props, iconimage,
        play_url, fastStart,
    )
    _recordRecent(name, url, iconimage or "", isAudio, play_url)


_MONITOR_IDLE_SEC = 60

_ISA_FALLBACK_MAX_PLAYED = 10.0

_ISA_AUDIO_CHECK_SEC = 5.0

_RECONNECT_MAX = 500
_RECONNECT_MIN_PLAYED = 7.0


_AUDIO_MISSING_VALUES = ("", "unknown", "unk", "none", "n/a", "-", "0")


def _isaNoAudio(player, sname):
    try:
        if not player.isPlayingVideo():
            return False
    except Exception:
        return False

    try:
        streams = player.getAvailableAudioStreams() or []
    except Exception:
        streams = []

    vdec = xbmc.getInfoLabel("Player.Process(videodecoder)") or ""
    adec = xbmc.getInfoLabel("Player.Process(audiodecoder)") or ""
    achan = xbmc.getInfoLabel("Player.Process(audiochannels)") or ""
    labels_ok = bool(vdec.strip())

    def _missing(v):
        return v.strip().lower() in _AUDIO_MISSING_VALUES

    if labels_ok:
        no_audio = _missing(adec) and _missing(achan)
    else:
        no_audio = not streams

    common.log(
        "Playback: audio check streams={0} adec='{1}' achan='{2}' "
        "vdec='{3}' -> {4} [{5}]".format(
            len(streams), adec.strip(), achan.strip(), vdec.strip(),
            "NO AUDIO" if no_audio else "ok", sname,
        )
    )
    return no_audio


def _playbackMonitor(name, stream_url, headers, manifest, isAudio, props,
                      iconimage, play_url, fastStart=False):
    sname = name.split("\n", 1)[0][:40]
    kind = _streamKind(stream_url, name=name)
    allow_rc = (
        kind != "vod"
        and Addon.getSetting("autoReconnect") != "false"
    )

    class _P(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.events = []

        def onAVStarted(self):
            self.events.append(("avstarted", time.time()))

        def onPlayBackStopped(self):
            self.events.append(("stopped", time.time()))

        def onPlayBackEnded(self):
            self.events.append(("ended", time.time()))

        def onPlayBackError(self):
            self.events.append(("error", time.time()))

    def _job():
        try:
            p = _P()
            mon = xbmc.Monitor()
            seen = 0
            started_at = None
            reason = None
            reason_ts = None
            attempt = 0
            cur_play_url = play_url
            cur_manifest = manifest
            tried_ffmpeg = False
            audio_checked = False
            idle = 0
            while True:
                if mon.waitForAbort(1):
                    return
                evs = p.events
                while seen < len(evs):
                    ev, ts = evs[seen]
                    seen += 1
                    if ev == "avstarted" and started_at is None:
                        started_at = ts
                    if ev in ("stopped", "ended", "error") and not reason:
                        reason = ev
                        reason_ts = ts
                if reason:
                    played = (reason_ts - started_at) if started_at else 0.0
                    common.log(
                        "Playback: end reason={0} played={1:.1f}s "
                        "[{2}]".format(reason, played, sname)
                    )
                    if (cur_manifest and not tried_ffmpeg
                            and reason in ("ended", "error")
                            and played < _ISA_FALLBACK_MAX_PLAYED):
                        tried_ffmpeg = True
                        cur_manifest = None
                        common.log(
                            "Playback: adaptive failed, retrying with "
                            "FFmpeg [{0}]".format(sname)
                        )
                        try:
                            ff_props = {
                                k: v for k, v in (props or {}).items()
                                if not k.startswith("inputstream")
                            }
                            new_item, cur_play_url = _buildPlayItem(
                                name, stream_url, headers, None,
                                isAudio, ff_props, iconimage,
                                fastStart=fastStart,
                            )
                            p.play(cur_play_url, new_item)
                        except Exception as ex:
                            common.log(
                                "Playback: FFmpeg fallback failed {0} "
                                "[{1}]".format(ex, sname), 3
                            )
                            return
                        seen = len(p.events)
                        started_at = None
                        reason = None
                        reason_ts = None
                        idle = 0
                        continue
                    if (allow_rc and attempt < _RECONNECT_MAX
                            and reason in ("ended", "error")
                            and started_at is not None
                            and played >= _RECONNECT_MIN_PLAYED):
                        attempt += 1
                        common.log(
                            "Playback: reconnect #{0} [{1}]".format(
                                attempt, sname)
                        )
                        try:
                            _rp = props
                            if cur_manifest is None and manifest:
                                _rp = {
                                    k: v for k, v in (props or {}).items()
                                    if not k.startswith("inputstream")
                                }
                            new_item, cur_play_url = _buildPlayItem(
                                name, stream_url, headers, cur_manifest,
                                isAudio, _rp, iconimage,
                                fastStart=fastStart,
                            )
                            p.play(cur_play_url, new_item)
                        except Exception as ex:
                            common.log(
                                "Playback: reconnect failed {0} [{1}]"
                                .format(ex, sname), 3
                            )
                            return
                        seen = len(p.events)
                        started_at = None
                        reason = None
                        reason_ts = None
                        idle = 0
                        continue
                    return
                if (cur_manifest and not tried_ffmpeg and not audio_checked
                        and started_at is not None
                        and time.time() - started_at >= _ISA_AUDIO_CHECK_SEC):
                    audio_checked = True
                    no_audio = _isaNoAudio(p, sname)
                    if no_audio:
                        tried_ffmpeg = True
                        cur_manifest = None
                        common.log(
                            "Playback: adaptive has no audio, retrying "
                            "with FFmpeg [{0}]".format(sname)
                        )
                        try:
                            ff_props = {
                                k: v for k, v in (props or {}).items()
                                if not k.startswith("inputstream")
                            }
                            new_item, cur_play_url = _buildPlayItem(
                                name, stream_url, headers, None,
                                isAudio, ff_props, iconimage,
                                fastStart=fastStart,
                            )
                            p.play(cur_play_url, new_item)
                        except Exception as ex:
                            common.log(
                                "Playback: FFmpeg fallback failed {0} "
                                "[{1}]".format(ex, sname), 3
                            )
                            return
                        seen = len(p.events)
                        started_at = None
                        reason = None
                        reason_ts = None
                        idle = 0
                        continue

                try:
                    playing = p.isPlaying()
                except Exception:
                    playing = False
                idle = 0 if playing else idle + 1
                if idle >= _MONITOR_IDLE_SEC:
                    return
        except Exception as ex:
            common.log("Playback monitor: {0}".format(ex), 3)

    threading.Thread(target=_job, daemon=False).start()


def _recordRecent(name, url, image, isAudio, play_url):
    cname = name.split("\n", 1)[0].split(" • ", 1)[0].strip()
    if cname.startswith("[B]") and cname.endswith("[/B]"):
        cname = cname[3:-4].strip()
    enc_key = ENC_KEY

    def _isOurs(player):
        try:
            pfile = player.getPlayingFile()
        except Exception:
            return False
        return pfile == play_url

    def _job():
        try:
            player = xbmc.Player()

            started = False
            for _i in range(_RECENT_START_WAIT):
                time.sleep(1)
                playing = (player.isPlayingAudio() if isAudio
                           else player.isPlayingVideo())
                if playing:
                    if _isOurs(player):
                        started = True
                    break
            if not started:
                common.log("RecordRecent: never started, skip", 1)
                return

            time.sleep(_RECENT_CONFIRM_SEC)
            playing = (player.isPlayingAudio() if isAudio
                       else player.isPlayingVideo())
            if not playing or not _isOurs(player):
                common.log("RecordRecent: stopped early, skip", 1)
                return

            src = {}
            for channel in common.load_encrypted(tmpListFile, enc_key):
                ch_name = channel.get("name", "").split("\n", 1)[0] \
                    .split(" • ", 1)[0].strip()
                if ch_name.startswith("[B]") and ch_name.endswith("[/B]"):
                    ch_name = ch_name[3:-4].strip()
                if ch_name.lower() == cname.lower():
                    src = channel
                    break

            entry = {
                "url": url,
                "image": image or src.get("image", ""),
                "name": cname,
                "list": src.get("list", ""),
                "group": src.get("group", ""),
                "series": src.get("series", ""),
                "epg": src.get("epg", ""),
                "kind": src.get("kind") or _streamKind(
                    url, name=cname, group=src.get("group", ""),
                    tvg_id=src.get("tvg_id", ""),
                ),
                "tvg_id": src.get("tvg_id", ""),
                "ts": int(time.time()),
            }

            recent = common.load_encrypted(recentFile, enc_key) or []
            recent = [r for r in recent
                      if r.get("url", "").lower() != url.lower()]
            recent.insert(0, entry)
            common.save_encrypted(recentFile, recent[:_RECENT_MAX], enc_key)
            common.log("RecordRecent: written '{0}'".format(cname), 1)
        except Exception as ex:
            common.log("RecordRecent: {0}".format(ex), 3)

    threading.Thread(target=_job, daemon=False).start()


def Search():
    search_string = GetKeyboardText(getLocaleString(30090)).strip()
    if len(search_string) < 2:
        return False
    xbmc.executebuiltin(
        "Container.Update({0}?{1})".format(
            sys.argv[0],
            urllib.parse.urlencode({"mode": 61, "q": search_string}),
        )
    )
    return False

def DoSearch(search_string):
    needle = clean_tags(search_string).lower()
    if not needle:
        return False

    cached = common.load_encrypted(searchResultsFile, ENC_KEY, default=None)
    if (isinstance(cached, dict) and cached.get("q") == needle
            and cached.get("results")):
        _drawSearchResults(cached["results"])
        return True

    results = _scanSearch(needle)
    if not results:
        xbmcgui.Dialog().ok(
            AddonName,
            getLocaleString(30093, search_string),
        )
        return False

    common.save_encrypted(
        searchResultsFile, {"q": needle, "results": results}, ENC_KEY
    )
    _drawSearchResults(results)
    return True

def _scanSearch(needle):
    chList = common.load_encrypted(playlistsFile, ENC_KEY)
    if MENU.get("external"):
        chList = chList + GetExternalEntries()

    found_channels = 0
    found_groups = 0
    found_playlists = 0
    results = []
    progress = xbmcgui.DialogProgress()
    progress.create(AddonName, getLocaleString(30091))
    total = max(len(chList), 1)

    def _progress(idx, list_name):
        progress.update(
            int(idx * 100 / total),
            getLocaleString(
                30092, clean_tags(list_name),
                found_channels, found_groups, found_playlists,
            ),
        )

    for idx, item in enumerate(chList):
        if progress.iscanceled():
            break
        name = item.get("name", "")
        _progress(idx, name)

        url = item.get("url", "")
        cache = int(item.get("cache", "0") or 0)
        logos = item.get("logos", "")
        epg = item.get("epg", "")

        if needle in clean_tags(name).lower():
            results.append({
                "kind": "playlist", "name": name, "url": url,
                "image": item.get("image", ""), "logos": logos,
                "epg": epg, "uuid": item.get("uuid", "0"),
                "ext": "_folder" in item,
            })
            found_playlists += 1
            _progress(idx, name)

        if not url:
            continue

        try:
            if ".plx" in url.lower():
                for channel in common.plx2list(url, cache)[1:]:
                    ch_url = channel.get("url", "")
                    if not ch_url:
                        continue
                    ch_name = channel.get("name", "")
                    if needle not in clean_tags(ch_name).lower():
                        continue
                    iconimage = common.GetEncodeString(channel.get("thumb", ""))
                    if channel.get("type") == "playlist":
                        results.append({
                            "kind": "plx_sub", "name": ch_name,
                            "url": ch_url, "image": iconimage,
                        })
                        found_playlists += 1
                    else:
                        results.append({
                            "kind": "channel", "name": ch_name,
                            "url": ch_url, "image": iconimage,
                            "list": name, "group": "", "series": "",
                            "epg": "", "plx": True,
                        })
                        found_channels += 1
                    _progress(idx, name)
            else:
                m3uItems = common.m3u2list(url, cache)

                if makeGroups:
                    gOrder = []
                    gCount = {}
                    for c in m3uItems:
                        g = c.get("group_title")
                        if not g:
                            continue
                        if g not in gOrder:
                            gOrder.append(g)
                            gCount[g] = 0
                        gCount[g] += 1
                    for gidx, g in enumerate(gOrder):
                        if needle not in clean_tags(g).lower():
                            continue
                        results.append({
                            "kind": "group", "name": g,
                            "count": gCount[g], "gidx": gidx,
                            "url": url, "logos": logos, "epg": epg,
                            "cache": str(cache), "list": name,
                        })
                        found_groups += 1
                        _progress(idx, name)

                for channel in m3uItems:
                    ch_name = channel.get("display_name", "")
                    if needle not in clean_tags(ch_name).lower():
                        continue
                    chUrl = common.GetEncodeString(channel["url"])
                    image = channel.get("tvg_logo", channel.get("logo", ""))
                    image = _resolveImage(image, logos)
                    groupName = channel.get("group_title", "")

                    seriesName = ""
                    if groupSeries:
                        parsed = _parseEpisode(
                            common.GetEncodeString(ch_name)
                        )
                        if parsed:
                            seriesName = parsed[0]

                    results.append({
                        "kind": "channel", "name": ch_name,
                        "url": chUrl, "image": image,
                        "list": name, "group": groupName,
                        "series": seriesName, "epg": epg,
                    })
                    found_channels += 1
                    _progress(idx, name)
        except Exception as ex:
            common.log("Search: error scanning {0}: {1}".format(url, ex), 3)

    progress.close()
    return results

_SEARCH_KIND_ORDER = {"playlist": 0, "plx_sub": 1, "group": 2, "channel": 3}

def _drawSearchResults(results):
    favUrls = {f.get("url", "").lower()
               for f in common.load_encrypted(favoritesFile, ENC_KEY)}
    tmpList = []
    iptvIdx = None

    listDefault = os.path.join(iconsDir, "defaultlist.png")

    for r in sorted(results,
                    key=lambda x: _SEARCH_KIND_ORDER.get(x.get("kind"), 4)):
        kind = r.get("kind", "")

        if kind == "playlist":
            image = r.get("image", "") or (
                "DefaultPlaylist.png" if r.get("ext") else listDefault
            )
            AddDir(
                getLocaleString(30094, fix_tags(r["name"])), r["url"],
                10 if ".plx" in r["url"] else 11,
                image, r.get("logos", ""), r.get("epg", ""),
                uuid=r.get("uuid", "0"),
            )

        elif kind == "plx_sub":
            AddDir(
                getLocaleString(30095, fix_tags(r["name"])),
                r["url"], 10, r.get("image", "") or listDefault,
            )

        elif kind == "group":
            AddDir(
                getLocaleString(
                    30096,
                    "{0}  ({1})".format(fix_tags(r["name"]), r.get("count", 0)),
                ),
                r["url"], 12, "DefaultTVShows.png",
                r.get("logos", ""), r.get("epg", ""),
                index=r.get("gidx", -1), cacheMin=r.get("cache", "0"),
                plot=_channelPlot(r.get("list", "")),
                listName=r.get("list", ""),
            )

        elif kind == "channel":
            display = fix_tags(r["name"])
            image = r.get("image", "")
            streamKind = _streamKind(r["url"], name=r.get("name", ""))

            if (not image and not r.get("plx")
                    and streamKind != "vod" and _useIptvLogos()):
                if iptvIdx is None:
                    iptvIdx = common.iptvLogos()
                image = common.iptvLogoLookup(iptvIdx, r["name"])

            if image:
                disp_image = image
            elif r.get("plx"):
                disp_image = "DefaultTVShows.png"
            elif streamKind == "radio":
                disp_image = "DefaultMusicSongs.png"
            else:
                disp_image = "DefaultAddonPVRClient.png"

            AddDir(
                display, r["url"], 20, disp_image,
                epg=r.get("epg", ""),
                isFolder=False, IsPlayable=True,
                plot=_channelPlot(
                    r.get("list", ""), r.get("group", ""),
                    isFav=r["url"].lower() in favUrls,
                    seriesName=r.get("series", ""),
                ),
                favUrls=favUrls,
                fromSearch=True,
                originParams={"listname": r.get("list", ""),
                              "group": r.get("group", ""),
                              "series": r.get("series", "")},
                isAudio=(streamKind == "radio"),
            )
            tmpList.append({"url": r["url"], "image": image,
                            "name": display, "list": r.get("list", ""),
                            "group": r.get("group", ""),
                            "series": r.get("series", ""),
                            "epg": r.get("epg", ""),
                            "kind": streamKind})

    if tmpList:
        common.save_encrypted(tmpListFile, tmpList, ENC_KEY)


def GetPlaylistIndex(iuuid, listFile):
    chList = common.load_encrypted(listFile, ENC_KEY)
    for i, playlist in enumerate(chList):
        if playlist.get("uuid") == iuuid:
            return i
    return None

def _xtreamInfo(url):
    try:
        parts = urllib.parse.urlsplit(url)
        if "get.php" not in parts.path.lower():
            return url, None
        q = dict(urllib.parse.parse_qsl(parts.query))
        user = q.get("username")
        pwd = q.get("password")
        if not user or not pwd:
            return url, None

        if q.get("type", "") not in ("m3u_plus", "m3u"):
            q["type"] = "m3u_plus"
        q.setdefault("output", "m3u8")
        norm = urllib.parse.urlunsplit(
            (parts.scheme, parts.netloc, parts.path,
             urllib.parse.urlencode(q), "")
        )

        epg = urllib.parse.urlunsplit(
            (parts.scheme, parts.netloc,
             parts.path.rsplit("/", 1)[0] + "/xmltv.php",
             urllib.parse.urlencode({"username": user, "password": pwd}), "")
        )
        return norm, epg
    except Exception:
        return url, None

def AddNewList():
    listName = GetKeyboardText(getLocaleString(30110)).strip()
    if not listName:
        return

    listUrl = GetChoice(
        30111, 30112, 30113, 30114, 30115,
        fileType=1, fileMask=".plx|.m3u|.m3u8",
    )
    if not listUrl:
        return

    is_plx = ".plx" in listUrl.lower()

    xtream_epg = None
    if listUrl.startswith("http"):
        listUrl, xtream_epg = _xtreamInfo(listUrl)

    image = GetChoice(30116, 30116, 30116, 30002, 30003, 30001, fileType=2)
    image = image or ""

    logosUrl = ""
    epgUrl = ""
    if not is_plx:
        logosUrl = GetChoice(30117, 30118, 30119, 30118, 30119, 30001,
                             fileType=0) or ""
        if logosUrl.startswith("http") and not logosUrl.endswith("/"):
            logosUrl += "/"
        if xtream_epg:
            if xbmcgui.Dialog().yesno(
                AddonName, getLocaleString(30123, xtream_epg)
            ):
                epgUrl = xtream_epg
            else:
                epgUrl = GetChoice(30120, 30121, 30122, 30121, 30122, 30001,
                                   fileType=1, fileMask=".xml|.xml.gz") or ""
        else:
            epgUrl = GetChoice(30120, 30121, 30122, 30121, 30122, 30001,
                               fileType=1, fileMask=".xml|.xml.gz") or ""
    cacheInMinutes = 0
    if listUrl.startswith("http"):
        cacheInMinutes = GetNumFromUser(getLocaleString(30124), "0") or 0

    chList = common.load_encrypted(playlistsFile, ENC_KEY)
    for item in chList:
        if item["url"].lower() == listUrl.lower():
            xbmcgui.Dialog().notification(
                AddonName,
                '"{0}" {1}'.format(item["name"], getLocaleString(30126)),
                icon, 5000,
            )
            return

    chList.append({
        "name": listName,
        "url": listUrl,
        "image": image,
        "logos": logosUrl,
        "epg": epgUrl,
        "cache": cacheInMinutes,
        "uuid": str(uuidlib.uuid4()),
    })
    if common.save_encrypted(playlistsFile, chList, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def RemoveFromLists(iuuid, listFile):
    if not xbmcgui.Dialog().yesno(AddonName, getLocaleString(30010, AddonName) + "?"):
        return

    chList = common.load_encrypted(listFile, ENC_KEY)
    vDirsList = common.load_encrypted(vDirectoriesFile, ENC_KEY)

    chList = [p for p in chList if p.get("uuid") != iuuid]

    for vDir in vDirsList:
        vDir["data"] = [u for u in vDir.get("data", []) if u != iuuid]

    common.save_encrypted(listFile, chList, ENC_KEY)
    common.save_encrypted(vDirectoriesFile, vDirsList, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def ChangeKey(iuuid, listFile, key, titleId, favourites=False):
    index = iuuid if favourites else GetPlaylistIndex(iuuid, listFile)
    if index is None:
        return

    chList = common.load_encrypted(listFile, ENC_KEY)
    if not (0 <= index < len(chList)):
        return

    newValue = GetKeyboardText(
        getLocaleString(titleId), chList[index].get(key, "")
    ).strip()
    if not newValue:
        return

    chList[index][key] = newValue
    if favourites and key == "url":
        chList[index]["kind"] = _streamKind(
            newValue, name=chList[index].get("name", ""),
            group=chList[index].get("group", ""),
            tvg_id=chList[index].get("tvg_id", ""),
        )
    if common.save_encrypted(listFile, chList, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def ChangeChoice(
    iuuid, listFile, key, choiceTitle, fileTitle, urlTitle,
    choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None,
    favourites=False,
):
    index = iuuid if favourites else GetPlaylistIndex(iuuid, listFile)
    if index is None:
        return

    chList = common.load_encrypted(listFile, ENC_KEY)
    if not (0 <= index < len(chList)):
        return

    newValue = GetChoice(
        choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl,
        choiceNone, fileType, fileMask,
        defaultText=chList[index].get(key, ""),
    )
    if newValue is None:
        return
    if key == "url" and not newValue:
        return
    if key == "logos" and newValue.startswith("http") and not newValue.endswith("/"):
        newValue += "/"

    if key == "url" and not favourites and newValue.startswith("http"):
        newValue, xtream_epg = _xtreamInfo(newValue)
        if xtream_epg and xbmcgui.Dialog().yesno(
            AddonName, getLocaleString(30123, xtream_epg)
        ):
            chList[index]["epg"] = xtream_epg

    chList[index][key] = newValue
    if common.save_encrypted(listFile, chList, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def ChangeCache(iuuid, listFile):
    index = GetPlaylistIndex(iuuid, listFile)
    if index is None:
        return

    chList = common.load_encrypted(listFile, ENC_KEY)
    if not (0 <= index < len(chList)):
        return
    if not chList[index].get("url", "").startswith("http"):
        return

    cacheInMinutes = GetNumFromUser(
        getLocaleString(30124), str(chList[index].get("cache", 0))
    )
    if cacheInMinutes is None:
        return

    chList[index]["cache"] = cacheInMinutes
    if common.save_encrypted(listFile, chList, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def MoveInList(iuuid, step, listFile):
    def _move(lst, index, stp):
        new_index = index + stp
        if stp == 0 or not (0 <= new_index < len(lst)):
            return None
        lst = list(lst)
        item = lst.pop(index)
        lst.insert(new_index, item)
        return lst

    vdirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)

    home_vdir = None
    for vdir in vdirs:
        if iuuid in vdir.get("data", []):
            home_vdir = vdir
            break

    if home_vdir is not None:
        data = home_vdir["data"]
        index = data.index(iuuid)
        if step == 0:
            step = GetIndexFromUser(len(data), index)
        moved = _move(data, index, step)
        if moved is None:
            return
        home_vdir["data"] = moved
        common.save_encrypted(vDirectoriesFile, vdirs, ENC_KEY)

    else:
        theList = common.load_encrypted(listFile, ENC_KEY)
        inDirs = set()
        for vdir in vdirs:
            inDirs.update(vdir.get("data", []))

        dirItems = [p for p in theList if p.get("uuid") in inDirs]
        rootItems = [p for p in theList if p.get("uuid") not in inDirs]

        index = None
        for i, p in enumerate(rootItems):
            if p.get("uuid") == iuuid:
                index = i
                break
        if index is None:
            return

        if step == 0:
            step = GetIndexFromUser(len(rootItems), index)
        moved = _move(rootItems, index, step)
        if moved is None:
            return
        common.save_encrypted(listFile, dirItems + moved, ENC_KEY)

    xbmc.executebuiltin("Container.Refresh()")


def ListFavorites():
    AddDir(
        "[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30140)),
        "favorites", 42,
        "DefaultAddSource.png",
        isFolder=False,
    )
    favList = common.load_encrypted(favoritesFile, ENC_KEY)

    useEpg = Addon.getSetting("favoritesEpg") == "true"
    epgCache = {}
    dnow = to_zone = None
    iptvIdx = None

    for i, channel in enumerate(favList):
        name = channel.get("name", "").split("\n", 1)[0].strip()
        image = channel.get("image", "")
        plot = ""
        meta = {}
        chUrl = channel.get("url", "")
        kind = channel.get("kind") or _streamKind(
            chUrl, name=channel.get("name", ""),
            group=channel.get("group", ""),
            tvg_id=channel.get("tvg_id", ""),
        )

        epg = channel.get("epg", "") if (useEpg and kind == "live") else ""
        gEpg = _globalEpg() if (useEpg and kind == "live") else ""
        if epg or gEpg:
            sources = []
            if epg:
                if epg not in epgCache:
                    epgCache[epg] = common.epg2dict(
                        epg, cache=720, noDownload=(epg == gEpg)
                    )
                if epgCache[epg]:
                    sources.append(epgCache[epg])
            if gEpg and gEpg != epg:
                if gEpg not in epgCache:
                    epgCache[gEpg] = common.epg2dict(gEpg, cache=720, noDownload=True)
                if epgCache[gEpg]:
                    sources.append(epgCache[gEpg])
            if sources:
                if dnow is None:
                    dnow = datetime.now(tz.UTC)
                    to_zone = tz.tzlocal()
                name, plot, image, meta = _epgForChannel(
                    sources, name, image, dnow, to_zone,
                    tvg_id=channel.get("tvg_id", ""),
                )

        if not image and kind != "vod" and _useIptvLogos():
            if iptvIdx is None:
                iptvIdx = common.iptvLogos()
            image = common.iptvLogoLookup(
                iptvIdx, channel.get("name", "").split("\n", 1)[0].strip()
            )

        if not image and kind == "radio":
            image = "DefaultMusicSongs.png"

        seriesName = channel.get("series", "")
        if seriesName == _UNGROUPED:
            seriesName = ""

        plot = _channelPlot(
            channel.get("list", ""), channel.get("group", ""), plot,
            seriesName=seriesName,
        )

        AddDir(
            fix_tags(name),
            chUrl,
            21,
            image,
            index=i,
            isFolder=False,
            IsPlayable=True,
            plot=plot,
            epgMeta=meta,
            listName=channel.get("list", ""),
            isAudio=(kind == "radio"),
        )

def AddFavorites(url, iconimage, name, origin=None):
    name = name.split("\n", 1)[0].split(" • ", 1)[0].strip()
    if name.startswith("[B]") and name.endswith("[/B]"):
        name = name[3:-4].strip()

    favList = common.load_encrypted(favoritesFile, ENC_KEY)
    for item in favList:
        if item.get("url", "").lower() == url.lower():
            xbmcgui.Dialog().notification(
                AddonName,
                "'{0}' {1}".format(name, getLocaleString(30144)),
                icon, 5000,
            )
            return

    src = dict(origin) if origin else {}
    if not src:
        for channel in common.load_encrypted(tmpListFile, ENC_KEY):
            ch_name = channel.get("name", "").split("\n", 1)[0] \
                .split(" • ", 1)[0].strip()
            if ch_name.startswith("[B]") and ch_name.endswith("[/B]"):
                ch_name = ch_name[3:-4].strip()
            if ch_name.lower() == name.lower():
                src = channel
                url = url or channel.get("url", "")
                iconimage = iconimage or channel.get("image", "")
                break

    if not url:
        return

    favList.append({
        "url": url,
        "image": iconimage or "",
        "name": name,
        "list": src.get("list", ""),
        "group": src.get("group", ""),
        "series": src.get("series", ""),
        "epg": src.get("epg", ""),
        "kind": src.get("kind") or _streamKind(
            url, name=name, group=src.get("group", ""),
            tvg_id=src.get("tvg_id", ""),
        ),
        "tvg_id": src.get("tvg_id", ""),
    })
    common.save_encrypted(favoritesFile, favList, ENC_KEY)
    xbmcgui.Dialog().notification(
        AddonName,
        "'{0}' {1}".format(name, getLocaleString(30145)),
        icon, 4000,
    )
    xbmc.executebuiltin("Container.Refresh()")

def AddNewFavorite():
    chName = GetKeyboardText(getLocaleString(30141)).strip()
    if not chName:
        return
    chUrl = GetKeyboardText(getLocaleString(30142)).strip()
    if not chUrl:
        return
    image = GetChoice(30143, 30143, 30143, 30002, 30003, 30001, fileType=2)
    image = image or ""

    favList = common.load_encrypted(favoritesFile, ENC_KEY)
    for item in favList:
        if item.get("url", "").lower() == chUrl.lower():
            xbmcgui.Dialog().notification(
                AddonName,
                "'{0}' {1}".format(chName, getLocaleString(30144)),
                icon, 5000,
            )
            return

    favList.append({"url": chUrl, "image": image, "name": chName,
                    "kind": _streamKind(chUrl, name=chName)})
    if common.save_encrypted(favoritesFile, favList, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def RemoveFromFavourites(index):
    favList = common.load_encrypted(favoritesFile, ENC_KEY)
    if index < 0 or index >= len(favList):
        return
    del favList[index]
    common.save_encrypted(favoritesFile, favList, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def RemoveFavoriteByUrl(url):
    favList = common.load_encrypted(favoritesFile, ENC_KEY)
    newList = [f for f in favList if f.get("url", "").lower() != url.lower()]
    if len(newList) != len(favList):
        common.save_encrypted(favoritesFile, newList, ENC_KEY)
        xbmc.executebuiltin("Container.Refresh()")

def MoveInFavourites(index, step):
    theList = common.load_encrypted(favoritesFile, ENC_KEY)
    if not (0 <= index < len(theList)):
        return

    if step == 0:
        step = GetIndexFromUser(len(theList), index)

    new_index = index + step
    if step == 0 or not (0 <= new_index < len(theList)):
        return

    item = theList.pop(index)
    theList.insert(new_index, item)

    common.save_encrypted(favoritesFile, theList, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def OpenFavoriteOrigin(index):
    favList = common.load_encrypted(favoritesFile, ENC_KEY)
    if not (0 <= index < len(favList)):
        return
    fav = favList[index]
    _openOrigin(fav.get("list", ""), fav.get("group", ""),
                fav.get("series", ""))

def _openOrigin(listName, groupName="", seriesName=""):
    if not listName:
        return

    candidates = common.load_encrypted(playlistsFile, ENC_KEY)
    if MENU.get("external"):
        candidates = candidates + GetExternalEntries()

    wanted = _plainName(listName).lower()
    target = None
    for item in candidates:
        if _plainName(item.get("name", "")).lower() == wanted:
            target = item
            break

    if target is None:
        common.OKmsg(
            AddonName,
            getLocaleString(30147, _plainName(listName)),
        )
        return

    params = {
        "mode": 11,
        "url": target.get("url", ""),
        "name": target.get("name", ""),
        "logos": target.get("logos", ""),
        "epg": target.get("epg", ""),
        "cache": target.get("cache", "0"),
    }

    if ".plx" in target.get("url", "").lower():
        params["mode"] = 10
    else:
        gidxFound = -1
        if groupName and makeGroups:
            cache = int(target.get("cache", "0") or 0)
            chList = common.m3u2list(target.get("url", ""), cache)
            for gidx, channels in enumerate(_groupM3uChannels(chList)):
                if channels and channels[0].get("group_title", "") == groupName:
                    gidxFound = gidx
                    break

        if seriesName and groupSeries:
            params["mode"] = 13
            params["series"] = seriesName
            params["index"] = gidxFound
            params["listname"] = target.get("name", "")
        elif gidxFound > -1:
            params["mode"] = 12
            params["index"] = gidxFound
            params["listname"] = target.get("name", "")

    xbmc.executebuiltin(
        "Container.Update({0}?{1})".format(
            sys.argv[0], urllib.parse.urlencode(params)
        )
    )


def ListRecent():
    recent = common.load_encrypted(recentFile, ENC_KEY) or []

    favUrls = {f.get("url", "").lower()
               for f in common.load_encrypted(favoritesFile, ENC_KEY)}

    useEpg = Addon.getSetting("favoritesEpg") == "true"
    epgCache = {}
    dnow = to_zone = None
    iptvIdx = None

    for channel in recent:
        name = channel.get("name", "")
        image = channel.get("image", "")
        plot = ""
        meta = {}
        chUrl = channel.get("url", "")
        kind = channel.get("kind") or _streamKind(
            chUrl, name=channel.get("name", ""),
            group=channel.get("group", ""),
            tvg_id=channel.get("tvg_id", ""),
        )

        epg = channel.get("epg", "") if (useEpg and kind == "live") else ""
        gEpg = _globalEpg() if (useEpg and kind == "live") else ""
        if epg or gEpg:
            sources = []
            if epg:
                if epg not in epgCache:
                    epgCache[epg] = common.epg2dict(
                        epg, cache=720, noDownload=(epg == gEpg)
                    )
                if epgCache[epg]:
                    sources.append(epgCache[epg])
            if gEpg and gEpg != epg:
                if gEpg not in epgCache:
                    epgCache[gEpg] = common.epg2dict(
                        gEpg, cache=720, noDownload=True
                    )
                if epgCache[gEpg]:
                    sources.append(epgCache[gEpg])
            if sources:
                if dnow is None:
                    dnow = datetime.now(tz.UTC)
                    to_zone = tz.tzlocal()
                name, plot, image, meta = _epgForChannel(
                    sources, name, image, dnow, to_zone,
                    tvg_id=channel.get("tvg_id", ""),
                )
        if not image and kind != "vod" and _useIptvLogos():
            if iptvIdx is None:
                iptvIdx = common.iptvLogos()
            image = common.iptvLogoLookup(iptvIdx, channel.get("name", ""))

        if not image and kind == "radio":
            image = "DefaultMusicSongs.png"

        seriesName = channel.get("series", "")
        if seriesName == _UNGROUPED:
            seriesName = ""

        plot = _channelPlot(
            channel.get("list", ""), channel.get("group", ""), plot,
            isFav=chUrl.lower() in favUrls,
            seriesName=seriesName,
        )

        _ts = channel.get("ts")
        if _ts:
            try:
                _when = datetime.fromtimestamp(int(_ts)).strftime(
                    "%d.%m.%Y. %H:%M"
                )
                _stamp = "[COLOR FFE06666][B]{0}[/B][/COLOR]".format(_when)
                plot = _stamp + "\n\n" + plot if plot else _stamp
            except Exception:
                pass

        AddDir(
            fix_tags(name),
            chUrl,
            20,
            image,
            isFolder=False,
            IsPlayable=True,
            plot=plot,
            epgMeta=meta,
            listName=channel.get("list", ""),
            favUrls=favUrls,
            isAudio=(kind == "radio"),
            fromRecent=True,
            originParams={
                "listname": channel.get("list", ""),
                "group": channel.get("group", ""),
                "series": channel.get("series", ""),
                "epg": channel.get("epg", ""),
                "tvg_id": channel.get("tvg_id", ""),
                "kind": channel.get("kind", ""),
            },
        )

def PlayLastRecent():
    recent = common.load_encrypted(recentFile, ENC_KEY) or []
    if not recent:
        xbmcgui.Dialog().notification(
            AddonName, getLocaleString(30160), icon, 4000
        )
        return
    last = recent[0]
    kind = last.get("kind") or _streamKind(
        last.get("url", ""), name=last.get("name", ""),
        group=last.get("group", ""), tvg_id=last.get("tvg_id", ""),
    )
    p = {
        "mode": 20,
        "name": last.get("name", ""),
        "url": last.get("url", ""),
        "iconimage": last.get("image", ""),
    }
    if kind == "radio":
        p["audio"] = 1
    xbmc.executebuiltin(
        "PlayMedia({0}?{1})".format(
            sys.argv[0], urllib.parse.urlencode(p)
        )
    )

def RemoveFromRecent(chUrl):
    recent = common.load_encrypted(recentFile, ENC_KEY) or []
    newList = [r for r in recent
               if r.get("url", "").lower() != chUrl.lower()]
    if len(newList) != len(recent):
        common.save_encrypted(recentFile, newList, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")


def AddNewDirectory():
    dir_name = _sanitizeDirName(GetKeyboardText(getLocaleString(30044)))
    if not dir_name:
        return

    vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    for vdir in vDirs:
        if vdir.get("name", "").lower() == dir_name.lower():
            xbmcgui.Dialog().notification(
                AddonName,
                "'{0}' {1}".format(dir_name, getLocaleString(30125)),
                icon, 5000,
            )
            return

    dir_icon = xbmcgui.Dialog().browse(1, getLocaleString(30026), "files")

    vDirs.append({
        "name": dir_name,
        "data": [],
        "icon": dir_icon or "",
        "uuid": str(uuidlib.uuid4()),
    })
    if common.save_encrypted(vDirectoriesFile, vDirs, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def AddToDirectory(playlist_uuid):
    vdirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    if not vdirs:
        common.OKmsg(AddonName, getLocaleString(30044))
        return

    svdir = xbmcgui.Dialog().select(
        getLocaleString(30170),
        [vdir.get("name", "?") for vdir in vdirs],
    )
    if svdir < 0:
        return

    if playlist_uuid in vdirs[svdir].get("data", []):
        return

    for vdir in vdirs:
        vdir["data"] = [u for u in vdir.get("data", []) if u != playlist_uuid]

    vdirs[svdir]["data"].append(playlist_uuid)
    common.save_encrypted(vDirectoriesFile, vdirs, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def RenameDirectory(iuuid):
    vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    target = None
    for vdir in vDirs:
        if vdir.get("uuid") == iuuid:
            target = vdir
            break
    if target is None:
        return

    extFolders = set()
    if MENU.get("external"):
        for entry in GetExternalEntries():
            parts = _folderParts(entry.get("_folder", ""))
            if parts:
                extFolders.add(parts[0].lower())

    taken = {v.get("name", "").lower() for v in vDirs
             if v.get("uuid") != iuuid}
    taken |= extFolders

    newName = target.get("name", "")
    while True:
        newName = _sanitizeDirName(
            GetKeyboardText(getLocaleString(30025), newName)
        )
        if not newName or newName == target.get("name", ""):
            return
        if newName.lower() not in taken:
            break
        xbmcgui.Dialog().notification(
            AddonName,
            "'{0}' {1}".format(newName, getLocaleString(30125)),
            icon, 5000,
        )

    target["name"] = newName
    if common.save_encrypted(vDirectoriesFile, vDirs, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def ChangeDirectoryIcon(iuuid):
    vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    target = None
    for vdir in vDirs:
        if vdir.get("uuid") == iuuid:
            target = vdir
            break
    if target is None:
        return

    newIcon = GetChoice(
        30026, 30026, 30026, 30002, 30003, 30001, fileType=2,
        defaultText=target.get("icon", ""),
    )
    if newIcon is None:
        return

    target["icon"] = newIcon
    if common.save_encrypted(vDirectoriesFile, vDirs, ENC_KEY):
        xbmc.executebuiltin("Container.Refresh()")

def RemoveFromDirectory(playlist_uuid):
    vdirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    changed = False
    for vdir in vdirs:
        if playlist_uuid in vdir.get("data", []):
            vdir["data"] = [u for u in vdir["data"] if u != playlist_uuid]
            changed = True
    if changed:
        common.save_encrypted(vDirectoriesFile, vdirs, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def DeleteDirectory(iuuid, with_contents=False):
    vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
    target = None
    for vdir in vDirs:
        if vdir.get("uuid") == iuuid:
            target = vdir
            break
    if target is None:
        return

    msg = getLocaleString(30028) if with_contents else getLocaleString(30027)
    if not xbmcgui.Dialog().yesno(
        AddonName, "{0}: '{1}'?".format(msg, target.get("name", "?"))
    ):
        return

    contents = common.load_encrypted(playlistsFile, ENC_KEY)

    if with_contents:
        uuids = set(target.get("data", []))
        contents = [p for p in contents if p.get("uuid") not in uuids]
        common.save_encrypted(playlistsFile, contents, ENC_KEY)
    else:
        order = [u for u in target.get("data", [])]
        inFolder = {p.get("uuid"): p for p in contents
                    if p.get("uuid") in order}
        others = [p for p in contents if p.get("uuid") not in inFolder]
        ordered = [inFolder[u] for u in order if u in inFolder]
        common.save_encrypted(playlistsFile, others + ordered, ENC_KEY)

    vDirs = [v for v in vDirs if v.get("uuid") != iuuid]
    common.save_encrypted(vDirectoriesFile, vDirs, ENC_KEY)
    xbmc.executebuiltin("Container.Refresh()")

def ShowDirectoryContents(directory_uuid):
    folder_name = None

    if directory_uuid.startswith("ext:"):
        folder_name = directory_uuid[4:]
    else:
        vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
        for vdir in vDirs:
            if vdir.get("uuid") == directory_uuid:
                folder_name = vdir.get("name", "")
                dirFiles = vdir.get("data", [])
                chList = common.load_encrypted(playlistsFile, ENC_KEY)
                byUuid = {p.get("uuid"): p for p in chList}
                AddListItems(
                    [byUuid[u] for u in dirFiles if u in byUuid],
                    addToVdir=False,
                )
                break
        if folder_name is None:
            return

    if MENU.get("external"):
        subs, here = _extFolderChildren(GetExternalEntries(), folder_name)
        for f in subs:
            child = _joinFolder(folder_name, f)
            AddDir(
                "[COLOR FF00FF66][B]{0}[/B][/COLOR]".format(f),
                child, 71,
                os.path.join(iconsDir, "defaultfolder.png"),
                uuid="ext:{0}".format(child), isFolder=True,
                addToVdir=False,
            )
        for entry in here:
            AddDir(
                _display_name(entry.get("name", "?")),
                entry.get("url", ""),
                11,
                entry.get("image") or "DefaultPlaylist.png",
                entry.get("logos", ""),
                entry.get("epg", ""),
                index=1,
                uuid=entry.get("uuid", "0"),
                cacheMin=_extListCache(entry),
                addToVdir=False,
                isExternal=True,
            )


def CleanCache(allItems):
    valid = set()
    liveUrls = set()
    for item in allItems:
        url = item.get("url", "")
        if url:
            liveUrls.add(url)
        if url.startswith("http"):
            valid.update(common.cacheNames(url, item.get("epg", "")))

    gEpg = _globalEpg()
    if gEpg.startswith("http"):
        valid.update(common.cacheNames("", gEpg))
        valid.add(
            os.path.basename(common.cachePath(gEpg + "#epg-raw")) + ".lock"
        )

    if _useIptvLogos():
        valid.update(common.iptvLogosCacheNames())

    ext_sources = list(EXTERNAL_LISTS_URLS or [])
    if Addon.getSetting("useCustomSource") == "true":
        cs = (Addon.getSetting("customSourceUrl") or "").strip()
        if cs.startswith("http"):
            ext_sources.append({"url": cs})

    for src in ext_sources:
        surl = src.get("url", "") if isinstance(src, dict) else src
        if surl:
            valid.add(
                os.path.basename(common.cachePath(surl + "#external"))
            )

    for the_file in os.listdir(common.cacheDir):
        file_path = os.path.join(common.cacheDir, the_file)
        if the_file.endswith((".tmp", ".lock")):
            if common.isFileNew(file_path, 2 * 3600):
                continue
            try:
                os.unlink(file_path)
            except Exception as ex:
                common.log("CleanCache: stale lock/tmp {0}: {1}".format(the_file, ex), 3)
            continue
        try:
            if os.path.isfile(file_path) and the_file not in valid:
                os.unlink(file_path)
        except Exception as ex:
            common.log("CleanCache: {0}".format(ex), 3)

    prefs = _sortPrefs()
    stale = [u for u in prefs if u not in liveUrls]
    if stale:
        for u in stale:
            del prefs[u]
        common.save_encrypted(sortPrefsFile, prefs, ENC_KEY)

def ClearExternalCache():
    for entry in GetExternalEntries():
        eurl = entry.get("url", "")
        if eurl.startswith("http"):
            common.DelFile(common.cachePath(eurl))
            epg = entry.get("epg", "")
            if epg:
                common.DelFile(common.cachePath(epg))
                common.DelFile(common.cachePath(epg + "#epg-parsed"))
    for src in (EXTERNAL_LISTS_URLS or []):
        surl = src.get("url", "") if isinstance(src, dict) else src
        if surl:
            common.DelFile(common.cachePath(surl + "#external"))
    if Addon.getSetting("useCustomSource") == "true":
        cs = (Addon.getSetting("customSourceUrl") or "").strip()
        if cs.startswith("http"):
            common.DelFile(common.cachePath(cs + "#external"))

def _checkUrl(url, expect="playlist"):
    if expect == "xml":
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": common.UA}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                head = resp.read(131072)
        except urllib.error.HTTPError as ex:
            return "HTTP {0}".format(ex.code)
        except Exception:
            return getLocaleString(30183)

        if head[:2] == b"\x1f\x8b":
            try:
                head = zlib.decompressobj(
                    16 + zlib.MAX_WBITS
                ).decompress(head)
            except Exception:
                return getLocaleString(30182)
        try:
            text = head.decode("utf-8", errors="replace")
        except Exception:
            return getLocaleString(30182)
        if "<tv" not in text[:4096]:
            return getLocaleString(30182)
        return "OK"

    try:
        data = common.OpenURL(url, timeout=10)
    except urllib.error.HTTPError as ex:
        if expect == "any" and ex.code not in (404, 410):
            return "OK"
        return "HTTP {0}".format(ex.code)
    except Exception:
        return getLocaleString(30183)

    body = (data or "").lstrip().lstrip("\ufeff")
    if expect == "json":
        try:
            if not isinstance(json.loads(body), list):
                return getLocaleString(30182)
        except (ValueError, TypeError):
            return getLocaleString(30182)
    elif expect == "playlist":
        if not body or body[:1] == "<":
            return getLocaleString(30182)
    return "OK"

def CheckSources():
    rows = []

    checks = []

    if Addon.getSetting("useCustomSource") == "true":
        cs = (Addon.getSetting("customSourceUrl") or "").strip()
        checks.append((getLocaleString(30181), cs, "json", None, ""))

    if Addon.getSetting("useGlobalEpg") == "true":
        epgSrc = _globalEpg()
        if Addon.getSetting("globalEpgSource") == "1":
            checks.append((getLocaleString(30185), epgSrc, "xml",
                           None, "file"))
        else:
            checks.append((getLocaleString(30185), epgSrc, "xml",
                           None, ""))

    if Addon.getSetting("useGlobalLogos") == "true":
        if Addon.getSetting("globalLogosSource") == "1":
            logosSrc = (Addon.getSetting("globalLogosFolder") or "").strip()
            checks.append((getLocaleString(30186), logosSrc, "any",
                           None, "dir"))
        else:
            logosSrc = (Addon.getSetting("globalLogosUrl") or "").strip()
            checks.append((getLocaleString(30186), logosSrc, "any",
                           None, ""))

    for item in common.load_encrypted(playlistsFile, ENC_KEY):
        label = _plainName(item.get("name", "?"))
        url = item.get("url", "")
        local = "" if url.startswith("http") else "file"
        checks.append((label, url, "playlist", item.get("uuid"), local))

    if MENU.get("external"):
        for entry in GetExternalEntries():
            label = _plainName(entry.get("name", "?"))
            checks.append((label, entry.get("url", ""), "playlist",
                           None, ""))

    if not checks:
        return

    progress = xbmcgui.DialogProgress()
    progress.create(AddonName, getLocaleString(30091))
    total = len(checks)

    try:
        for i, (label, url, expect, iuuid, local) in enumerate(checks):
            if progress.iscanceled():
                return
            progress.update(
                int(i * 100 / total), getLocaleString(30180, label)
            )
            if local == "file":
                status = "OK" if url and os.path.isfile(url) else (
                    getLocaleString(30184) + " — " + getLocaleString(30183)
                )
            elif local == "dir":
                status = "OK" if url and os.path.isdir(url) else (
                    getLocaleString(30184) + " — " + getLocaleString(30183)
                )
            elif not url:
                status = getLocaleString(30183)
            else:
                status = _checkUrl(url, expect)

            color = "FF00BB66" if status == "OK" else "FFFF4444"
            marker = "• " if iuuid is not None else ""
            rows.append((
                "{0}{1}  —  [COLOR {2}][B]{3}[/B][/COLOR]".format(
                    marker, label, color, status
                ),
                iuuid,
            ))
    finally:
        progress.close()

    sel = 0
    while True:
        sel = xbmcgui.Dialog().select(
            getLocaleString(30371), [r[0] for r in rows],
            preselect=min(sel, len(rows) - 1),
        )
        if sel < 0:
            return
        iuuid = rows[sel][1]
        if iuuid is None:
            continue
        before = len(common.load_encrypted(playlistsFile, ENC_KEY))
        RemoveFromLists(iuuid, playlistsFile)
        after = len(common.load_encrypted(playlistsFile, ENC_KEY))
        if after < before:
            del rows[sel]

def ToggleGroups():
    Addon.setSetting("makeGroups", "false" if makeGroups else "true")
    xbmc.executebuiltin("Container.Refresh()")


def run(enc_key, external_lists_urls, menu=None):
    global ENC_KEY, EXTERNAL_LISTS_URLS, MENU
    ENC_KEY = enc_key
    EXTERNAL_LISTS_URLS = external_lists_urls
    MENU = menu or {}
    common.set_key(enc_key)

    if not os.path.isfile(favoritesFile):
        common.save_encrypted(favoritesFile, [], ENC_KEY)
    if not os.path.isfile(vDirectoriesFile):
        common.save_encrypted(vDirectoriesFile, [], ENC_KEY)

    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace("?", "")))
    url = params.get("url")
    logos = params.get("logos", "")
    epg = params.get("epg", "")
    name = params.get("name")
    iconimage = params.get("iconimage")
    cache = int(params.get("cache", "0") or 0)
    index = int(params.get("index", "-1"))
    move = int(params.get("move", "0"))
    mode = int(params.get("mode", "0"))
    uuid = params.get("uuid", "0")

    _crumb = AddonName
    if mode == 40:
        _crumb = "{0} [B]»[/B] {1}".format(AddonName, getLocaleString(30040))
    elif mode == 50:
        _crumb = "{0} [B]»[/B] {1}".format(AddonName, getLocaleString(30041))
    elif mode == 61:
        _crumb = "{0} [B]»[/B] {1}".format(AddonName, getLocaleString(30042))
    elif mode in (10, 11, 12, 13):
        _listCrumb = _plainName(
            params.get("listname") or params.get("name", "")
        )
        if _listCrumb:
            _crumb = "{0} [B]»[/B] {1}".format(AddonName, _listCrumb)
    xbmcplugin.setPluginCategory(int(sys.argv[1]), _crumb)
    xbmcplugin.addSortMethod(
        int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED
    )

    sprops = {}
    if params.get("sprops"):
        try:
            sprops = json.loads(params["sprops"])
        except (ValueError, TypeError):
            sprops = {}

    succeeded = True

    if mode == 0:
        Categories()

    elif mode == 10:
        PlxCategory(url, cache, listName=params.get("name", ""))

    elif mode in (11, 12):
        m3uCategory(url, logos, epg, cache, mode, index,
                    listName=params.get("listname") or params.get("name", ""))

    elif mode == 13:
        SeriesCategory(
            url, logos, epg, cache, index,
            params.get("series", ""),
            params.get("listname") or params.get("name", ""),
        )

    elif mode in (20, 21):
        PlayUrl(
            name, url, iconimage,
            props=sprops.get("props"),
            vlcopt=sprops.get("vlcopt"),
            isAudio=(params.get("audio") == "1"),
            forceFFmpeg=(params.get("ff") == "1"),
        )

    elif mode == 30:
        AddNewList()

    elif mode == 31:
        MoveInList(uuid, move, playlistsFile)

    elif mode == 32:
        RemoveFromLists(uuid, playlistsFile)

    elif mode == 33:
        ChangeKey(uuid, playlistsFile, "name", 30110)

    elif mode == 34:
        ChangeChoice(
            uuid, playlistsFile, "url",
            30111, 30112, 30113, 30114, 30115,
            None, 1, ".plx|.m3u|.m3u8",
        )

    elif mode == 35:
        ChangeChoice(
            uuid, playlistsFile, "image",
            30116, 30116, 30116, 30002, 30003, 30001, 2,
        )

    elif mode == 36:
        ChangeChoice(
            uuid, playlistsFile, "logos",
            30117, 30118, 30119, 30118, 30119, 30001, 0,
        )

    elif mode == 37:
        ChangeChoice(
            uuid, playlistsFile, "epg",
            30120, 30121, 30122, 30121, 30122, 30001,
            1, ".xml|.xml.gz",
        )

    elif mode == 38:
        ChangeCache(uuid, playlistsFile)

    elif mode == 39:
        if xbmcgui.Dialog().yesno(AddonName, getLocaleString(30367) + "?"):
            common.DelFile(playlistsFile)
            vDirs = common.load_encrypted(vDirectoriesFile, ENC_KEY)
            for vdir in vDirs:
                vdir["data"] = []
            common.save_encrypted(vDirectoriesFile, vDirs, ENC_KEY)
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30189), icon, 4000
            )
            xbmc.executebuiltin("Container.Refresh()")
        return

    elif mode == 40:
        ListFavorites()

    elif mode == 41:
        _origin = None
        if params.get("favlist"):
            _origin = {
                "list": params.get("favlist", ""),
                "group": params.get("favgroup", ""),
                "series": params.get("favseries", ""),
                "epg": params.get("favepg", ""),
                "tvg_id": params.get("favtvg", ""),
                "kind": params.get("favkind", ""),
            }
        AddFavorites(url, iconimage, name, origin=_origin)

    elif mode == 42:
        AddNewFavorite()

    elif mode == 43:
        RemoveFromFavourites(index)

    elif mode == 44:
        RemoveFavoriteByUrl(url)

    elif mode == 45:
        MoveInFavourites(index, move)

    elif mode == 46:
        ChangeKey(index, favoritesFile, "name", 30141, favourites=True)

    elif mode == 47:
        ChangeKey(index, favoritesFile, "url", 30142, favourites=True)

    elif mode == 48:
        ChangeChoice(
            index, favoritesFile, "image",
            30143, 30143, 30143, 30002, 30003, 30001, 2,
            favourites=True,
        )

    elif mode == 49:
        if xbmcgui.Dialog().yesno(AddonName, getLocaleString(30364) + "?"):
            common.DelFile(favoritesFile)
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30146), icon, 4000
            )
            xbmc.executebuiltin("Container.Refresh()")
        return

    elif mode == 50:
        ListRecent()

    elif mode == 51:
        PlayLastRecent()
        return

    elif mode == 52:
        RemoveFromRecent(url)
        return

    elif mode == 53:
        if xbmcgui.Dialog().yesno(AddonName, getLocaleString(30365) + "?"):
            common.DelFile(recentFile)
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30161), icon, 4000
            )
            xbmc.executebuiltin("Container.Refresh()")
        return

    elif mode == 60:
        Search()
        return

    elif mode == 61:
        succeeded = DoSearch(params.get("q", "")) is not False

    elif mode == 70:
        AddNewDirectory()

    elif mode == 71:
        ShowDirectoryContents(uuid)

    elif mode == 72:
        AddToDirectory(uuid)

    elif mode == 73:
        RemoveFromDirectory(uuid)

    elif mode == 74:
        RenameDirectory(uuid)

    elif mode == 75:
        ChangeDirectoryIcon(uuid)

    elif mode == 76:
        DeleteDirectory(uuid)

    elif mode == 77:
        DeleteDirectory(uuid, with_contents=True)

    elif mode == 78:
        if xbmcgui.Dialog().yesno(AddonName, getLocaleString(30366) + "?"):
            inDirs = set()
            for vdir in common.load_encrypted(vDirectoriesFile, ENC_KEY):
                inDirs.update(vdir.get("data", []))
            chList = common.load_encrypted(playlistsFile, ENC_KEY)
            chList = [p for p in chList if p.get("uuid") not in inDirs]
            common.save_encrypted(playlistsFile, chList, ENC_KEY)
            common.DelFile(vDirectoriesFile)
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30171), icon, 4000
            )
            xbmc.executebuiltin("Container.Refresh()")
        return

    elif mode == 80:
        _openOrigin(
            params.get("listname", ""),
            params.get("group", ""),
            params.get("series", ""),
        )

    elif mode == 81:
        OpenFavoriteOrigin(index)

    elif mode == 82:
        _g = params.get("group", "")
        if params.get("scope") == "group" and not _g:
            xbmcgui.Dialog().notification(
                AddonName, getLocaleString(30034), icon, 4000
            )
            return
        ToggleSort(url, _g or None)
        return

    elif mode == 83:
        RandomFromGroup(url, cache, index)
        return

    elif mode == 84:
        RandomFromSeries(url, cache, index, params.get("series", ""))
        return

    elif mode == 85:
        RandomFromFavorites()
        return

    elif mode == 86:
        ToggleGroups()

    elif mode == 90:
        _watched = (
            "useCustomSource", "customSourceUrl",
            "useGlobalEpg", "globalEpgSource", "globalEpgUrl",
            "globalEpgFile",
            "useGlobalLogos", "globalLogosSource", "globalLogosUrl",
            "globalLogosFolder", "useIptvOrgLogos",
            "useCustomUA", "customUA",
            "makeGroups", "groupSeries", "favoritesEpg",
        )
        _before = {k: Addon.getSetting(k) for k in _watched}
        Addon.openSettings()
        _after = {k: Addon.getSetting(k) for k in _watched}
        if _before != _after:
            xbmc.executebuiltin("Container.Refresh()")
        return

    elif mode == 91:
        CheckSources()
        return

    elif mode == 92:
        for f in os.listdir(common.cacheDir):
            fpath = os.path.join(common.cacheDir, f)
            if f.endswith((".tmp", ".lock")) and common.isFileNew(fpath, 600):
                continue
            common.DelFile(fpath)
        common.DelFile(searchResultsFile)
        gEpg = _globalEpg()
        if gEpg.startswith("http"):
            common.prefetchEpg(gEpg, cache=720)
        if _useIptvLogos():
            common.prefetchIptvLogos(cache=2880)
        xbmcgui.Dialog().notification(
            AddonName, getLocaleString(30187), icon, 4000
        )
        return

    elif mode == 93:
        ClearExternalCache()
        xbmcgui.Dialog().notification(
            AddonName, getLocaleString(30188), icon, 4000
        )
        return

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=succeeded)
