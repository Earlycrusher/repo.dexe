
if __name__ == '__main__':
	__import__('entry').routing()
